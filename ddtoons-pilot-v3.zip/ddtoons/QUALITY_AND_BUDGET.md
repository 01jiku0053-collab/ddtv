# D&D Toons quality and budget preset

This revision is a starting preset, not a claim that every scene will look good. Review the first five scenes before paying for the full episode.

## What changed

- Original picture-book style with a restrained palette replaces the generic saturated 3D prompt. Keep selected character reference images; the words alone cannot guarantee identity.
- Story scripts target 18–24 scenes and 300–380 spoken words. At most ten scenes are selected for 5-second image-to-video. Other scenes use the existing slow image movement.
- A scene's `animate` flag now actually controls whether a clip is ordered. The previous producer ignored it. `max_parts: 1` prevents extra chained clips from multiplying the bill.
- Static camera and one simple character action replace simultaneous mouth movement, complex action and camera movement. The editor no longer forces a different framing at every cut.
- Songs, generated music bed and generated sound effects default off for stories. Use a licensed music track in `assets/music`; enable songs for a planned rhyme episode only.
- Script approval is enabled in automatic mode. Verify the actual approval gate before activating unattended scheduling.

## Practical workflow

1. Lock the main cast and one location. Check reference warnings in `produce.log`; if image references were rejected, stop before ordering animation.
2. Generate a five-scene preview. Check the hook, exact costume/colors, left-right continuity, prop count, simple acting and distinct voices. Reject or revise the script and still frames before proceeding.
3. Keep no more than ten animated scenes. Prefer action in scenes 1–2, one visual gag, the turn and the payoff.
4. Use the actual Runware cost returned in the job status. Set your own per-job spending approval; this package does not enforce a dollar ceiling. Do not run automatic production until the first full episode is measured.
5. Inspect the final episode and vertical crops before uploading. The existing Shorts are crops of the long video, so reframe or produce separate vertical art when important action is cut off.

## Prompt example for a 5-second clip

First frame: Pip, the same coral scarf and round ears as the approved reference, stands left of a small blue wagon. One yellow pear lies in the wagon. Static medium camera at Pip's eye level; warm afternoon light; same garden gate behind him.

Motion: Pip reaches with his right paw, lifts the single pear, pauses and smiles. Wagon, scarf, gate and framing stay fixed. One continuous action; no speaking mouth, new props, cuts or camera movement.

## Cost estimate

Runware lists Seedream 4.5 at about $0.04 per image. At the configured 720p size, Seedance 1.0 Pro Fast is listed around $0.0134 per second, or ~$0.067 per five-second clip. Twenty-four images plus ten clips suggest ~$1.63 before character/location sheets, thumbnails, retries, voice, music and taxes. The 1080p clip rate is higher (about $0.16 per five seconds). The previous 40-clip setting could multiply cost further, especially with chained parts. Use returned cost rather than this estimate for a real job.

## Why a generator swap is not the first fix

The original video request incorrectly used top-level `frameImages: [{ inputImage: ... }]`. Runware documents `inputs.frameImages: [{ image: ..., frame: "first" }]` for Seedance 1.0 Pro Fast. That request shape is fixed here. The image request now stops if character references fail, instead of retrying without them. The Prompt Director also stops on missing shots rather than quietly issuing simple fallback prompts.

The current 720p Seedance 1.0 Pro Fast should be tested with this corrected request before changing models. To compare motion quality, render one approved image and identical simple motion prompt with a second model (e.g. Kling VIDEO 3.0 Standard at about $0.084/s without audio). A five-second Kling sample is about $0.42; use it only for a hero action if it is visibly better. The existing `lab` compares other models but includes lip-sync and OmniHuman runs; it is not a cheap two-model comparison. Do not assume a model improves character consistency without comparing the same first frame.
