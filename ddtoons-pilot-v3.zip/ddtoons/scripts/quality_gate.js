'use strict';
// Deterministic checks before script approval and before any Runware charges.
const fs = require('fs');
const path = require('path');

function inspect(script, cast, cfg, opts = {}) {
  const errors = [], warnings = [];
  const ids = new Set(cast.characters.map(c => c.id));
  const scenes = script.scenes || [];
  const animated = scenes.filter(s => s.animate).length;
  if (animated > (cfg.video.max_clips || 0)) errors.push(`${animated} animated scenes exceed max_clips ${cfg.video.max_clips}`);
  const chorus = [];
  for (const [i, sc] of scenes.entries()) {
    const n = i + 1;
    if (!sc.visual_anchor || sc.visual_anchor.trim().length < 15) errors.push(`scene ${n}: missing visual_anchor (costume, prop, screen position)`);
    if (!sc.image_prompt || sc.image_prompt.trim().length < 25) errors.push(`scene ${n}: image prompt too vague`);
    if (sc.animate && (!sc.motion_prompt || sc.motion_prompt.trim().length < 15)) errors.push(`scene ${n}: missing specific motion`);
    for (const id of sc.characters || []) if (!ids.has(id)) errors.push(`scene ${n}: unknown character ${id}`);
    for (const ln of sc.lines || []) {
      if (!ids.has(ln.speaker)) errors.push(`scene ${n}: unknown speaker ${ln.speaker}`);
      if (ln.chorus) chorus.push(String(ln.text || '').replace(/\[[^\]]+\]/g, '').trim().toLowerCase());
    }
  }
  if (chorus.length) {
    const unit = chorus.length / 3;
    if (!Number.isInteger(unit) || unit > 4 || chorus.some((line, i) => line !== chorus[i % unit]))
      errors.push('chorus must repeat the same one-to-four lines exactly three times');
  }
  if (!chorus.length) warnings.push('No marked chorus; acceptable for a non-musical story, but musical pilots need one.');
  if (opts.requireReferences) {
    const used = new Set(scenes.flatMap(s => s.characters || []));
    for (const id of used) {
      const ref = cast.characters.find(c => c.id === id)?.ref || path.join(opts.root, 'assets', 'characters', `${id}.jpg`);
      if (!fs.existsSync(ref)) errors.push(`missing approved reference image for ${id}: ${ref}`);
    }
  }
  return { ok: errors.length === 0, errors, warnings, animated, scenes: scenes.length, chorusRepetitions: chorus.length };
}
module.exports = { inspect };
