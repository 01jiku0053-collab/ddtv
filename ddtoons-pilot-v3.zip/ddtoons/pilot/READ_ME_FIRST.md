# D&D Toons pilot: Doodle and the Missing Red Kite

**Status:** Script and storyboard draft only. No paid media was generated. Review the story and exact chorus before production.

## Audience and hook

English-language musical story adventure for ages 3–6. At 0–10 seconds the red kite blows away; Dia and Dhruv make two mistaken discoveries, Doodle follows a yellow tail, and the family finds and repairs the kite. One garden set limits background drift.

## The original refrain

> Look up high, look down low.  
> Where did Doodle's red kite go?

The two lines occur unchanged in scenes 4, 10 and 16. They are a spoken sing-song refrain in the JSON draft. A music producer may turn them into an original two-line melody after checking syllable timing. Do not mark them as `sing:true` or use the current generic 30-second song generator until a test confirms the melody and words are exact. The current pipeline cannot guarantee that an AI song sings specified lyrics correctly.

## Production choices

- 20 storyboard scenes, 291 spoken words, 10 selected animation clips. This is a short pilot, about 2–3 minutes depending on delivery and music; adjust after a read-aloud.
- Character wardrobe and the single red kite/yellow tail are repeated in each visual anchor. The gate validates presence of anchors, IDs, clip count, and exact chorus repetition. Human review must check actual prop and costume continuity because text checks cannot prove images match.
- First lock approved reference images for Nani, Dia, Dhruv and Doodle using Character Setup. Give each speaking human a distinct approved ElevenLabs voice ID; Doodle should use a bark sound rather than the narrator reading “Woof woof.” The starter cast has empty voice IDs.
- Generate a five-scene preview only. Check scene 1's kite motion, scene 4's refrain, costume identity, line delivery, and the 16:9 to 9:16 Shorts crop. Stop and revise before a full run.
- The draft JSON is a review artifact. The n8n form still writes its own script. To produce this exact pilot, import it as a job script with matching brief/status and approved cast references, or use the form with the detailed brief and approve only a matching script. Do not assume dropping this JSON into n8n automatically starts a job.

## Script direction for a form-based draft

Idea: Dia's red kite blows past the garden gate. Dia and Dhruv search high and low. A ribbon and a red picnic ball are funny false clues. Doodle finds a yellow tail beneath the blue picnic blanket. They repair the string and fly the kite together. All action stays in one sunny garden. Use exactly the original two-line refrain above at three points; use the approved DD family looks and no new characters. Keep the hook within 10 seconds, 18–22 scenes, at most 10 simple animated actions, and preserve red kite, yellow tail, blue blanket, costumes and screen sides.

Lesson: Look carefully and help each other. No danger, thief, police chase, injury or punishment.
