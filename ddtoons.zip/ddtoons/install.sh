#!/bin/sh
# DD TV English installer. Run on the VPS as root:   sh install.sh you@gmail.com
set -e
SRC=$(cd "$(dirname "$0")" && pwd)
DEST=/opt/storyvault/ddtoons
N8N=n8n-wx3b-n8n-1
mkdir -p "$DEST/scripts" "$DEST/config" "$DEST/jobs" "$DEST/series" "$DEST/logs" "$DEST/assets/music" "$DEST/assets/characters"
cp "$SRC"/scripts/*.js "$DEST/scripts/"
for f in config.json characters.json; do
  if [ -f "$DEST/config/$f" ]; then echo "kept your existing config/$f"; else cp "$SRC/config/$f" "$DEST/config/"; fi
done
if [ -n "$1" ]; then sed -i "s/SET_YOUR_EMAIL@gmail.com/$1/" "$DEST/config/config.json"; echo "notify_email set to $1"; fi
chown -R 1000:1000 "$DEST"
echo "--- checks from inside n8n ---"
docker exec $N8N sh -c 'test -x /data/bin/ffmpeg && echo "ffmpeg OK" || echo "ffmpeg MISSING at /data/bin/ffmpeg"'
docker exec $N8N sh -c 'test -f /data/secrets.json && echo "secrets.json OK" || echo "secrets.json MISSING"'
docker exec $N8N node -e "require('/data/ddtoons/scripts/lib.js'); console.log('scripts OK')"
docker exec $N8N node -e "fetch('http://ollama-k6m6-ollama-1:11434/api/tags').then(r=>r.json()).then(j=>console.log('Ollama models:', j.models.map(m=>m.name).join(', '))).catch(e=>console.log('Ollama NOT reachable:', e.message))"
echo "Done. Next: import ddtoons-workflow.json into n8n (see README)."
# Add new config keys to an existing config.json without touching your values
docker exec $N8N node -e "const fs=require('fs');const p='/data/ddtoons/config/config.json';const c=JSON.parse(fs.readFileSync(p));c.voice=c.voice||{};if(!c.voice.pool){c.voice.pool={girl:[],boy:[],woman:[],man:[],grandma:[],grandpa:[],creature:[]};fs.writeFileSync(p,JSON.stringify(c,null,2));console.log('added voice.pool to config.json')}"
