#!/bin/sh
# DD TV English installer. Run on the VPS as root:   sh install.sh you@gmail.com
set -e
SRC=$(cd "$(dirname "$0")" && pwd)
DEST=/opt/storyvault/ddtoons
N8N=n8n-wx3b-n8n-1
mkdir -p "$DEST/scripts" "$DEST/config" "$DEST/jobs" "$DEST/series" "$DEST/logs" "$DEST/assets/music" "$DEST/assets/characters"
cp "$SRC"/scripts/*.js "$DEST/scripts/"
cp "$SRC/config/config.json" "$DEST/config/config.defaults.json"
for f in config.json characters.json; do
  if [ -f "$DEST/config/$f" ]; then echo "kept your existing config/$f"; else cp "$SRC/config/$f" "$DEST/config/"; fi
done
if [ -n "$1" ]; then sed -i "s/SET_YOUR_EMAIL@gmail.com/$1/" "$DEST/config/config.json"; echo "notify_email set to $1"; fi
chown -R 1000:1000 "$DEST"
echo "--- checks from inside n8n ---"
docker exec $N8N sh -c 'test -x /data/bin/ffmpeg && echo "ffmpeg OK" || echo "ffmpeg MISSING at /data/bin/ffmpeg"'
docker exec $N8N sh -c 'test -f /data/secrets.json && echo "secrets.json OK" || echo "secrets.json MISSING"'
docker exec $N8N node -e "require('/data/ddtoons/scripts/lib.js'); console.log('scripts OK')"
docker exec $N8N node -e "fetch('http://ollama-k6m6-ollama-1:11434/api/tags').then(r=>r.json()).then(j=>console.log('Ollama models:', j.models.map(m=>m.name).join(', '))).catch(e=>console.log('Ollama NOT reachable:', e.message))"
# Add new config keys to an existing config.json without touching your values
echo "--- config ---"
docker exec $N8N node -e "
const fs=require('fs');const p='/data/ddtoons/config/config.json';const c=JSON.parse(fs.readFileSync(p));
const d=JSON.parse(fs.readFileSync('/data/ddtoons/config/config.defaults.json'));let added=[];
for(const k of Object.keys(d)){ if(c[k]===undefined){c[k]=d[k];added.push(k);} else if(typeof d[k]==='object'&&!Array.isArray(d[k])){ for(const k2 of Object.keys(d[k])) if(c[k][k2]===undefined){c[k][k2]=d[k][k2];added.push(k+'.'+k2);} } }
fs.writeFileSync(p,JSON.stringify(c,null,2));console.log(added.length?'added new settings: '+added.join(', '):'config up to date (your settings kept)');"
echo "--- n8n workflow ---"
cp "$SRC/ddtoons-workflow.json" "$DEST/ddtoons-workflow.json" && chown 1000:1000 "$DEST/ddtoons-workflow.json"
docker exec $N8N sh -c 'n8n export:credentials --all --output=/tmp/ddtv_creds.json >/dev/null 2>&1; node /data/ddtoons/scripts/patch_workflow.js /tmp/ddtv_creds.json /data/ddtoons/ddtoons-workflow.json /tmp/ddtv_wf.json && n8n import:workflow --input=/tmp/ddtv_wf.json 2>&1 | grep -iE "success|import|error" | tail -3; rm -f /tmp/ddtv_creds.json /tmp/ddtv_wf.json'
echo "Done. In n8n: refresh the page, delete the OLD 'DD TV English' workflow, then Publish the new one."
