// Small HTTP wrapper around Laya for the DD TV pipeline.
//   POST /decide { state, questions }  -> Laya systemOne result (answers with probabilities)
//   GET  /health                       -> { ready }
import http from 'node:http';
import { Laya } from '@receptron/laya';

let laya = null, loading = null, lastError = null, queue = Promise.resolve();
function load() {
  if (laya) return Promise.resolve(laya);
  if (!loading) {
    console.log('loading Laya (first start downloads ~1.7 GB)...');
    loading = Laya.load({ cacheDir: process.env.LAYA_CACHE || '/cache', sessionOptions: { intraOpNumThreads: +(process.env.THREADS || 2) } })
      .then(l => { laya = l; lastError = null; console.log('Laya ready'); return l; })
      .catch(e => { lastError = e; loading = null; console.error('Laya load failed:', e.message); throw e; });
  }
  return loading;
}
load().catch(() => {});

// one decision at a time (keeps memory flat on a small VPS)
const serial = fn => { const run = queue.then(fn, fn); queue = run.catch(() => {}); return run; };

http.createServer(async (req, res) => {
  const send = (code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
  if (req.method === 'GET' && req.url === '/health') return send(laya ? 200 : 503, { ready: !!laya, error: lastError && lastError.message });
  if (req.method !== 'POST' || req.url !== '/decide') return send(404, { error: 'not found' });
  let body = '';
  for await (const c of req) body += c;
  try {
    const { state, questions } = JSON.parse(body || '{}');
    const l = await load();
    const r = await serial(() => l.systemOne(state, questions));
    send(200, r);
  } catch (e) { send(500, { error: String(e.message || e) }); }
}).listen(8080, () => console.log('ddtv-laya listening on 8080'));
