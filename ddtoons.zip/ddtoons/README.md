# DD TV English – kids story pipeline (n8n)

Runs on the same setup as StoryVault: n8n container `n8n-wx3b-n8n-1`, files in
`/opt/storyvault/ddtoons` (= `/data/ddtoons` inside n8n), same `secrets.json`,
same Runware + ElevenLabs keys, same Ollama.

**You stay the creative director:** every story starts from *your* idea and lesson,
you approve the characters, and nothing is produced until you approve each script.
That keeps the channel on the right side of YouTube's inauthentic-content policy.

## Automatic mode (default)

Every **Sunday at 10:00** (Swedish time) the writer invents a story by itself:
about 60% are **public-domain classics retold** with new characters (Panchatantra, Aesop, Jataka,
Grimm, Andersen, world folk tales), the rest are **originals**. It never copies YouTube channels,
films or modern books, and never repeats a tale (`ideas_history.json`).

You get **one email** with the plan and the character pictures → **Approve** → every part is
written, produced and delivered to Drive automatically. Watch each video before you upload.

**Surprise Me form** = invent a story right now (optionally with a theme hint like "Diwali").

Settings in `config.json` → `auto`:
`episodes_min` / `episodes_max` (1–5), `classic_share` (0.6 = 60% classics),
`formats` (mix of story / rhyme / learn), `approve_scripts` (`true` = also approve each script by email).
Optional: add `"youtube_key": "..."` to secrets.json so the writer sees which *topics* are popular on kids YouTube.

## What's in the workflow (one import, three forms)

| Form | What it does |
|---|---|
| **New Story** | Idea + lesson + **1–5 parts** + characters (*new*, *family* or *mix*). The writer plans the story, **invents the characters**, and Runware draws each one. The plan and the pictures come by email: **Approve / Revise / Reject**. Write `redraw: Pip, rounder and more orange` in the notes to redraw a character. |
| **Resume** | *resume production*: re-run an approved episode (only missing files are remade). *write script*: write or rewrite an episode script, e.g. to continue a story you paused. |
| **Character Setup** | Draws and locks the DD family (Nani, Dia, Dhruv, Doodle). Only needed for *family* / *mix* stories, and for Nani, who hosts every story. |

**How a 3-part story flows**
1. New Story form → story plan + character pictures by email → you approve.
2. Part 1 script by email → you approve (or revise) → production → "Ready" email with Drive links.
3. The Part 2 script is written automatically and arrives for approval. It opens with Nani's
   short recap; every part except the last ends with a gentle teaser.
4. … until the last part. Reject any script to pause; continue later with the Resume form
   (action *write script*, job ID `<seriesId>_e2`).

The characters' pictures are locked for the whole story, so every scene of every part uses
them as references. That's what keeps Pip looking like Pip in Part 5.

Production makes: 16:9 episode with music under the voices, 2 vertical Shorts with a
title on top, a thumbnail and a metadata file (title gets "| Story Name Part N").

## Install (about 15 minutes)

1. **Copy the folder to the VPS** (Hostinger file manager or `scp`), then:
   ```sh
   cd ddtoons && sh install.sh your@gmail.com
   ```
   The checks at the end should all say OK and list your Ollama models.
2. **Check the model name.** If `glm-5.3:cloud` isn't in the list, put the exact name in
   `/opt/storyvault/ddtoons/config/config.json` → `llm.ollama_model`.
3. The installer imports the workflow into n8n and connects your Gmail and Google Drive
   credentials automatically. Refresh n8n; if an older DD TV English workflow exists, delete it.
4. If any Gmail/Drive box still shows a red triangle, open it and pick the credential by hand.
5. **Drive folder (optional):** make a "DD TV English" folder in Drive, copy its ID from the URL
   into `drive_parent_folder_id`. Empty = episode folders land in My Drive root.
6. **Activate** the workflow (forms only have a Production URL when active).
   Double-click each form node to copy its URL and bookmark all three.

## Before the first episode

**Nani first.** Nani hosts every story, so lock her look once: Character Setup form →
generate → `nani` → `3`, then pick → `nani` → the number you like. New characters the
writer invents will copy her art style, so the whole channel looks consistent.
(Do the same for Dia, Dhruv and Doodle before your first *family* or *mix* story.)

**Voices.** The writer gives every invented character a voice type
(girl, boy, woman, man, grandma, grandpa, creature). In ElevenLabs → Voice Library, add a
few voices to your account and paste their IDs into `config.json` → `voice.pool`, e.g.
`"girl": ["id1", "id2"]` (two IDs = two different girls in the same story).
Nani's voice goes in `characters.json` → `nani` → `voice_id`. Any type left empty
uses the narrator voice, and the Ready email tells you which.

**Music.** Put 3–6 cheerful royalty-free tracks (YouTube Audio Library, "no attribution
required") in `/opt/storyvault/ddtoons/assets/music/`. Tracks with `rhyme` or `song` in the
file name are used for rhyme episodes; the rest for stories. Music ducks under speech automatically.

**Intro/outro (optional).** `assets/intro.mp4` and `assets/outro.mp4` are added automatically if present.
An outro of about 20 s gives room for YouTube end-screen elements.

**First test cheaply:** set `video.max_clips` to `4` for the first episode, check the result,
then set it back to `16`.

## Costs per episode (rough)
Seedream images ~22 × $0.04 ≈ $0.90 · Seedance clips up to 16 · thumbnail $0.04 ·
ElevenLabs ≈ 2,500–4,000 characters. The Ready email shows the Runware cost of each run.

## Script quality
The StoryVault lesson applies here too: if the GLM drafts feel flat, switch the writer.
Add `"openrouter_key": "..."` to `/opt/storyvault/secrets.json` and set `llm.provider` to
`"openrouter"` (check the model slug in `llm.openrouter_model` on openrouter.ai).
A kids script costs cents with a top model.

## Useful commands
```sh
# follow a production live
tail -f /opt/storyvault/ddtoons/jobs/<jobId>/produce.log
# what stage is a job in
cat /opt/storyvault/ddtoons/jobs/<jobId>/status.json
# remake one scene: delete its files, then use the Resume form
cd /opt/storyvault/ddtoons/jobs/<jobId> && rm scene_007.jpg scene_007.mp4 scene_007_seg.mp4 final.mp4 short_*.mp4
```

## Troubleshooting
| Symptom | Fix |
|---|---|
| "script failed" email mentioning ollama 404 | Wrong `llm.ollama_model` name |
| produce.log: `image variant 1 rejected` then images still made | Fine: Runware took the older reference format automatically |
| Ready email warns images were made **without** references | Runware rejected both reference formats: send me the error line from produce.log |
| Clip errors mentioning width/height/duration | The error lists allowed values: put them in `video.width/height/duration` |
| A character looks wrong in the plan | Revise the plan with `redraw: Name` and what to change |
| Characters drift between scenes | Remake the bad scenes (delete their files, Resume). If it's a family character, lock them in Character Setup |
| A story stopped after one part | You rejected (or never answered) a script. Resume form → *write script* → `<seriesId>_e<N>` |
| ElevenLabs 401 / quota | Check key and credits |

## Channel rhythm (policy-safe)
2–3 episodes a week, each story from your own idea. Rotate formats (story → rhyme → learn).
Watch every episode before upload. Post Shorts on separate days.
