'use strict';
// THE SCRIPT DOCTOR: runs on every song and story before it reaches you.
//   1) measured checks in code (length, line length, narration share)
//   2) an editor check (Claude): rhymes, story logic, tone, the formula, viewer moment, pictures, originality
//      -> anything that fails is FIXED automatically (up to 2 rounds)
//   3) Laya (if running): a second opinion on every line: "safe for a 3-year-old?" and "does the picture match?"
//      -> flagged lines get one targeted fix
//   4) a scorecard for the email: ✅ passed · 🔧 fixed · ⚠️ please look
const L = require('./lib');

const icon = st => ({ pass: '✅', fixed: '🔧', warn: '⚠️' }[st] || '•');
function cardHtml(card) {
  return `<div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:10px 14px;margin:10px 0;font-size:14px">
<b>🩺 Script Doctor</b> · ${card.filter(c => c.status === 'warn').length ? '<b style="color:#b45309">please look at the ⚠️ items</b>' : '<b style="color:#15803d">all checks passed</b>'}<br>
${card.map(c => `${icon(c.status)} <b>${L.esc(c.name)}</b>${c.note ? `: ${L.esc(c.note)}` : ''}`).join('<br>')}</div>`;
}
function merge(card, name, status, note) {
  const old = card.find(c => c.name === name);
  if (!old) card.push({ name, status, note });
  else if (old.status === 'pass' || status === 'warn') Object.assign(old, { status: old.status === 'fixed' && status === 'pass' ? 'fixed' : status, note: note || old.note });
}

async function llmCheck(cfg, sec, system, payload, label) {
  try { return L.parseJSONLoose(await L.llm(cfg, sec, system, JSON.stringify(payload), { temperature: 0.3 })); }
  catch (e) { L.log(`${label} skipped: ${e.message}`); return null; }
}

// ---------------- songs ----------------
const SONG_CHECKS = ['length', 'rhymes', 'story logic', 'tone for ages 2-5', 'the formula', 'viewer moment', 'pictures match the lines', 'originality'];
function songDoctorSystem(cfg, targetS, lineS) {
  const lines = Math.round(targetS / lineS);
  return `You are the Script Doctor of a preschool song channel. Check the song JSON strictly, then return a FIXED version.
CHECKS (return each with pass true/false and a short note):
- length: about ${lines} sung lines in total (target ${Math.round(targetS / 60 * 10) / 10} minutes). If shorter, add verses in the same pattern (a new colour/animal/number) or a final chorus.
- rhymes: in every verse, lines 1-2 rhyme and lines 3-4 rhyme (real rhymes, e.g. high/sky, hen/pen, quack/back).
- story logic: every event has a reason; nobody is suddenly somewhere without cause; searching/finding makes sense.
- tone for ages 2-5: always gentle and happy; no tears, no fear, no one left out for long.
- the formula: nearly identical verses with a clear progression, a learning layer, a happy final verse, a catchy chorus.
- viewer moment: at least one line invites the viewer ("Can you see...? Shout...!").
- pictures match the lines: every "visual" shows exactly what its line says.
- originality: our own characters and twist; not a copy of another channel's version.
${L.houseStyle()}
Reply with ONLY: { "checks": [ { "name": "length", "pass": true, "note": "..." } ], "song": { ...the full fixed song in the same JSON format... } }`;
}

async function song({ cfg, sec, song, normalizeSong, toScenes }) {
  const SG = cfg.song || {};
  const targetS = SG.target_s || 150, lineS = SG.line_s || 3.6;
  const card = [];
  let cur = song;
  for (let round = 1; round <= 2; round++) {
    const sungLines = cur.sections.reduce((t, s) => t + s.lines.length, 0);
    const res = await llmCheck(cfg, sec, songDoctorSystem(cfg, targetS, lineS), { measured: { sung_lines: sungLines, seconds: Math.round(sungLines * lineS) }, song: cur }, `song doctor ${round}`);
    if (!res) break;
    const fails = (res.checks || []).filter(c => c && c.pass === false);
    for (const c of res.checks || []) merge(card, String(c.name), c.pass === false ? 'fixed' : 'pass', c.pass === false ? String(c.note || '') : '');
    if (!fails.length) break;
    try { const fixed = normalizeSong(res.song || {}); if (fixed.sections.length >= cur.sections.length - 1) cur = fixed; } catch (e) { L.log('doctor fix unusable:', e.message); break; }
  }
  // measured length after fixing
  const lines = cur.sections.reduce((t, s) => t + s.lines.length, 0);
  const secs = Math.round(lines * lineS);
  merge(card, 'length', secs >= targetS * 0.8 ? (card.find(c => c.name === 'length' && c.status === 'fixed') ? 'fixed' : 'pass') : 'warn', `${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, '0')} (target ${Math.floor(targetS / 60)}:${String(targetS % 60).padStart(2, '0')})`);
  // Laya: every line, safe + picture match
  const flagged = [];
  let layaOn = false;
  for (const s of cur.sections) for (const l of s.lines) {
    const a = await L.laya(cfg, { line: l.text, picture: l.visual }, {
      unsafe: { type: 'noul', instructions: 'Is this line scary, sad, rude or unkind for a 3-year-old?' },
      match: { type: 'noul', instructions: 'Does the picture show what the line says?' } });
    if (!a) continue;
    layaOn = true;
    if (a.unsafe && a.unsafe.noul > 0.5) flagged.push(`"${l.text}" may feel scary/sad (${Math.round(a.unsafe.noul * 100)}%)`);
    if (a.match && a.match.noul < 0.35) flagged.push(`picture for "${l.text}" may not match (${Math.round(a.match.noul * 100)}%)`);
  }
  if (flagged.length) {
    const res = await llmCheck(cfg, sec, `Fix ONLY these problems in the song and return the full song JSON in the same format:\n${flagged.join('\n')}\n${L.houseStyle()}`, cur, 'laya fix');
    try { if (res) { cur = normalizeSong(res.song || res); merge(card, 'Laya second opinion', 'fixed', flagged.slice(0, 3).join('; ')); } } catch { merge(card, 'Laya second opinion', 'warn', flagged.slice(0, 3).join('; ')); }
  } else if (layaOn) merge(card, 'Laya second opinion', 'pass', 'every line safe and matching its picture');
  cur.scenes = toScenes(cur, lineS);
  cur.doctor = card;
  return cur;
}

// ---------------- stories ----------------
function storyDoctorSystem(cfg) {
  return `You are the Script Doctor of a preschool animation channel. Check the script JSON strictly, then return a FIXED version.
CHECKS (each with pass true/false and a short note):
- story logic: every event has a reason; characters only appear when the story brings them in; the plan's key moments are there.
- tone for ages 2-5: warm, gentle, no fear or lasting sadness, no unkindness.
- the formula: a hook in the first 2 scenes, a clear want, funny tries that grow, a twist, a warm ending.
- viewer moment: at least one moment where a character talks to the viewer.
- pictures match the lines: each image_prompt shows what happens in its lines.
- pronouns and names: consistent for every character.
- dialogue: natural, complete sentences; each character sounds like themselves.
${L.houseStyle()}
Keep the same JSON format, cast ids, voice tags and "sing" flags. Reply with ONLY: { "checks": [ { "name": "...", "pass": true, "note": "..." } ], "script": { ...full fixed script... } }`;
}

async function story({ cfg, sec, script, cast, normalize, minWords }) {
  const card = [];
  let cur = script;
  const res = await llmCheck(cfg, sec, storyDoctorSystem(cfg), cur, 'story doctor');
  if (res) {
    for (const c of res.checks || []) merge(card, String(c.name), c.pass === false ? 'fixed' : 'pass', c.pass === false ? String(c.note || '') : '');
    if ((res.checks || []).some(c => c.pass === false)) {
      try { const fixed = normalize(res.script || {}, cast, cfg); if (fixed.words >= cur.words * 0.9) { fixed.fun = cur.fun; cur = fixed; } } catch (e) { L.log('story fix unusable:', e.message); }
    }
  }
  // measured checks
  merge(card, 'length', cur.words >= (minWords || 0) ? 'pass' : 'warn', `${cur.words} words`);
  const lines = cur.scenes.flatMap(sc => sc.lines);
  const narr = lines.length ? Math.round(lines.filter(l => l.speaker === cast.narrator).length / lines.length * 100) : 0;
  merge(card, 'storyteller share', narr >= 15 && narr <= 40 ? 'pass' : 'warn', `${narr}% of lines`);
  const long = cur.scenes.filter(sc => sc.lines.reduce((t, l) => t + L.stripTags(l.text).split(/\s+/).length, 0) > 26).map(sc => sc.n);
  merge(card, 'short shots', long.length ? 'warn' : 'pass', long.length ? `long scenes: ${long.join(', ')}` : '');
  // Laya per scene
  const flagged = []; let layaOn = false;
  for (const sc of cur.scenes) {
    const a = await L.laya(cfg, { lines: sc.lines.map(l => L.stripTags(l.text)).join(' '), picture: sc.image_prompt }, {
      unsafe: { type: 'noul', instructions: 'Is anything here scary, sad, rude or unkind for a 3-year-old?' },
      match: { type: 'noul', instructions: 'Does the picture show what the lines say?' } });
    if (!a) continue;
    layaOn = true;
    if (a.unsafe && a.unsafe.noul > 0.5) flagged.push(`scene ${sc.n} may feel scary/sad (${Math.round(a.unsafe.noul * 100)}%)`);
    if (a.match && a.match.noul < 0.35) flagged.push(`scene ${sc.n}: picture may not match the lines (${Math.round(a.match.noul * 100)}%)`);
  }
  if (flagged.length) merge(card, 'Laya second opinion', 'warn', flagged.slice(0, 4).join('; '));
  else if (layaOn) merge(card, 'Laya second opinion', 'pass', 'every scene safe and matching its picture');
  cur.doctor = card;
  return cur;
}

module.exports = { song, story, cardHtml, SONG_CHECKS };
