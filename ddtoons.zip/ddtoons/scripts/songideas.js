'use strict';
// usage: node songideas.js ideas <hintB64|-> <mix>          -> 8 researched song ideas, emailed as a numbered list
//        node songideas.js choose <batch> <n> <ownB64|->    -> starts the song job for idea n (or your own idea)
// mix: "mix" | "traditional" | "original"
const fs = require('fs');
const path = require('path');
const L = require('./lib');
const { TRADITIONAL, FORMULA } = require('./song');

// Real numbers from YouTube (secrets.json "youtube_key"): the most-watched kids' songs of the last 6 months (see research.js)
async function youtubeEvidence(cfg, sec) {
  try {
    const d = await require('./research').trending(cfg, sec, { months: (cfg.research && cfg.research.months) || 6 });
    return d.live ? d.items.slice(0, 40) : [];
  } catch (e) { L.log('YouTube research skipped:', e.message); return []; }
}

async function ideas(hint, mix) {
  const { cfg, sec } = L.loadAll();
  const histFile = path.join(L.ROOT, 'ideas_history.json');
  const history = L.readJSON(histFile, []);
  const used = history.map(h => String(h.source || h.title));
  const yt = await youtubeEvidence(cfg, sec);
  const today = new Date().toISOString().slice(0, 10);
  const want = mix === 'traditional' ? '8 traditional rhymes' : mix === 'original' ? '8 original songs' : '4 traditional rhymes and 4 original songs';
  const system = `You are the music researcher and songwriter of "DD TV English", a kids' song channel for ${cfg.script.audience}. Today is ${today}.
${FORMULA}

TASK: research and propose ${want} that are most likely to get views right now.
- Traditional rhymes ONLY from this list (public domain): ${TRADITIONAL.join('; ')}.
- Original songs: new lyrics and ideas, never copied; themes toddlers love or live (routines, animals, vehicles, colours, food, feelings, seasons, festivals coming up soon).
- Prefer themes and rhymes that are popular right now (use the data you are given and any web results), and seasonal moments in the next 4-6 weeks.
- Do NOT propose anything already made: ${used.slice(-60).join('; ') || '(none yet)'}.
- "why": one short sentence. Only quote numbers that appear in the data you were given or in web results; otherwise say why it is evergreen or seasonal. Never invent view counts.

Reply with ONLY this JSON:
{ "ideas": [ { "kind": "traditional|original", "song": "rhyme name, or the original song idea in one sentence",
  "title": "catchy YouTube title", "learning": "counting / colours / animals / body parts / routine / ...", "why": "...", "evidence": [1, 4] } ] }`;
  const row = (v, i) => `#${i + 1} [${v.short ? 'SHORT' : 'LONG'}] "${v.title}" | ${v.channel} | ${v.views.toLocaleString('en')} views | ${v.views_per_day.toLocaleString('en')}/day | ${v.published}`;
  const user = `${hint ? `Showrunner hint: ${hint}\n` : ''}${yt.length ? `Most-watched English kids' song videos of the last 6 months on YouTube (real data, ranked by views per day; the #number is the rank):\n${yt.map(row).join('\n')}\nLook for THEMES that repeat (animals and sounds, habits like brushing teeth, potty, healthy food, sharing; learning like counting, colours, letters) and combine them, as the top videos do.\nFor every idea, list in "evidence" the #rank numbers of the 1-3 videos above that support it (empty list if it is evergreen or seasonal only).` : 'No YouTube data available; use web research and knowledge.'}`;
  let list, lastErr;
  for (let a = 1; a <= 2 && !list; a++) {
    try {
      const j = L.parseJSONLoose(await L.llm(cfg, sec, system, user + (a > 1 ? `\nPrevious reply invalid (${lastErr}). JSON only.` : ''), { temperature: 0.9, web: cfg.research_web !== false }));
      const xs = (j.ideas || []).map(x => ({ kind: /trad/i.test(x.kind) ? 'traditional' : 'original', song: String(x.song || '').trim(), title: String(x.title || x.song || '').trim(),
        learning: String(x.learning || ''), why: String(x.why || ''),
        evidence: (Array.isArray(x.evidence) ? x.evidence : []).map(n => parseInt(String(n).replace('#', ''), 10)).filter(n => n >= 1 && n <= yt.length).slice(0, 3) }))
        .filter(x => x.song && (x.kind === 'original' || TRADITIONAL.some(t => t.toLowerCase() === x.song.toLowerCase() || x.song.toLowerCase().includes(t.toLowerCase().split(' (')[0]))));
      if (xs.length < 4) throw new Error(`only ${xs.length} usable ideas`);
      xs.forEach(x => { x.score = Math.max(0, ...x.evidence.map(n => yt[n - 1].views_per_day)); });
      list = xs.slice(0, 8).sort((a, b) => b.score - a.score);
    } catch (e) { lastErr = e.message; L.log(`ideas attempt ${a}: ${e.message}`); }
  }
  if (!list) throw new Error(`could not research song ideas: ${lastErr}`);
  const batch = `s${new Date().toISOString().slice(2, 16).replace(/[-:T]/g, '')}`;
  const dir = path.join(L.ROOT, 'pitches'); fs.mkdirSync(dir, { recursive: true });
  L.writeJSON(path.join(dir, `${batch}.json`), { batch, created: today, ideas: list });
  const rows = list.map((x, i) => `<tr><td style="padding:8px;vertical-align:top;font-size:20px;color:#7c3aed"><b>${i + 1}</b></td>
<td style="padding:8px"><b>${L.esc(x.title)}</b><br>${x.kind === 'traditional' ? '🎵 Traditional rhyme' : '🎶 Original song'} · ${L.esc(x.learning)}<br>
<span style="color:#555">${L.esc(x.kind === 'original' ? x.song : '')}</span>
<div style="margin:4px 0"><b>${x.score >= 200000 ? '🔥🔥🔥 Very hot' : x.score >= 50000 ? '🔥🔥 Hot' : x.score > 0 ? '🔥 Trending' : '🌱 Evergreen / seasonal'}</b></div>
${x.evidence.map(n => { const v = yt[n - 1]; return `<div style="font-size:13px;color:#0f766e">📊 Rank #${n} · <b>${v.views.toLocaleString('en')} views</b> · ${v.views_per_day.toLocaleString('en')}/day · ${v.short ? 'Short' : 'full song'} · "${L.esc(v.title.slice(0, 70))}" (${L.esc(v.channel)})</div>`; }).join('')}
<div style="color:#888;font-size:13px">💡 ${L.esc(x.why)}</div></td></tr>`).join('');
  const chart = yt.length ? `<p style="margin:16px 0 4px"><b>📈 Top trending right now (last 6 months, ranked by views per day)</b></p>
<table style="border-collapse:collapse;font-size:13px">${yt.slice(0, 12).map((v, i) => `<tr><td style="padding:2px 6px;color:#7c3aed">#${i + 1}</td><td style="padding:2px 6px;text-align:right"><b>${v.views.toLocaleString('en')}</b></td><td style="padding:2px 6px;color:#555">${v.views_per_day.toLocaleString('en')}/day</td><td style="padding:2px 6px">${v.short ? '📱' : '🎬'} ${L.esc(v.title.slice(0, 60))} <span style="color:#888">(${L.esc(v.channel)})</span></td></tr>`).join('')}</table>` : '';
  return { ok: true, batch, notify_email: cfg.notify_email, subject: 'DD TV English: 8 song ideas to choose from',
    email_html: `<div style="font-family:Arial,sans-serif;max-width:720px"><p>Here are 8 researched song ideas${yt.length ? ' (based on real YouTube view data)' : ''}. Pick one in the next email, ask for 8 new ones, or type your own.</p>
<table style="border-collapse:collapse">${rows}</table>${chart}
<p style="color:#888;font-size:12px">🎬 = full song · 📱 = Short. Ideas are sorted by trend strength. Numbers are real YouTube data from the last 6 months.</p></div>` };
}

async function choose(batch, n, own) {
  const { cfg } = L.loadAll();
  let brief;
  if (own) {
    const trad = TRADITIONAL.find(t => own.toLowerCase().includes(t.toLowerCase().split(' (')[0]));
    brief = { kind: 'song', song_kind: trad ? 'traditional' : 'original', song: trad || own, learning: '', notes: own };
  } else {
    const data = L.readJSON(path.join(L.ROOT, 'pitches', `${batch}.json`));
    const x = data.ideas[(parseInt(n, 10) || 1) - 1];
    if (!x) throw new Error(`no idea ${n} in ${batch}`);
    brief = { kind: 'song', song_kind: x.kind, song: x.song, learning: x.learning, notes: `Title idea: ${x.title}` };
  }
  const histFile = path.join(L.ROOT, 'ideas_history.json');
  const history = L.readJSON(histFile, []);
  history.push({ date: new Date().toISOString().slice(0, 10), title: brief.song.slice(0, 60), source: brief.song_kind === 'traditional' ? brief.song : 'original song', lesson: brief.learning });
  L.writeJSON(histFile, history.slice(-300));
  const slug = brief.song.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 22).replace(/-+$/, '') || 'song';
  return { ok: true, kind: 'song', jobId: `dd_${new Date().toISOString().slice(2, 16).replace(/[-:T]/g, '')}_song-${slug}`,
    briefB64: Buffer.from(JSON.stringify(brief)).toString('base64'), feedbackB64: '', notify_email: cfg.notify_email };
}

L.main(async () => {
  const [mode, a1, a2, a3] = process.argv.slice(2);
  if (mode === 'ideas') return ideas(L.b64d(a1 || ''), a2 || 'mix');
  if (mode === 'choose') return choose(a1, a2, L.b64d(a3 || ''));
  throw new Error('use: ideas | choose');
});
