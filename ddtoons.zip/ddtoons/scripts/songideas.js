'use strict';
// usage: node songideas.js ideas <hintB64|-> <mix>          -> 8 researched song ideas, emailed as a numbered list
//        node songideas.js choose <batch> <n> <ownB64|->    -> starts the song job for idea n (or your own idea)
// mix: "mix" | "traditional" | "original"
const fs = require('fs');
const path = require('path');
const L = require('./lib');
const { TRADITIONAL, FORMULA } = require('./song');

// Real numbers from YouTube (secrets.json "youtube_key"): the most-watched kids' songs of the last 6 months (see research.js)
async function youtubeEvidence(cfg, sec) {
  try {
    const d = await require('./research').trending(cfg, sec, { months: (cfg.research && cfg.research.months) || 3 });
    return d.live ? d.items.slice(0, 40) : [];
  } catch (e) { L.log('YouTube research skipped:', e.message); return []; }
}

async function ideas(hint, mix) {
  const { cfg, sec } = L.loadAll();
  const histFile = path.join(L.ROOT, 'ideas_history.json');
  const history = L.readJSON(histFile, []);
  const used = history.map(h => String(h.source || h.title));
  const yt = await youtubeEvidence(cfg, sec);
  const today = new Date().toISOString().slice(0, 10);
  const months = (cfg.research && cfg.research.months) || 3;
  const want = mix === 'traditional' ? '8 traditional rhymes' : mix === 'original' ? '8 original songs' : '4 traditional rhymes and 4 original songs';
  const system = `You are the music researcher and songwriter of "DD TV English", a kids' song channel for ${cfg.script.audience}. Today is ${today}.
${FORMULA}

TASK: research and propose ${want} that are most likely to get views right now.
- Traditional rhymes ONLY from this list (public domain): ${TRADITIONAL.join('; ')}.
- Original songs: new lyrics and ideas, never copied; themes toddlers love or live (routines, animals, vehicles, colours, food, feelings, seasons, festivals coming up soon).
- Prefer themes and rhymes that are popular right now (use the data you are given and any web results), and seasonal moments in the next 4-6 weeks.
- Do NOT propose anything already made: ${used.slice(-60).join('; ') || '(none yet)'}.
- "why": one short sentence. Only quote numbers that appear in the data you were given or in web results; otherwise say why it is evergreen or seasonal. Never invent view counts.

Reply with ONLY this JSON:
{ "ideas": [ { "kind": "traditional|original", "song": "rhyme name, or the original song idea in one sentence",
  "title": "catchy YouTube title", "learning": "counting / colours / animals / body parts / routine / ...", "why": "...", "evidence": [ { "rank": 1, "match": "same_song|same_theme|loose" } ] } ] }
"match": same_song = the video is the same song/rhyme; same_theme = a different song on the same topic or learning theme; loose = only loosely related.
${L.houseStyle()}`;
  const row = (v, i) => `#${i + 1} [${v.short ? 'SHORT' : 'FULL SONG'}] "${v.title}" | ${v.channel} | ${L.fmtM(v.views)} views | ${L.fmtM(v.views_per_day)}/day | ${v.published}`;
  const user = `${hint ? `Showrunner hint: ${hint}\n` : ''}${yt.length ? `Most-watched English kids' song videos of the last ${months} months on YouTube (real data, ranked by total views; the #number is the rank):\n${yt.map(row).join('\n')}\nLook for THEMES that repeat (animals and sounds, habits like brushing teeth, potty, healthy food, sharing; learning like counting, colours, letters) and combine them, as the top videos do.\nFor every idea, list in "evidence" the 1-3 videos above that support it, with how closely each matches (empty list if it is evergreen or seasonal only). We make FULL SONGS, so full-song evidence of the same song is the strongest.` : 'No YouTube data available; use web research and knowledge.'}`;
  let list, lastErr;
  for (let a = 1; a <= 2 && !list; a++) {
    try {
      const j = L.parseJSONLoose(await L.llm(cfg, sec, system, user + (a > 1 ? `\nPrevious reply invalid (${lastErr}). JSON only.` : ''), { temperature: 0.9, web: cfg.research_web !== false }));
      const xs = (j.ideas || []).map(x => ({ kind: /trad/i.test(x.kind) ? 'traditional' : 'original', song: String(x.song || '').trim(), title: String(x.title || x.song || '').trim(),
        learning: String(x.learning || ''), why: String(x.why || ''),
        evidence: (Array.isArray(x.evidence) ? x.evidence : []).map(e => {
          const n = parseInt(String(typeof e === 'object' ? e.rank : e).replace('#', ''), 10);
          const m = String(typeof e === 'object' ? e.match : '').toLowerCase();
          return { n, match: /same.?song/.test(m) ? 'same_song' : /theme/.test(m) ? 'same_theme' : 'loose' };
        }).filter(e => e.n >= 1 && e.n <= yt.length).slice(0, 3) }))
        .filter(x => x.song && (x.kind === 'original' || TRADITIONAL.some(t => t.toLowerCase() === x.song.toLowerCase() || x.song.toLowerCase().includes(t.toLowerCase().split(' (')[0]))));
      if (xs.length < 4) throw new Error(`only ${xs.length} usable ideas`);
      list = xs.slice(0, 8);
    } catch (e) { lastErr = e.message; L.log(`ideas attempt ${a}: ${e.message}`); }
  }
  if (!list) throw new Error(`could not research song ideas: ${lastErr}`);
  let layaUsed = false;
  for (const x of list) {
    if (!x.evidence.length) continue;
    const q = {};
    x.evidence.forEach((e, i) => { q[`v${i}`] = { type: 'choice', instructions: `How does this YouTube video relate to the song idea? Video: "${yt[e.n - 1].title.slice(0, 120)}"`,
      criteria: { same_song: 'it is the same song or rhyme', same_theme: 'a different song with the same topic or learning theme', loose: 'only loosely related or unrelated' } }; });
    const ans = await L.laya(cfg, { song_idea: `${x.title}. ${x.kind === 'traditional' ? 'Traditional rhyme: ' : ''}${x.song}. Learning: ${x.learning}` }, q);
    if (ans) { layaUsed = true; x.evidence.forEach((e, i) => { const a = ans[`v${i}`]; if (a && a.choice) { e.match = a.choice; e.p = Math.round(Math.max(...Object.values(a.probabilities || { x: 0 })) * 100); } }); }
  }
  // score: full-song evidence counts 4x a Short; same song 1, same theme 0.5, loose 0.1
  const W = { same_song: 1, same_theme: 0.5, loose: 0.1 };
  for (const x of list) {
    x.score = Math.max(0, ...x.evidence.map(e => yt[e.n - 1].views * W[e.match] * (yt[e.n - 1].short ? 0.25 : 1)));
    const strong = x.evidence.filter(e => e.match !== 'loose').map(e => yt[e.n - 1]);
    const bestFull = Math.max(0, ...strong.filter(v => !v.short).map(v => v.views));
    const bestShort = Math.max(0, ...strong.filter(v => v.short).map(v => v.views));
    x.heat = !x.evidence.length ? '🌱 Evergreen / seasonal'
      : !strong.length ? '🔸 Weak evidence (loose links only)'
      : bestFull >= 50e6 || bestShort >= 300e6 ? '🔥🔥🔥 Very hot' : bestFull >= 10e6 || bestShort >= 80e6 ? '🔥🔥 Hot' : '🔥 Trending';
  }
  list.sort((a, b) => b.score - a.score);
  const batch = `s${new Date().toISOString().slice(2, 16).replace(/[-:T]/g, '')}`;
  const dir = path.join(L.ROOT, 'pitches'); fs.mkdirSync(dir, { recursive: true });
  L.writeJSON(path.join(dir, `${batch}.json`), { batch, created: today, ideas: list });
  const rows = list.map((x, i) => `<tr><td style="padding:8px;vertical-align:top;font-size:20px;color:#7c3aed"><b>${i + 1}</b></td>
<td style="padding:8px"><b>${L.esc(x.title)}</b><br>${x.kind === 'traditional' ? '🎵 Traditional rhyme' : '🎶 Original song'} · ${L.esc(x.learning)}<br>
<span style="color:#555">${L.esc(x.kind === 'original' ? x.song : '')}</span>
<div style="margin:4px 0"><b>${x.heat}</b></div>
${x.evidence.map(e => { const v = yt[e.n - 1]; const tag = { same_song: '✅ same song', same_theme: '🟡 same theme', loose: '⚪ loose link' }[e.match]; return `<div style="font-size:13px;color:#0f766e">📊 #${e.n} · <b>${L.fmtM(v.views)} views</b> · ${v.short ? '📱 Short' : '🎬 full song'} · <b>${tag}</b>${e.p ? ` <span style="color:#888">(Laya ${e.p}%)</span>` : ''} · "${L.esc(v.title.slice(0, 70))}" (${L.esc(v.channel)})</div>`; }).join('')}
<div style="color:#888;font-size:13px">💡 ${L.esc(x.why)}</div></td></tr>`).join('');
  const chart = yt.length ? `<p style="margin:16px 0 4px"><b>📈 Most viewed right now (last ${months} months, ranked by views)</b></p>
<table style="border-collapse:collapse;font-size:13px">${yt.slice(0, 12).map((v, i) => `<tr><td style="padding:2px 6px;color:#7c3aed">#${i + 1}</td><td style="padding:2px 6px;text-align:right"><b>${L.fmtM(v.views)}</b></td><td style="padding:2px 6px;color:#555">${L.fmtM(v.views_per_day)}/day</td><td style="padding:2px 6px">${v.short ? '📱' : '🎬'} ${L.esc(v.title.slice(0, 60))} <span style="color:#888">(${L.esc(v.channel)})</span></td></tr>`).join('')}</table>` : '';
  return { ok: true, batch, notify_email: cfg.notify_email, subject: 'DD TV English: 8 song ideas to choose from',
    email_html: `<div style="font-family:Arial,sans-serif;max-width:720px"><p>Here are 8 researched song ideas${yt.length ? ' (based on real YouTube view data)' : ''}. Pick one in the next email, ask for 8 new ones, or type your own.</p>
<table style="border-collapse:collapse">${rows}</table>${chart}
<p style="color:#888;font-size:12px">🎬 = full song · 📱 = Short. Ideas are sorted by evidence strength (full songs of the same song count most). Real YouTube data from the last ${months} months.${layaUsed ? ' Evidence links double-checked by Laya.' : ''}</p></div>` };
}

async function choose(batch, n, own) {
  const { cfg } = L.loadAll();
  let brief;
  if (own) {
    const trad = TRADITIONAL.find(t => own.toLowerCase().includes(t.toLowerCase().split(' (')[0]));
    brief = { kind: 'song', song_kind: trad ? 'traditional' : 'original', song: trad || own, learning: '', notes: own };
  } else {
    const data = L.readJSON(path.join(L.ROOT, 'pitches', `${batch}.json`));
    const x = data.ideas[(parseInt(n, 10) || 1) - 1];
    if (!x) throw new Error(`no idea ${n} in ${batch}`);
    brief = { kind: 'song', song_kind: x.kind, song: x.song, learning: x.learning, notes: `Title idea: ${x.title}` };
  }
  const histFile = path.join(L.ROOT, 'ideas_history.json');
  const history = L.readJSON(histFile, []);
  history.push({ date: new Date().toISOString().slice(0, 10), title: brief.song.slice(0, 60), source: brief.song_kind === 'traditional' ? brief.song : 'original song', lesson: brief.learning });
  L.writeJSON(histFile, history.slice(-300));
  const slug = brief.song.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 22).replace(/-+$/, '') || 'song';
  return { ok: true, kind: 'song', jobId: `dd_${new Date().toISOString().slice(2, 16).replace(/[-:T]/g, '')}_song-${slug}`,
    briefB64: Buffer.from(JSON.stringify(brief)).toString('base64'), feedbackB64: '', notify_email: cfg.notify_email };
}

L.main(async () => {
  const [mode, a1, a2, a3] = process.argv.slice(2);
  if (mode === 'ideas') return ideas(L.b64d(a1 || ''), a2 || 'mix');
  if (mode === 'choose') return choose(a1, a2, L.b64d(a3 || ''));
  throw new Error('use: ideas | choose');
});
