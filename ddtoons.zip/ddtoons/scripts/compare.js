'use strict';
// usage: node compare.js compare <jobId>      -> writes the episode with every writer in config.tryout, emails them blind (A, B, ...)
//        node compare.js pick <jobId> <A|B>   -> uses that script for the episode and makes that model the default writer
const fs = require('fs');
const path = require('path');
const L = require('./lib');
const { draft } = require('./write_script');

const secs = s => Math.round(s.words / 2.1 + s.scenes.length * 1.2);
const mmss = n => `${Math.floor(n / 60)}m ${n % 60}s`;
const narr = (s, n) => { const l = s.scenes.flatMap(x => x.lines); return l.length ? Math.round(l.filter(x => x.speaker === n).length / l.length * 100) : 0; };

L.main(async () => {
  const [action, jobId, pickLabel] = process.argv.slice(2);
  const dir = L.jobDir(jobId);
  const { cfg, cast: family, sec } = L.loadAll();
  const cast = L.castFor(cfg, family, L.seriesOf(jobId));
  const tdir = path.join(dir, 'tryout');
  const name = Object.fromEntries(cast.characters.map(c => [c.id, c.name]));

  if (action === 'compare') {
    const brief = L.readJSON(path.join(dir, 'brief.json'), null);
    if (!brief) throw new Error(`job ${jobId} has no brief yet: write its script once first (Resume form, "write script")`);
    const writers = ((cfg.tryout && cfg.tryout.writers) || []).slice(0, 4);
    if (writers.length < 2) throw new Error('config.tryout.writers needs at least 2 writers');
    const labels = ['A', 'B', 'C', 'D'].slice(0, writers.length).sort(() => Math.random() - 0.5);
    fs.rmSync(tdir, { recursive: true, force: true }); fs.mkdirSync(tdir, { recursive: true });
    const key = {}; const blocks = [];
    for (const [i, w] of writers.entries()) {
      const label = labels[i];
      key[label] = w;
      const c2 = JSON.parse(JSON.stringify(cfg));
      c2.llm.provider = w.provider;
      if (w.provider === 'openrouter') c2.llm.openrouter_model = w.model; else c2.llm.ollama_model = w.model;
      L.log(`writer ${label} starting`);
      try {
        const s = await draft(c2, cast, sec, brief, null, '');
        L.writeJSON(path.join(tdir, `${label}.json`), s);
        const rows = s.scenes.map(sc => `<tr><td style="color:#999;vertical-align:top;padding:3px 6px">${sc.n}</td><td style="padding:3px 6px">${sc.lines.map(l => `<b>${L.esc(name[l.speaker] || l.speaker)}:</b> ${L.esc(l.text)}`).join('<br>')}</td></tr>`).join('');
        blocks.push({ label, html: `<h2 style="margin:24px 0 4px">✍️ Writer ${label}</h2>
<p style="margin:0 0 8px;color:#555">${L.esc(s.title)} · ${s.scenes.length} scenes · ${s.words} words · ≈ ${mmss(secs(s))} · storyteller ${narr(s, cast.narrator)}% of lines</p>
<table style="border-collapse:collapse;font-size:15px">${rows}</table>` });
      } catch (e) {
        blocks.push({ label, html: `<h2>✍️ Writer ${label}</h2><p style="color:#b91c1c">Could not write: ${L.esc(e.message)}</p>` });
      }
    }
    L.writeJSON(path.join(tdir, 'key.json'), key);
    blocks.sort((a, b) => a.label.localeCompare(b.label));
    return { ok: true, notify_email: cfg.notify_email, subject: `DD TV English writer tryout: ${jobId}`,
      email_html: `<div style="font-family:Arial,sans-serif;max-width:780px">
<p>The same story, written by ${blocks.length} different writers. Names are hidden so you judge only the story.
Read them aloud like you would to a 4-year-old. Which one would a child want to hear again?</p>
<p><b>To choose:</b> open the Writer Tryout form → Job ID <code>${jobId}</code> → Action <b>pick A</b> or <b>pick B</b>. The winner's script is used for this episode and becomes the default writer.</p>
${blocks.map(b => b.html).join('<hr style="margin:24px 0">')}</div>` };
  }

  if (action === 'pick') {
    const label = String(pickLabel || '').toUpperCase();
    const key = L.readJSON(path.join(tdir, 'key.json'), null);
    if (!key || !key[label]) throw new Error(`no writer ${label} in the last tryout for ${jobId}`);
    const script = L.readJSON(path.join(tdir, `${label}.json`), null);
    if (!script) throw new Error(`writer ${label} did not produce a script`);
    // install the chosen script as a new version (earlier production is archived, nothing deleted)
    const st = L.readJSON(path.join(dir, 'status.json'), {});
    const version = (st.version || 0) + 1;
    const made = fs.readdirSync(dir).filter(x => /^(scene_|line_|short_|thumbnail|final|body|concat|bumper_|metadata|shots\.json)/.test(x));
    if (made.length) {
      const arch = path.join(dir, `archive_v${st.version || 0}`);
      fs.mkdirSync(arch, { recursive: true });
      for (const x of made) fs.renameSync(path.join(dir, x), path.join(arch, x));
    }
    script.version = version;
    L.writeJSON(path.join(dir, `script_v${version}.json`), script);
    L.writeJSON(path.join(dir, 'script.json'), script);
    L.setStatus(dir, { stage: 'script_picked', version, title: script.title });
    // make the winner the default writer
    const cfgPath = path.join(L.ROOT, 'config', 'config.json');
    const c = L.readJSON(cfgPath); const w = key[label];
    c.llm.provider = w.provider;
    if (w.provider === 'openrouter') c.llm.openrouter_model = w.model; else c.llm.ollama_model = w.model;
    L.writeJSON(cfgPath, c);
    const reveal = Object.entries(key).sort().map(([k, v]) => `Writer ${k} = <b>${L.esc(v.model)}</b>${k === label ? ' ✅ your pick' : ''}`).join('<br>');
    return { ok: true, notify_email: cfg.notify_email, subject: `DD TV English: you picked writer ${label}`,
      email_html: `<div style="font-family:Arial,sans-serif"><p>${reveal}</p>
<p><b>${L.esc(w.model)}</b> is now the default writer for all new stories.</p>
<p>Script v${version} ("${L.esc(script.title)}") is ready for job <code>${jobId}</code>.<br>
<b>Next:</b> open the Resume Production form → Job ID <code>${jobId}</code> → Action <b>resume production</b> to make the video.</p></div>` };
  }
  throw new Error(`unknown action "${action}" (use compare or pick)`);
});
