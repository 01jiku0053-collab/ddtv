'use strict';
// DD TV English shared helpers. Zero npm dependencies (runs on the Node that ships with n8n).
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');

const ROOT = process.env.DD_ROOT || '/data/ddtoons';
const SECRETS = process.env.DD_SECRETS || '/data/secrets.json';
const RW_URL = process.env.RW_URL || 'https://api.runware.ai/v1';
const EL_BASE = process.env.EL_BASE || 'https://api.elevenlabs.io';

const log = (...a) => console.error(new Date().toISOString().slice(11, 19), ...a);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const uuid = () => crypto.randomUUID();

function readJSON(p, def) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); }
  catch (e) { if (def !== undefined) return def; throw new Error(`cannot read ${p}: ${e.message}`); }
}
function writeJSON(p, o) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p + '.tmp', JSON.stringify(o, null, 2));
  fs.renameSync(p + '.tmp', p);
}
function loadAll() {
  const cfg = readJSON(path.join(ROOT, 'config', 'config.json'));
  const cast = readJSON(path.join(ROOT, 'config', 'characters.json'));
  const sec = readJSON(process.env.DD_SECRETS || cfg.paths.secrets || SECRETS, {});
  return { cfg, cast, sec };
}
function jobDir(id) {
  if (!/^[a-z0-9_-]+$/i.test(id || '')) throw new Error(`bad job id "${id}"`);
  return path.join(ROOT, 'jobs', id);
}
function setStatus(dir, patch) {
  const p = path.join(dir, 'status.json');
  writeJSON(p, { ...readJSON(p, {}), ...patch, updated: new Date().toISOString() });
}
// Every script prints exactly one JSON object as its last stdout line and exits 0,
// so n8n's Execute Command node never hard-fails; the workflow routes on `ok`.
function finish(obj) { process.stdout.write('\n' + JSON.stringify(obj) + '\n'); process.exit(0); }
function main(fn) {
  fn().then(finish).catch(e => {
    log('FATAL', e.stack || e.message);
    let notify_email = '';
    try { notify_email = readJSON(path.join(ROOT, 'config', 'config.json')).notify_email; } catch { /* config unreadable */ }
    finish({ ok: false, jobId: process.argv[2] || '', notify_email, error: String(e.message || e).slice(0, 1500) });
  });
}
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const b64d = s => (!s || s === '-') ? '' : Buffer.from(s, 'base64').toString('utf8');

async function fetchT(url, opts = {}, ms = 120000) {
  const c = new AbortController(); const t = setTimeout(() => c.abort(), ms);
  try { return await fetch(url, { ...opts, signal: c.signal }); } finally { clearTimeout(t); }
}
async function retry(fn, tries = 3, label = 'call') {
  let last;
  for (let i = 1; i <= tries; i++) {
    try { return await fn(i); } catch (e) { last = e; log(`${label} attempt ${i}/${tries} failed: ${e.message}`); if (i < tries) await sleep(3000 * i); }
  }
  throw last;
}
async function download(url, file) {
  const r = await fetchT(url, {}, 300000);
  if (!r.ok) throw new Error(`download ${r.status} ${url.slice(0, 80)}`);
  fs.writeFileSync(file + '.part', Buffer.from(await r.arrayBuffer()));
  fs.renameSync(file + '.part', file);
}
// Run async jobs with a concurrency limit.
async function pool(items, n, fn) {
  const out = []; let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => {
    while (i < items.length) { const k = i++; out[k] = await fn(items[k], k); }
  }));
  return out;
}

// ---------- LLM (Ollama by default, OpenRouter optional) ----------
async function llm(cfg, sec, system, user, { temperature = 0.8 } = {}) {
  const L = cfg.llm;
  if (L.provider === 'openrouter') {
    if (!sec.openrouter_key) throw new Error('llm.provider is "openrouter" but secrets.json has no openrouter_key');
    const r = await fetchT(process.env.OPENROUTER_URL || 'https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST', headers: { Authorization: `Bearer ${sec.openrouter_key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: L.openrouter_model, temperature, response_format: { type: 'json_object' },
        messages: [{ role: 'system', content: system }, { role: 'user', content: user }] }),
    }, 600000);
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(`openrouter ${r.status}: ${JSON.stringify(j).slice(0, 300)}`);
    return j.choices?.[0]?.message?.content || '';
  }
  const r = await fetchT(process.env.OLLAMA_URL || L.ollama_url, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: L.ollama_model, stream: false, format: 'json', options: { temperature, num_predict: 16000 },
      messages: [{ role: 'system', content: system }, { role: 'user', content: user }] }),
  }, 900000);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`ollama ${r.status}: ${JSON.stringify(j).slice(0, 300)}`);
  const m = j.message || {};
  return (m.content && m.content.trim()) ? m.content : (m.thinking || '');
}
function parseJSONLoose(text) {
  const t = String(text).replace(/<think>[\s\S]*?<\/think>/g, '').replace(/```(?:json)?/g, '').trim();
  const a = t.indexOf('{'), b = t.lastIndexOf('}');
  if (a < 0 || b <= a) throw new Error('model returned no JSON object');
  return JSON.parse(t.slice(a, b + 1));
}

// ---------- Runware ----------
async function runware(sec, tasks, ms = 180000) {
  if (!sec.runware_key) throw new Error('secrets.json has no runware_key');
  const r = await fetchT(RW_URL, { method: 'POST',
    headers: { Authorization: `Bearer ${sec.runware_key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(tasks) }, ms);
  const j = await r.json().catch(() => ({}));
  const errors = j.errors || (r.ok ? [] : [{ message: `HTTP ${r.status}` }]);
  return { status: r.status, data: j.data || [], errors };
}
function fileToDataURI(file) {
  return 'data:image/jpeg;base64,' + fs.readFileSync(file).toString('base64');
}
// Generates one image. With references it tries the current Seedream syntax
// (inputs.referenceImages), then the legacy top-level referenceImages, then text-only.
async function genImage(cfg, sec, { prompt, refs = [], width, height, file }) {
  const I = cfg.image;
  const base = { taskType: 'imageInference', model: I.model, positivePrompt: prompt.slice(0, 1990),
    width: width || I.width, height: height || I.height, numberResults: 1,
    outputType: 'URL', outputFormat: 'JPG', includeCost: true };
  const variants = refs.length
    ? [{ ...base, inputs: { referenceImages: refs } }, { ...base, referenceImages: refs }, base]
    : [base];
  let lastErr = '';
  for (const [k, t] of variants.entries()) {
    const r = await runware(sec, [{ ...t, taskUUID: uuid() }]);
    const d = r.data.find(x => x.imageURL);
    if (d) {
      await download(d.imageURL, file);
      fs.writeFileSync(file.replace(/\.jpg$/, '.url'), d.imageURL);
      const usedRefs = refs.length > 0 && k < 2;
      if (refs.length && !usedRefs) log(`WARNING ${path.basename(file)} made WITHOUT character references (both reference syntaxes rejected)`);
      return { cost: d.cost || 0, usedRefs };
    }
    lastErr = JSON.stringify(r.errors).slice(0, 400);
    log(`image variant ${k + 1} rejected: ${lastErr}`);
    if (r.status === 401 || r.status === 402) break;
  }
  throw new Error(`Runware image failed: ${lastErr}`);
}
function imageInputFor(file) {
  const u = file.replace(/\.jpg$/, '.url');
  // Runware result URLs are temporary; reuse them only while fresh.
  if (fs.existsSync(u) && Date.now() - fs.statSync(u).mtimeMs < 6 * 3600e3) return fs.readFileSync(u, 'utf8').trim();
  return fileToDataURI(file);
}
async function submitVideo(cfg, sec, { imageFile, prompt, duration }) {
  const V = cfg.video; const taskUUID = uuid();
  const r = await runware(sec, [{ taskType: 'videoInference', taskUUID, model: V.model,
    positivePrompt: prompt.slice(0, 1990), duration: duration || V.duration, width: V.width, height: V.height,
    frameImages: [{ inputImage: imageInputFor(imageFile), frame: 'first' }],
    deliveryMethod: 'async', outputType: 'URL', outputFormat: 'MP4', includeCost: true }]);
  if (r.errors.length) throw new Error(JSON.stringify(r.errors).slice(0, 300));
  return taskUUID;
}

// ---------- ElevenLabs ----------
const stripTags = t => String(t).replace(/\[[^\]]{1,30}\]/g, ' ').replace(/\s+/g, ' ').trim();
async function elPost(sec, pathQ, body, file, ms = 300000) {
  if (!sec.elevenlabs_key) throw new Error('secrets.json has no elevenlabs_key');
  const r = await fetchT(`${EL_BASE}${pathQ}`, {
    method: 'POST', headers: { 'xi-api-key': sec.elevenlabs_key, 'Content-Type': 'application/json', Accept: 'audio/mpeg' },
    body: JSON.stringify(body) }, ms);
  if (!r.ok) throw new Error(`ElevenLabs ${r.status}: ${(await r.text()).slice(0, 300)}`);
  fs.writeFileSync(file + '.part', Buffer.from(await r.arrayBuffer()));
  fs.renameSync(file + '.part', file);
}
// Speech. With an expressive model (eleven_v3) the [acting tags] in the text are performed;
// if that model fails, it falls back to the stable model with the tags removed.
async function tts(cfg, sec, { text, voiceId, file }) {
  const E = cfg.voice;
  const q = `/v1/text-to-speech/${voiceId}?output_format=mp3_44100_128`;
  if (E.expressive_model) {
    try { return await elPost(sec, q, { text, model_id: E.expressive_model, voice_settings: E.expressive_settings || { stability: 0.5 } }, file, 180000); }
    catch (e) { log(`expressive voice failed, using ${E.model}: ${e.message.slice(0, 120)}`); }
  }
  return elPost(sec, q, { text: stripTags(text), model_id: E.model, voice_settings: E.settings }, file, 180000);
}
async function soundEffect(sec, { text, seconds, file }) {
  return elPost(sec, '/v1/sound-generation', { text, duration_seconds: seconds, prompt_influence: 0.5 }, file, 120000);
}
// Music. Tries a composition plan (so the lyrics are sung exactly), then a plain prompt.
async function music(sec, { prompt, lyrics, styles, ms, file }) {
  const plan = lyrics && lyrics.length ? { positive_global_styles: styles, negative_global_styles: ['scary', 'sad', 'explicit'],
    sections: [{ section_name: 'Song', positive_local_styles: styles, negative_local_styles: [], duration_ms: ms, lines: lyrics }] } : null;
  if (plan) {
    try { return await elPost(sec, '/v1/music?output_format=mp3_44100_128', { composition_plan: plan, model_id: 'music_v1' }, file, 600000); }
    catch (e) { log('music with composition plan failed, trying prompt:', e.message.slice(0, 160)); }
  }
  return elPost(sec, '/v1/music?output_format=mp3_44100_128', { prompt: prompt + (lyrics && lyrics.length ? ` Lyrics: ${lyrics.join(' / ')}` : ''), music_length_ms: ms, model_id: 'music_v1' }, file, 600000);
}

// ---------- ffmpeg ----------
function ffmpegBin(cfg) { return process.env.FFMPEG || cfg.paths.ffmpeg; }
function ffRaw(bin, args, timeoutMs = 3600e3) {
  return new Promise(res => {
    const p = spawn(bin, ['-hide_banner', '-nostdin', ...args]); let err = '';
    const t = setTimeout(() => p.kill('SIGKILL'), timeoutMs);
    p.stderr.on('data', d => { err += d; if (err.length > 200000) err = err.slice(-100000); });
    p.on('close', code => { clearTimeout(t); res({ code, err }); });
    p.on('error', e => { clearTimeout(t); res({ code: -1, err: String(e) }); });
  });
}
async function ff(bin, args, label = 'ffmpeg') {
  const { code, err } = await ffRaw(bin, ['-y', '-loglevel', 'error', ...args]);
  if (code !== 0) throw new Error(`${label} failed (${code}): ${err.slice(-800)}`);
}
async function duration(bin, file) {
  const { err } = await ffRaw(bin, ['-i', file]);
  const m = err.match(/Duration:\s*(\d+):(\d+):([\d.]+)/);
  if (!m) throw new Error(`cannot read duration of ${file}`);
  return (+m[1]) * 3600 + (+m[2]) * 60 + parseFloat(m[3]);
}
async function hasAudio(bin, file) { const { err } = await ffRaw(bin, ['-i', file]); return /Stream #.*Audio:/.test(err); }

// ---------- series + cast ----------
// Episode job ids look like <seriesId>_e<n>; the series folder holds bible.json + character pictures.
function seriesOf(jobId) {
  const m = /^(.+)_e([1-5])$/.exec(jobId || '');
  if (!m) return null;
  const dir = path.join(ROOT, 'series', m[1]);
  if (!fs.existsSync(path.join(dir, 'bible.json'))) return null;
  return { id: m[1], dir, ep: +m[2], bible: readJSON(path.join(dir, 'bible.json')), brief: readJSON(path.join(dir, 'brief.json')) };
}
// Picks voice ids from config.voice.pool by voice_type; two characters of the same type get different voices when the pool has several.
function assignVoices(cfg, chars) {
  const pool = (cfg.voice && cfg.voice.pool) || {}; const used = {};
  return chars.map(c => {
    if (c.voice_id) return c;
    const list = [].concat(pool[c.voice_type] || []).filter(Boolean);
    const k = used[c.voice_type] = (used[c.voice_type] || 0) + 1;
    return { ...c, voice_id: list.length ? list[(k - 1) % list.length] : '' };
  });
}
// The cast for a job: family characters (per the series cast mode) + the series' own characters.
// Every character gets `ref`: the path of its locked reference picture.
function castFor(cfg, family, series) {
  const famRef = c => ({ ...c, source: 'family', ref: path.join(ROOT, 'assets', 'characters', `${c.id}.jpg`) });
  if (!series) return { narrator: family.narrator, characters: family.characters.map(famRef) };
  const mode = series.brief.cast || 'new';
  const fam = family.characters.filter(c => mode !== 'new' || c.id === family.narrator).map(famRef);
  const own = assignVoices(cfg, (series.bible.characters || []).map(c => ({ ...c, source: 'series', ref: path.join(series.dir, 'characters', `${c.id}.jpg`) })));
  return { narrator: family.narrator, characters: [...fam, ...own] };
}

module.exports = { seriesOf, castFor, assignVoices, ROOT, log, sleep, uuid, readJSON, writeJSON, loadAll, jobDir, setStatus, main, esc, b64d,
  fetchT, retry, download, pool, llm, parseJSONLoose, runware, fileToDataURI, genImage, submitVideo, tts, stripTags, soundEffect, music, elPost,
  ffmpegBin, ffRaw, ff, duration, hasAudio };
