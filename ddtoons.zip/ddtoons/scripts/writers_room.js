'use strict';
// The writers' room: 1) beat plan  2) script written from the beats  3) "fun editor" that scores the
// script against what keeps small kids watching and rewrites it until it scores well enough.
const L = require('./lib');

const CRAFT = `WHAT MAKES KIDS KEEP WATCHING (follow all of it)
- HOOK: the first 2 scenes grab attention with something surprising, funny or a question to the viewer. No slow "once upon a time" warm-up.
- WANT: the hero clearly WANTS something small and concrete, says it out loud, and we feel why it matters.
- THREE TRIES: the hero tries and fails in funny ways, three times, each try bigger and sillier than the last.
- COMEDY: physical, visual comedy every few scenes: a character stuck, a bounce, a splash, a wobble, a funny face, a surprise sound (BOING! SPLAT! WHOOSH!).
- STORYTELLER + DIALOGUE: about a quarter of the lines belong to the storyteller: warm, flowing, full sentences that set the scene and carry the feelings, the way a grandmother reads aloud. The rest is characters TALKING to each other in natural, complete sentences (not one-word headlines).
- RUNNER: one catchy repeated line, chant or mini-song that returns at least 3 times and grows each time; the ending pays it off.
- VIEWER: 2-3 moments where a character asks the viewer to help ("Can you see it? Shout 'Up there!'"), then pause and react.
- TWIST: just before the end, a surprise that turns the problem upside down.
- HEART: one small, warm, felt moment; the lesson is SHOWN by what happens; it is said plainly once, at most.
- PACE: something visible changes in every scene; never two quiet scenes in a row.
- PICTURES: never show the viewer or any child/person who is not in the cast. When a character talks to the viewer, show that character looking into the camera.`;

function beatsSystem(cfg, cast, brief, sheet) {
  return `You are the showrunner of "DD TV English", animated stories for ${cfg.script.audience}, as fun as the best preschool shows.
Plan the BEATS of this episode before any script is written.

THE CAST:
${sheet}

${CRAFT}

Reply with ONLY this JSON:
{ "hook": "what happens in the first 2 scenes that grabs attention",
  "hero": "who the hero is", "want": "what the hero wants, in their words",
  "tries": ["funny try 1", "bigger try 2", "biggest, silliest try 3"],
  "runner": "the repeated line / chant / mini-song, written out exactly",
  "viewer_moments": ["when and how kids at home are asked to join in"],
  "comedy": ["4-6 specific visual gags"],
  "twist": "the surprise before the end",
  "heart": "the warm moment", "ending": "how the runner pays off and the story ends",
  "key_moments": ["every important moment from the brief/story plan that MUST appear, e.g. who helps whom and how"] }`;
}

function wordsTarget(cfg, brief) { return (cfg.script.formats[brief.format] || cfg.script.formats.story).words; }
function minWords(cfg, brief) { return Math.round(parseInt(String(wordsTarget(cfg, brief)).split('-')[0], 10) * 0.85) || 300; }

function expandSystem(cfg, brief, sheet) {
  return `You are the dialogue writer of a preschool animation show. The script you receive is too short and too choppy.
THE CAST:
${sheet}

Rewrite it to about ${wordsTarget(cfg, brief)} words WITHOUT changing the story:
- keep every scene (you may split a scene in two), every joke, the runner and every key moment
- every scene gets 2-3 full, natural lines (8-15 words each) instead of one-word exclamations
- the storyteller speaks about a quarter of the lines, in warm, flowing sentences, like a grandmother reading aloud
- use the correct pronouns for every character
Reply with ONLY the full script JSON in the same format.`;
}

function editorSystem(cfg, cast, brief, sheet) {
  return `You are the toughest story editor in preschool animation. You judge scripts ONLY by whether a 3-5 year old would stay glued to the screen and want to watch again.

THE CAST:
${sheet}

${CRAFT}

TASK: 1) Score the script you receive, honestly and strictly, 1-10 for each item (7 = good enough to publish, 9 = as good as the best shows).
2) Name the weakest scenes and what exactly is wrong.
3) Rewrite the WHOLE script to fix every weakness: punch up the jokes, sharpen the hook, make the tries escalate, make the runner catchy, keep the storyteller at about 20-30% of the lines.
HARD LIMITS for the rewrite: keep EVERY key moment from the beat plan; never make the script shorter; total length ${wordsTarget(cfg, brief)} words; 2-3 full lines per scene; same JSON structure and cast ids; correct pronouns for every character (see the cast).

Reply with ONLY this JSON:
{ "scores": { "hook": 0, "want": 0, "escalation": 0, "comedy": 0, "dialogue": 0, "runner": 0, "viewer": 0, "twist": 0, "heart": 0, "pace": 0 },
  "notes": "the 3 biggest problems, short",
  "script": { ...the full rewritten script in the same format you received... } }`;
}

const avg = o => { const v = Object.values(o || {}).map(Number).filter(n => n >= 1 && n <= 10); return v.length ? Math.round(v.reduce((a, b) => a + b, 0) / v.length * 10) / 10 : 0; };
const narrationShare = (s, narrator) => {
  const lines = s.scenes.flatMap(sc => sc.lines);
  return lines.length ? Math.round(lines.filter(l => l.speaker === narrator).length / lines.length * 100) : 0;
};

async function jsonCall(cfg, sec, system, user, opts, label) {
  let lastErr;
  for (let a = 1; a <= 2; a++) {
    try { return L.parseJSONLoose(await L.llm(cfg, sec, system, user + (a > 1 ? `\n\nYour previous reply was invalid (${lastErr}). Reply with the complete JSON only.` : ''), opts)); }
    catch (e) { lastErr = e.message; L.log(`${label} attempt ${a} failed: ${e.message}`); }
  }
  throw new Error(`${label} failed: ${lastErr}`);
}

async function ensureLength(cfg, sec, brief, sheet, cur, beats, normalize, cast) {
  const min = minWords(cfg, brief);
  for (let k = 1; k <= 2 && cur.words < min; k++) {
    L.log(`script too short (${cur.words} words, need ${min}): expanding, attempt ${k}`);
    try {
      const res = await jsonCall(cfg, sec, expandSystem(cfg, brief, sheet),
        `Key moments that must stay: ${JSON.stringify(beats.key_moments || [])}\nSCRIPT (${cur.words} words):\n${JSON.stringify(cur)}`, { temperature: 0.7 }, 'expand');
      const next = normalize(res, cast, cfg);
      if (next.words > cur.words) cur = next;
    } catch (e) { L.log(e.message); break; }
  }
  return cur;
}

// scriptSystem/userPrompt/normalize come from write_script.js so the JSON format stays in one place.
async function writersRoom({ cfg, cast, sec, brief, prev, feedback, sheet, scriptSystem, userPrompt, normalize }) {
  const model = cfg.llm.provider === 'openrouter' ? cfg.llm.openrouter_model : cfg.llm.ollama_model;
  const min = cfg.llm.min_fun_score || 7.5, rounds = cfg.llm.editor_rounds ?? 2;
  const base = userPrompt(brief, prev, feedback);

  // 1. beats
  const beats = await jsonCall(cfg, sec, beatsSystem(cfg, cast, brief, sheet), base, { temperature: 0.9 }, 'beat plan');
  L.log('beats:', JSON.stringify(beats).slice(0, 300));

  // 2. script from the beats
  const raw = await jsonCall(cfg, sec, scriptSystem + '\n\n' + CRAFT,
    `${base}\n\nAPPROVED BEAT PLAN (write the script from this, scene by scene):\n${JSON.stringify(beats)}`, { temperature: 0.85 }, 'script');
  let cur = await ensureLength(cfg, sec, brief, sheet, normalize(raw, cast, cfg), beats, normalize, cast);

  // 3. fun editor: score -> rewrite, until good enough or out of rounds
  const history = [];
  for (let r = 1; r <= rounds; r++) {
    let res;
    try {
      res = await jsonCall(cfg, sec, editorSystem(cfg, cast, brief, sheet),
        `Beat plan: ${JSON.stringify(beats)}\nFacts: ${narrationShare(cur, cast.narrator)}% of the lines are the storyteller's (target 20-30%). The script has ${cur.words} words (target ${wordsTarget(cfg, brief)}).\n\nSCRIPT:\n${JSON.stringify(cur)}`, { temperature: 0.6 }, `fun editor ${r}`);
    } catch (e) { L.log(e.message); break; }
    const score = avg(res.scores);
    history.push({ round: r, score, scores: res.scores, notes: String(res.notes || '') });
    L.log(`fun editor round ${r}: score ${score} ${res.notes || ''}`);
    if (score >= min) break;                       // the current script is good enough
    try {
      const next = await ensureLength(cfg, sec, brief, sheet, normalize(res.script || {}, cast, cfg), beats, normalize, cast);
      if (next.words >= cur.words * 0.9) cur = next; else { L.log(`editor rewrite was shorter (${next.words} vs ${cur.words}); keeping the longer version`); break; }
    }
    catch (e) { L.log('rewrite unusable, keeping previous version:', e.message); break; }
  }
  const last = history[history.length - 1];
  cur.fun = { model, beats, min_words: minWords(cfg, brief), rounds: history, final_score: last ? last.score : null,
    improved_after: last && last.score < min, narration_pct: narrationShare(cur, cast.narrator) };
  return cur;
}

module.exports = { writersRoom, CRAFT, minWords };
