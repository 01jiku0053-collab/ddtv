'use strict';
// usage: node idea.js [hintB64]
// Invents the next story automatically and returns a brief ready for series.js.
// Sources are limited to public-domain classics (retold with new characters) or fully original ideas.
// Keeps ideas_history.json so stories never repeat.
const fs = require('fs');
const path = require('path');
const L = require('./lib');

const CLASSICS = 'Panchatantra, Hitopadesha, Jataka tales, Aesop\'s fables, Brothers Grimm, Hans Christian Andersen, Charles Perrault, ' +
  'Indian folk tales, African folk tales (e.g. Anansi), Japanese folk tales, Chinese folk tales, Russian folk tales, Nordic folk tales, Native American folk tales, Arabian Nights';

function pickWeighted(weights) {
  const entries = Object.entries(weights).filter(([, w]) => w > 0);
  let r = Math.random() * entries.reduce((t, [, w]) => t + w, 0);
  for (const [k, w] of entries) { if ((r -= w) <= 0) return k; }
  return entries[0][0];
}

async function trendingTitles(sec) {
  if (!sec.youtube_key) return [];
  try {
    const after = new Date(Date.now() - 30 * 86400e3).toISOString();
    const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&order=viewCount&maxResults=25` +
      `&relevanceLanguage=en&safeSearch=strict&q=${encodeURIComponent('kids story cartoon')}&publishedAfter=${after}&key=${sec.youtube_key}`;
    const r = await L.fetchT(url, {}, 30000);
    const j = await r.json();
    return (j.items || []).map(i => i.snippet && i.snippet.title).filter(Boolean).slice(0, 25);
  } catch (e) { L.log('trend lookup skipped:', e.message); return []; }
}

L.main(async () => {
  const hint = L.b64d(process.argv[2] || '');
  const { cfg, sec } = L.loadAll();
  const A = cfg.auto || {};
  const histFile = path.join(L.ROOT, 'ideas_history.json');
  const history = L.readJSON(histFile, []);

  const kind = hint ? 'hint' : (Math.random() < (A.classic_share ?? 0.6) ? 'classic' : 'original');
  const format = pickWeighted(A.formats || { story: 0.8, rhyme: 0.1, learn: 0.1 });
  const minE = Math.max(1, A.episodes_min || 1), maxE = Math.min(5, Math.max(minE, A.episodes_max || 3));
  const trends = await trendingTitles(sec);
  const today = new Date().toISOString().slice(0, 10);

  const system = `You are the story editor of "DD TV English", a YouTube channel of animated stories for ${cfg.script.audience}.
Your job: propose the NEXT story. Today is ${today}.

HARD RULES
- Never copy or adapt any story, script or character from YouTube channels, films, TV, games or modern books.
- Classic stories may ONLY come from public-domain traditions: ${CLASSICS}. Retell them freshly: new original characters, a new setting, a gentle ending, and remove any violence, fear or cruelty from the original.
- Warm and safe: no villains who hurt anyone, no danger, no scary moments, no sadness that lasts.
- Characters are new and original (animals, children, magical friends). A grandmother called Nani tells every story.
- Pick a lesson a 3-5 year old understands (kindness, sharing, courage, honesty, patience, teamwork, gratitude, trying again, healthy habits…).
- Choose how many parts the story naturally needs, between ${minE} and ${maxE}. Most good small stories need ${minE}-${Math.min(maxE, 2)}; only choose more when the story truly has more chapters.
- Seasonal ideas are welcome when a festival or season is near (Diwali, Christmas, spring, rain, winter snow), but no Halloween horror.
- Do NOT repeat any story in the history list, and vary the lessons and settings from recent ones.

Reply with ONLY this JSON:
{ "type": "classic" | "original",
  "source": "for classics: the tradition and tale name, e.g. 'Aesop - The Lion and the Mouse'; for originals: 'original'",
  "working_title": "short working title",
  "idea": "3-5 sentences: the story as it will be told in this new version, with the new characters described briefly",
  "lesson": "one short sentence",
  "episodes": ${minE},
  "notes": "the fresh twist, setting and one funny moment" }`;

  const user = `Story type wanted: ${kind === 'classic' ? 'a public-domain CLASSIC, retold freshly' : kind === 'original' ? 'a completely ORIGINAL story' : 'follow the showrunner hint'}.
Episode format: ${format}.
${hint ? `Showrunner hint: ${hint}\n` : ''}Stories already made (do not repeat, vary from these):
${history.slice(-40).map(h => `- ${h.title} [${h.source}] lesson: ${h.lesson}`).join('\n') || '- (none yet)'}
${trends.length ? `\nTopics popular on kids YouTube this month (titles; use ONLY as a hint for themes kids like, never copy a story):\n${trends.map(t => '- ' + t).join('\n')}` : ''}`;

  let idea, lastErr;
  for (let a = 1; a <= 2 && !idea; a++) {
    try {
      const j = L.parseJSONLoose(await L.llm(cfg, sec, system, user + (a > 1 ? `\nYour previous reply was invalid (${lastErr}). Reply with the JSON only.` : ''), { temperature: 0.95 }));
      if (!j.idea || String(j.idea).length < 30) throw new Error('idea too short');
      const src = String(j.source || '').toLowerCase().trim();
      if (src && src !== 'original' && history.some(h => String(h.source).toLowerCase().trim() === src))
        throw new Error(`"${j.source}" was already used; choose a different tale`);
      idea = j;
    } catch (e) { lastErr = e.message; L.log(`idea attempt ${a} failed: ${e.message}`); }
  }
  if (!idea) throw new Error(`could not invent a story: ${lastErr}`);

  const brief = {
    idea: String(idea.idea).trim(), lesson: String(idea.lesson || '').trim(), format,
    episodes: Math.min(maxE, Math.max(minE, parseInt(idea.episodes, 10) || minE)), cast: 'new',
    notes: String(idea.notes || '').trim(), source: String(idea.source || 'original').slice(0, 120), auto: true,
  };
  const title = String(idea.working_title || brief.idea.slice(0, 40));
  history.push({ date: today, title, source: brief.source, lesson: brief.lesson });
  L.writeJSON(histFile, history.slice(-300));

  const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 24).replace(/-+$/, '') || 'story';
  const seriesId = `dd_${new Date().toISOString().slice(2, 16).replace(/[-:T]/g, '')}_${slug}`;
  return { ok: true, seriesId, briefB64: Buffer.from(JSON.stringify(brief)).toString('base64'), feedbackB64: '',
    title, source: brief.source, episodes: brief.episodes, notify_email: cfg.notify_email };
});
