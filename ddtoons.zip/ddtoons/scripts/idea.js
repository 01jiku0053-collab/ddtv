'use strict';
// usage: node idea.js [hintB64]
// Invents the next story automatically and returns a brief ready for series.js.
// Sources are limited to public-domain classics (retold with new characters) or fully original ideas.
// Keeps ideas_history.json so stories never repeat.
const fs = require('fs');
const path = require('path');
const L = require('./lib');

const CLASSICS = 'Panchatantra, Hitopadesha, Jataka tales, Aesop\'s fables, Brothers Grimm, Hans Christian Andersen, Charles Perrault, ' +
  'Indian folk tales, African folk tales (e.g. Anansi), Japanese folk tales, Chinese folk tales, Russian folk tales, Nordic folk tales, Native American folk tales, Arabian Nights';

function pickWeighted(weights) {
  const entries = Object.entries(weights).filter(([, w]) => w > 0);
  let r = Math.random() * entries.reduce((t, [, w]) => t + w, 0);
  for (const [k, w] of entries) { if ((r -= w) <= 0) return k; }
  return entries[0][0];
}

async function trendingTitles(sec) {
  if (!sec.youtube_key) return [];
  try {
    const after = new Date(Date.now() - 30 * 86400e3).toISOString();
    const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&order=viewCount&maxResults=25` +
      `&relevanceLanguage=en&safeSearch=strict&q=${encodeURIComponent('kids story cartoon')}&publishedAfter=${after}&key=${sec.youtube_key}`;
    const r = await L.fetchT(url, {}, 30000);
    const j = await r.json();
    return (j.items || []).map(i => i.snippet && i.snippet.title).filter(Boolean).slice(0, 25);
  } catch (e) { L.log('trend lookup skipped:', e.message); return []; }
}

const { TRADITIONAL, FORMULA } = require('./song');
const PITCH_TYPES = [
  { type: 'traditional_song', label: '🎵 Nursery rhyme', ask: `a TRADITIONAL nursery rhyme from this list only: ${TRADITIONAL.join('; ')}, given our own characters and a counting or colour layer. Put the song name in "source".` },
  { type: 'original_song', label: '🎶 Original song', ask: 'an ORIGINAL kids\' song following the formula (4-6 nearly identical verses, a countdown or build-up, a learning layer, a happy last verse) about something toddlers love or live (bath time, brushing teeth, animals on the farm, colours of fruit, vehicles).' },
  { type: 'everyday', label: '🏡 Everyday life', ask: 'an EVERYDAY-LIFE story about something 2-5 year olds really live: bedtime, bath time, sharing a toy, a new baby sibling, the first day at nursery, trying a new food, a lost teddy, waiting for a turn, a rainy day inside, visiting grandparents. Funny and warm, never scary.' },
  { type: 'adventure', label: '🚀 Adventure', ask: 'a small, exciting ADVENTURE with a clear goal and a playful journey (a treasure map in the garden, a trip to the moon in a cardboard box, finding the lost rainbow colour, helping a baby cloud get home). Wonder, not danger.' },
  { type: 'classic', label: '📜 Classic retold', ask: 'a public-domain CLASSIC tale retold freshly with new original characters and a new setting.' },
];

async function trendsAndHistory(sec, histFile) {
  return { history: L.readJSON(histFile, []), trends: await trendingTitles(sec) };
}

function commonRules(cfg, minE, maxE, today) {
  return `You are the story editor of "DD TV English", a YouTube channel of animated stories for ${cfg.script.audience}. Today is ${today}.
HARD RULES
- Never copy or adapt any story, script or character from YouTube channels, films, TV, games or modern books.
- Classic stories may ONLY come from public-domain traditions: ${CLASSICS}. Retell them freshly: new original characters, a new setting, a gentle ending, no violence, fear or cruelty.
- Warm and safe: no villains who hurt anyone, no danger, no scary moments, no sadness that lasts.
- New, original, lovable characters (animals, children, magical friends). A grandmother called Nani tells every story.
- A lesson a 3-5 year old understands. One small, vivid, unforgettable detail kids will remember.
- Parts: between ${minE} and ${maxE}; most small stories need ${minE}.
- Do NOT repeat anything in the history list; vary lessons and settings.`;
}

async function pitch(hint, mode) {
  const songsOnly = mode === 'songs';
  const { cfg, sec } = L.loadAll();
  const A = cfg.auto || {};
  const histFile = path.join(L.ROOT, 'ideas_history.json');
  const { history, trends } = await trendsAndHistory(sec, histFile);
  const research = require('./research');
  let trend = { live: false, items: [] };
  try { trend = await research.trending(cfg, sec, { months: (cfg.research && cfg.research.months) || 3 }); } catch (e) { L.log('trend research skipped:', e.message); }
  const trendText = research.summary(trend, 45);
  const count = songsOnly ? 6 : 3;
  const minE = Math.max(1, A.episodes_min || 1), maxE = Math.min(5, Math.max(minE, A.episodes_max || 3));
  const today = new Date().toISOString().slice(0, 10);
  const system = `${commonRules(cfg, minE, maxE, today)}

${songsOnly
  ? `Pitch SIX song ideas: 3 of type "traditional_song" (${PITCH_TYPES[0].ask}) and 3 of type "original_song" (${PITCH_TYPES[1].ask}). Order them from most to least promising.`
  : `Pitch THREE ideas, one of each kind, in this order:\n${[PITCH_TYPES[0], PITCH_TYPES[1], PITCH_TYPES[2 + Math.floor(Math.random() * 3)]].map((t, i) => `${i + 1}. (type "${t.type}") ${t.ask}`).join('\n')}`}
${trendText ? `
TRENDING DATA: the most-watched kids' song videos on YouTube in the last ${trend.months} months (title | channel | views | views per day | date).
Base the SONG ideas on this evidence: which traditional rhymes, learning topics and themes are winning right now.
Traditional rhymes must still come from the allowed list. For ORIGINAL songs, take only the THEME or topic that is trending,
never another channel's original song, lyrics, characters or title.
${trendText}` : '(No live trending data available: use your knowledge of evergreen favourites.)'}

${FORMULA}

Reply with ONLY this JSON:
{ "pitches": [ { "type": "everyday|adventure|classic", "source": "for the classic: tradition and tale name; otherwise 'original'",
  "working_title": "short, fun title", "logline": "one sentence that makes a parent want to press play",
  "idea": "3-5 sentences: the story as it will be told, with the new characters described briefly",
  "lesson": "one short sentence", "episodes": ${minE}, "notes": "the twist, setting and the funniest moment",
  "why_kids_love_it": "one sentence",
  "cast": "new (only new characters) | family (Dia, Dhruv and Doodle are the heroes) | mix (the family meets new characters)",
  "learning": "for songs: counting / colours / animals / body parts / routine",
  "evidence": "for songs: the trend that supports this idea, e.g. 'Five Little Ducks: top video 28M views in 6 months'" } ] }
For songs, "idea" describes the song (verses, progression, the happy ending); "episodes" is 1.
The show's recurring DD family: Dia (6-year-old girl), Dhruv (4-year-old boy) and Doodle (their puppy). Use them when a story is about everyday family life; say so in "cast".`;
  const user = `${hint ? `Showrunner hint (apply it to all ideas): ${hint}\n` : ''}Stories already made (do not repeat):
${history.slice(-40).map(h => `- ${h.title} [${h.source}] lesson: ${h.lesson}`).join('\n') || '- (none yet)'}
${trends.length ? `\nTopics popular on kids YouTube this month (themes only, never copy):\n${trends.map(t => '- ' + t).join('\n')}` : ''}`;
  let pitches, lastErr;
  for (let a = 1; a <= 2 && !pitches; a++) {
    try {
      const j = L.parseJSONLoose(await L.llm(cfg, sec, system, user + (a > 1 ? `\nYour previous reply was invalid (${lastErr}). Reply with the JSON only.` : ''), { temperature: 0.95 }));
      const ps = (j.pitches || []).filter(p => p && String(p.idea || '').length > 30).slice(0, count);
      if (ps.length < Math.min(3, count)) throw new Error(`only ${ps.length} usable pitches`);
      for (const p of ps) {
        const src = String(p.source || '').toLowerCase().trim();
        if (src && src !== 'original' && history.some(h => String(h.source).toLowerCase().trim() === src)) throw new Error(`"${p.source}" was already used; choose a different tale`);
      }
      pitches = ps;
    } catch (e) { lastErr = e.message; L.log(`pitch attempt ${a} failed: ${e.message}`); }
  }
  if (!pitches) throw new Error(`could not pitch stories: ${lastErr}`);
  const batch = `p${new Date().toISOString().slice(2, 16).replace(/[-:T]/g, '')}`;
  const dir = path.join(L.ROOT, 'pitches'); fs.mkdirSync(dir, { recursive: true });
  L.writeJSON(path.join(dir, `${batch}.json`), { batch, created: today, minE, maxE, pitches });
  const cards = pitches.map((p, i) => `<div style="border:2px solid #eee;border-radius:12px;padding:12px 16px;margin:12px 0">
<div style="color:#7c3aed;font-weight:bold">Idea ${i + 1} · ${L.esc((PITCH_TYPES.find(t => t.type === p.type) || PITCH_TYPES[i]).label)}${p.source && p.source !== 'original' ? ` · based on ${L.esc(p.source)}` : ''}</div>
<h3 style="margin:6px 0">${L.esc(p.working_title)}</h3><p style="margin:4px 0"><i>${L.esc(p.logline)}</i></p>
<p style="margin:6px 0">${L.esc(p.idea)}</p>
<p style="margin:4px 0;color:#555">Lesson: ${L.esc(p.lesson)} · Parts: ${Math.min(maxE, Math.max(minE, parseInt(p.episodes, 10) || minE))} · ${L.esc(p.why_kids_love_it || '')}</p>${p.evidence ? `<p style="margin:4px 0;color:#0f766e">📈 ${L.esc(p.evidence)}</p>` : ''}</div>`).join('');
  const topTrend = trend.live && trend.items.length ? `<p style="color:#555;font-size:13px">📈 Based on ${trend.items.length} top kids' song videos from the last ${trend.months} months. Top right now: ${trend.items.slice(0, 5).map(v => `"${L.esc(v.title.slice(0, 50))}" (${v.views.toLocaleString('en')} views)`).join(', ')}.</p>` : '<p style="color:#b45309;font-size:13px">No live YouTube data (add youtube_key to secrets.json for trend research).</p>';
  return { ok: true, batch, mode: songsOnly ? 'songs' : '', notify_email: cfg.notify_email,
    subject: songsOnly ? `DD TV English: ${pitches.length} trending song ideas` : `DD TV English: ${pitches.length} ideas for this week`,
    email_html: `<div style="font-family:Arial,sans-serif;max-width:720px"><p>Here are ${pitches.length} ideas. Pick one in the next email (or ask for new ones).</p>${topTrend}${cards}</div>` };
}

async function choose(batch, n) {
  const { cfg } = L.loadAll();
  const histFile = path.join(L.ROOT, 'ideas_history.json');
  const history = L.readJSON(histFile, []);
  const data = L.readJSON(path.join(L.ROOT, 'pitches', `${batch}.json`));
  const p = data.pitches[(parseInt(n, 10) || 1) - 1];
  if (!p) throw new Error(`there is no idea ${n} in this list (it has ${data.pitches.length}); choose a smaller number`);
  const today = new Date().toISOString().slice(0, 10);
  if (/song/.test(String(p.type || ''))) {
    const kind = String(p.type).startsWith('traditional') ? 'traditional' : 'original';
    const title = String(p.working_title || p.source || 'song');
    history.push({ date: today, title, source: kind === 'traditional' ? String(p.source || title) : 'original song', lesson: String(p.learning || p.lesson || '') });
    L.writeJSON(histFile, history.slice(-300));
    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 22).replace(/-+$/, '') || 'song';
    const jobId = `dd_${new Date().toISOString().slice(2, 16).replace(/[-:T]/g, '')}_song-${slug}`;
    const sb = { kind: 'song', song_kind: kind, song: kind === 'traditional' ? String(p.source || title) : `${title}: ${p.idea}`,
      learning: String(p.learning || ''), notes: `${p.idea || ''} ${p.notes || ''}`.trim() };
    return { ok: true, kind: 'song', jobId, briefB64: Buffer.from(JSON.stringify(sb)).toString('base64'), feedbackB64: '', title, notify_email: cfg.notify_email };
  }
  // keep the cast the pitch promised: if it names the DD family, they stay in the story
  const text = `${p.idea} ${p.logline || ''} ${p.notes || ''}`;
  const famNamed = /\b(Dia|Dhruv|Doodle)\b/.test(text);
  let cast = String(p.cast || '').split(/\s/)[0].toLowerCase();
  if (!['new', 'family', 'mix'].includes(cast)) cast = famNamed ? 'mix' : 'new';
  if (famNamed && cast === 'new') cast = 'mix';
  const brief = { idea: String(p.idea).trim(), lesson: String(p.lesson || '').trim(), format: 'story',
    episodes: Math.min(data.maxE, Math.max(data.minE, parseInt(p.episodes, 10) || data.minE)), cast,
    notes: `${String(p.notes || '').trim()} Logline: ${p.logline || ''}`.trim(), source: String(p.source || 'original').slice(0, 120), auto: true };
  const title = String(p.working_title || brief.idea.slice(0, 40));
  history.push({ date: today, title, source: brief.source, lesson: brief.lesson });
  L.writeJSON(histFile, history.slice(-300));
  const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 24).replace(/-+$/, '') || 'story';
  const seriesId = `dd_${new Date().toISOString().slice(2, 16).replace(/[-:T]/g, '')}_${slug}`;
  return { ok: true, kind: 'story', seriesId, briefB64: Buffer.from(JSON.stringify(brief)).toString('base64'), feedbackB64: '',
    title, notify_email: cfg.notify_email };
}

L.main(async () => {
  const [mode, a1, a2] = process.argv.slice(2);
  if (mode === 'pitch') return pitch(L.b64d(a1 || ''), a2 || '');
  if (mode === 'choose') return choose(a1, a2);
  return single(L.b64d(mode || ''));
});

async function single(hint) {
  const { cfg, sec } = L.loadAll();
  const A = cfg.auto || {};
  const histFile = path.join(L.ROOT, 'ideas_history.json');
  const history = L.readJSON(histFile, []);

  const kind = hint ? 'hint' : (Math.random() < (A.classic_share ?? 0.6) ? 'classic' : 'original');
  const format = pickWeighted(A.formats || { story: 0.8, rhyme: 0.1, learn: 0.1 });
  const minE = Math.max(1, A.episodes_min || 1), maxE = Math.min(5, Math.max(minE, A.episodes_max || 3));
  const trends = await trendingTitles(sec);
  const today = new Date().toISOString().slice(0, 10);

  const system = `You are the story editor of "DD TV English", a YouTube channel of animated stories for ${cfg.script.audience}.
Your job: propose the NEXT story. Today is ${today}.

HARD RULES
- Never copy or adapt any story, script or character from YouTube channels, films, TV, games or modern books.
- Classic stories may ONLY come from public-domain traditions: ${CLASSICS}. Retell them freshly: new original characters, a new setting, a gentle ending, and remove any violence, fear or cruelty from the original.
- Warm and safe: no villains who hurt anyone, no danger, no scary moments, no sadness that lasts.
- Characters are new and original (animals, children, magical friends). A grandmother called Nani tells every story.
- Pick a lesson a 3-5 year old understands (kindness, sharing, courage, honesty, patience, teamwork, gratitude, trying again, healthy habits…).
- Choose how many parts the story naturally needs, between ${minE} and ${maxE}. Most good small stories need ${minE}-${Math.min(maxE, 2)}; only choose more when the story truly has more chapters.
- Seasonal ideas are welcome when a festival or season is near (Diwali, Christmas, spring, rain, winter snow), but no Halloween horror.
- Do NOT repeat any story in the history list, and vary the lessons and settings from recent ones.

Reply with ONLY this JSON:
{ "type": "classic" | "original",
  "source": "for classics: the tradition and tale name, e.g. 'Aesop - The Lion and the Mouse'; for originals: 'original'",
  "working_title": "short working title",
  "idea": "3-5 sentences: the story as it will be told in this new version, with the new characters described briefly",
  "lesson": "one short sentence",
  "episodes": ${minE},
  "notes": "the fresh twist, setting and one funny moment" }`;

  const user = `Story type wanted: ${kind === 'classic' ? 'a public-domain CLASSIC, retold freshly' : kind === 'original' ? 'a completely ORIGINAL story' : 'follow the showrunner hint'}.
Episode format: ${format}.
${hint ? `Showrunner hint: ${hint}\n` : ''}Stories already made (do not repeat, vary from these):
${history.slice(-40).map(h => `- ${h.title} [${h.source}] lesson: ${h.lesson}`).join('\n') || '- (none yet)'}
${trends.length ? `\nTopics popular on kids YouTube this month (titles; use ONLY as a hint for themes kids like, never copy a story):\n${trends.map(t => '- ' + t).join('\n')}` : ''}`;

  let idea, lastErr;
  for (let a = 1; a <= 2 && !idea; a++) {
    try {
      const j = L.parseJSONLoose(await L.llm(cfg, sec, system, user + (a > 1 ? `\nYour previous reply was invalid (${lastErr}). Reply with the JSON only.` : ''), { temperature: 0.95 }));
      if (!j.idea || String(j.idea).length < 30) throw new Error('idea too short');
      const src = String(j.source || '').toLowerCase().trim();
      if (src && src !== 'original' && history.some(h => String(h.source).toLowerCase().trim() === src))
        throw new Error(`"${j.source}" was already used; choose a different tale`);
      idea = j;
    } catch (e) { lastErr = e.message; L.log(`idea attempt ${a} failed: ${e.message}`); }
  }
  if (!idea) throw new Error(`could not invent a story: ${lastErr}`);

  const brief = {
    idea: String(idea.idea).trim(), lesson: String(idea.lesson || '').trim(), format,
    episodes: Math.min(maxE, Math.max(minE, parseInt(idea.episodes, 10) || minE)), cast: 'new',
    notes: String(idea.notes || '').trim(), source: String(idea.source || 'original').slice(0, 120), auto: true,
  };
  const title = String(idea.working_title || brief.idea.slice(0, 40));
  history.push({ date: today, title, source: brief.source, lesson: brief.lesson });
  L.writeJSON(histFile, history.slice(-300));

  const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 24).replace(/-+$/, '') || 'story';
  const seriesId = `dd_${new Date().toISOString().slice(2, 16).replace(/[-:T]/g, '')}_${slug}`;
  return { ok: true, seriesId, briefB64: Buffer.from(JSON.stringify(brief)).toString('base64'), feedbackB64: '',
    title, source: brief.source, episodes: brief.episodes, notify_email: cfg.notify_email };
}
