'use strict';
// usage:
//   node characters.js generate <all|id,id> [count]   -> candidates/<id>_<k>.jpg + email previews
//   node characters.js pick <id> <k>                  -> assets/characters/<id>.jpg (the locked reference)
//   node characters.js status                          -> previews of the current locked cast
// Previews for the email always land in assets/characters/_latest/ (cleared each run).
const fs = require('fs');
const path = require('path');
const L = require('./lib');

L.main(async () => {
  const [action = 'status', a1 = 'all', a2 = ''] = process.argv.slice(2);
  const { cfg, cast, sec } = L.loadAll();
  const FF = L.ffmpegBin(cfg);
  const base = path.join(L.ROOT, 'assets', 'characters');
  const cand = path.join(base, 'candidates');
  const latest = path.join(base, '_latest');
  fs.mkdirSync(cand, { recursive: true });
  fs.rmSync(latest, { recursive: true, force: true });
  fs.mkdirSync(latest, { recursive: true });
  const byId = Object.fromEntries(cast.characters.map(c => [c.id, c]));
  const locked = id => fs.existsSync(path.join(base, `${id}.jpg`));
  const preview = (src, name) => L.ff(FF, ['-i', src, '-vf', 'scale=640:-2', '-q:v', '4', path.join(latest, name)], 'preview');
  let cost = 0; const lines = [];

  if (action === 'generate') {
    const ids = a1 === 'all' ? cast.characters.map(c => c.id) : a1.split(',').map(s => s.trim().toLowerCase());
    const count = Math.min(Math.max(parseInt(a2, 10) || 3, 1), 4);
    // Characters that are already locked act as style anchors, so the whole cast shares one art style.
    const anchors = cast.characters.filter(c => locked(c.id) && !ids.includes(c.id)).slice(0, 3)
      .map(c => L.fileToDataURI(path.join(base, `${c.id}.jpg`)));
    for (const id of ids) {
      const c = byId[id];
      if (!c) { lines.push(`Unknown character "${id}" (check characters.json)`); continue; }
      for (let k = 1; k <= count; k++) {
        const out = path.join(cand, `${id}_${k}.jpg`);
        const prompt = `${cfg.style}. Character reference sheet of ONE character: ${c.name}, ${c.look}. ` +
          `Full body, standing, facing the camera, friendly ${c.personality.split(',')[0]} expression, plain soft pastel background, whole character visible, centred.` +
          (anchors.length ? ' Use exactly the same art style, rendering and proportions as the reference images, but draw only this new character.' : '');
        const r = await L.retry(() => L.genImage(cfg, sec, { prompt, refs: anchors, width: 2048, height: 2048, file: out }), 2, `${id} #${k}`);
        cost += r.cost;
        await preview(out, `${id}_${k}.jpg`);
      }
      lines.push(`${c.name}: ${count} options attached as ${id}_1 … ${id}_${count}`);
    }
    lines.push('', 'Pick one per character with the Character Setup form: Action = pick, Character = id, Option = number.',
      'Tip: lock your main character first, then regenerate the others: they will copy the locked art style.');
  } else if (action === 'pick') {
    const id = a1.toLowerCase(), k = parseInt(a2, 10);
    const src = path.join(cand, `${id}_${k}.jpg`);
    if (!byId[id]) throw new Error(`unknown character "${id}"`);
    if (!fs.existsSync(src)) throw new Error(`no candidate ${id}_${k}.jpg; generate first`);
    fs.copyFileSync(src, path.join(base, `${id}.jpg`));
    lines.push(`${byId[id].name} is now locked to option ${k}. Every new episode uses this look.`);
  } else if (action !== 'status') {
    throw new Error(`unknown action "${action}" (use generate, pick or status)`);
  }

  const cur = cast.characters.map(c => `${c.name} (${c.id}): ${locked(c.id) ? 'locked ✅' : 'not set yet ❌'}${c.voice_id ? '' : ' · no voice_id'}`);
  if (action !== 'generate') for (const c of cast.characters) if (locked(c.id)) await preview(path.join(base, `${c.id}.jpg`), `cast_${c.id}.jpg`);
  return {
    ok: true, action, notify_email: cfg.notify_email, cost,
    subject: `DD TV English characters: ${action}`,
    email_html: `<div style="font-family:Arial,sans-serif">${[...lines, '', '<b>Current cast</b>', ...cur].map(l => L.esc(l).replace(/&lt;b&gt;|&lt;\/b&gt;/g, m => m === '&lt;b&gt;' ? '<b>' : '</b>')).join('<br>')}</div>`,
  };
});
