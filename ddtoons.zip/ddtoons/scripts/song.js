'use strict';
// SONG EPISODES (the nursery-rhyme format that dominates kids' YouTube).
//   write():   the songwriter + song editor -> script.json with kind "song" (sections, lines, one visual per line)
//   produce(): characters -> director (world + shots) -> pictures -> full song (ElevenLabs Music, exact lyrics,
//              section by section) -> one clip per lyric line, cut exactly to the music -> video, Short, thumbnail
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const L = require('./lib');
const director = require('./director');

// Traditional rhymes with no known modern author, safe to use. (Songs like "Baby Shark" or "Wheels on the Bus"
// have modern authors/owners and are deliberately NOT on this list.)
const TRADITIONAL = ['Five Little Ducks', 'Twinkle Twinkle Little Star', 'Old MacDonald Had a Farm', 'Row Row Row Your Boat',
  'Humpty Dumpty', 'Baa Baa Black Sheep', 'Itsy Bitsy Spider', 'Five Little Monkeys Jumping on the Bed', 'Ten in the Bed',
  'Hickory Dickory Dock', 'London Bridge Is Falling Down', 'Mary Had a Little Lamb', 'The Farmer in the Dell', 'Rain Rain Go Away',
  'Hey Diddle Diddle', 'Jack and Jill', 'Bingo', 'Five Little Speckled Frogs', 'One Two Buckle My Shoe', 'Pat-a-Cake',
  'Little Bo-Peep', 'Hot Cross Buns', 'The Muffin Man', 'Ring Around the Rosie', 'Little Miss Muffet', 'Hush Little Baby',
  'Head Shoulders Knees and Toes', 'If You\'re Happy and You Know It', 'The Ants Go Marching', 'This Old Man', 'Oh Where Has My Little Dog Gone',
  'Five Little Pumpkins', 'Ten Little Fingers', 'Are You Sleeping (Frère Jacques)', 'Down by the Bay', 'Here We Go Round the Mulberry Bush'];

const FORMULA = `THE FORMULA OF THE MOST-WATCHED KIDS' SONGS (measured on videos with 8-28 million views):
- 4 to 6 verses of 4 short lines, almost IDENTICAL: only 1-3 words change per verse (a number, a colour, an animal, a body part).
- A built-in progression kids can predict: a countdown (5,4,3,2,1,0), a count-up, one new animal/colour per verse.
- A learning layer: counting out loud between verses ("One, two, three, four!"), naming colours, animals or body parts.
- A tiny emotional arc: a small worry in the middle, a big happy reunion or success in the last verse.
- About 150-200 words in total. Very simple words. Every line is easy to sing and to act out with pictures.
- A cheerful 3-6 second intro that grabs attention (a colour list, a counting chant, a "Hello friends!").
- The pictures show EXACTLY what each line says.`;

// ---------- write ----------
function songSystem(cfg, brief) {
  return `You are the head songwriter of "DD TV English", a nursery-rhyme and kids' song channel for ${cfg.script.audience}.
${FORMULA}

${brief.kind === 'traditional'
  ? `Write the TRADITIONAL song "${brief.song}". Use the traditional public-domain lyrics (you may simplify, and you may add the counting/colour layer and a happy final verse). Allowed traditional songs ONLY: ${TRADITIONAL.join('; ')}. If the requested song is not on that list, write an ORIGINAL song on the same idea instead and set "kind": "original".`
  : `Write an ORIGINAL song (new lyrics and structure, never copied from any existing song) about: ${brief.song}.`}
Learning layer: ${brief.learning || 'writer\'s choice (counting is always good)'}.
Notes from the showrunner: ${brief.notes || '(none)'}

CHARACTERS: invent 1-4 cute, original characters for the song (animals are great), each with a concrete look and a pronoun.
For every line also write "visual": one sentence that shows exactly that line as a picture (who, doing what, where). Keep places consistent.
The intro has 1-2 lines; each verse 4 lines; an optional outro of 1-2 lines ("Let's sing it again!").

Reply with ONLY this JSON:
{ "title": "YouTube title, max 60 chars, like 'Five Little Ducks | Learn Colors | Kids Songs'",
  "kind": "traditional|original", "source": "song name (traditional) or 'original'",
  "learning": "...", "music_style": ["4-6 short style tags, e.g. cheerful preschool nursery rhyme, ukulele, glockenspiel, bouncy, clear happy vocals"],
  "characters": [ { "id": "lowercase", "name": "...", "look": "concrete visual description", "pronoun": "she|he", "role": "..." } ],
  "sections": [ { "name": "intro|verse 1|...|outro", "lines": [ { "text": "lyric line", "visual": "picture for this line" } ] } ],
  "description": "YouTube description, 2-3 sentences for parents", "tags": ["10 tags"],
  "thumbnail_prompt": "bright, simple close-up idea, no text" }`;
}

const EDITOR = `You are a strict editor of preschool songs. Check the song JSON against the formula and fix it:
- verses almost identical, only 1-3 words change; clear progression; learning layer present; happy ending
- every line short (max 9 words) and singable, similar rhythm in matching lines
- every visual shows exactly its line; characters and places consistent
Reply with ONLY the corrected full JSON in the same format.`;

function normalizeSong(raw) {
  const ids = new Set();
  const characters = (raw.characters || []).slice(0, 4).map(c => {
    let id = String(c.id || c.name || 'friend').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 14) || 'friend';
    while (ids.has(id)) id += 'x'; ids.add(id);
    return { id, name: String(c.name || id), look: String(c.look || '').trim(), role: String(c.role || ''),
      pronoun: /^he/i.test(c.pronoun || '') ? 'he/him' : 'she/her', voice_type: 'creature' };
  }).filter(c => c.look);
  const sections = (raw.sections || []).map(s => ({
    name: String(s.name || 'verse'),
    lines: (s.lines || []).map(l => ({ text: L.stripTags(String(l.text || l || '')).trim(), visual: String(l.visual || '').trim() })).filter(l => l.text).slice(0, 8),
  })).filter(s => s.lines.length).slice(0, 9);
  if (sections.length < 3) throw new Error(`song has only ${sections.length} sections`);
  const words = sections.reduce((t, s) => t + s.lines.reduce((u, l) => u + l.text.split(/\s+/).length, 0), 0);
  return { kind: 'song', song_kind: raw.kind === 'traditional' ? 'traditional' : 'original', source: String(raw.source || 'original'),
    title: String(raw.title || 'Kids Song').slice(0, 90), learning: String(raw.learning || ''), lesson: String(raw.learning || ''),
    music_style: (raw.music_style || []).map(String).slice(0, 6), characters, sections,
    description: String(raw.description || ''), tags: (raw.tags || []).map(String).slice(0, 15),
    thumbnail_prompt: String(raw.thumbnail_prompt || ''), words };
}

// turn the song into "scenes" (one per lyric line) with planned timing, so the director and renderer can use them
function toScenes(song, lineSeconds) {
  let n = 0;
  const scenes = [];
  for (const [si, s] of song.sections.entries()) for (const l of s.lines) {
    n++;
    const chars = song.characters.filter(c => new RegExp(`\\b${c.name}\\b`, 'i').test(`${l.visual} ${l.text}`)).map(c => c.id);
    scenes.push({ n, section: si, characters: chars.length ? chars.slice(0, 3) : song.characters.slice(0, 2).map(c => c.id),
      image_prompt: l.visual || l.text, animate: true, motion_prompt: `acting out: ${l.text}`,
      lines: [{ speaker: 'singer', text: l.text, sing: true }], planned_s: lineSeconds * (s.name === 'intro' ? 1.2 : 1) });
  }
  return scenes;
}

async function write({ cfg, sec, brief, feedback, prev }) {
  let user = `Write the song now.`;
  if (prev && feedback) user = `Previous version:\n${JSON.stringify(prev)}\n\nShowrunner feedback (priority):\n${feedback}\nRewrite the full song applying the feedback.`;
  let lastErr, song;
  for (let a = 1; a <= 2 && !song; a++) {
    try { song = normalizeSong(L.parseJSONLoose(await L.llm(cfg, sec, songSystem(cfg, brief), user + (a > 1 ? `\nYour previous reply was invalid (${lastErr}). JSON only.` : ''), { temperature: 0.8 }))); }
    catch (e) { lastErr = e.message; L.log(`song attempt ${a}: ${e.message}`); }
  }
  if (!song) throw new Error(`could not write the song: ${lastErr}`);
  try { song = normalizeSong(L.parseJSONLoose(await L.llm(cfg, sec, EDITOR + '\n\n' + FORMULA, JSON.stringify(song), { temperature: 0.4 }))); }
  catch (e) { L.log('song editor skipped:', e.message); }
  const lineS = (cfg.song && cfg.song.line_s) || 3.2;
  song.scenes = toScenes(song, lineS);
  return song;
}

function emailHtml(jobId, version, s) {
  const secs = Math.round(s.scenes.reduce((t, x) => t + x.planned_s, 0));
  const blocks = s.sections.map(sec => `<p style="margin:10px 0 2px"><b>${L.esc(sec.name)}</b></p>` +
    sec.lines.map(l => `<div style="margin-left:10px">🎵 ${L.esc(l.text)}<div style="color:#999;font-size:12px;margin-left:18px">🖼 ${L.esc(l.visual)}</div></div>`).join('')).join('');
  const chars = s.characters.map(c => `<b>${L.esc(c.name)}</b>: ${L.esc(c.look)}`).join('<br>');
  return `<div style="font-family:Arial,sans-serif;max-width:760px">
<h2 style="margin:0">🎵 ${L.esc(s.title)}</h2>
<p>${s.song_kind === 'traditional' ? `Traditional rhyme: <b>${L.esc(s.source)}</b>` : '<b>Original song</b>'} · learning: ${L.esc(s.learning)} · ${s.words} words · ≈ ${Math.floor(secs / 60)}m ${secs % 60}s · ${s.scenes.length} shots · draft v${version}</p>
<p style="color:#555">Music: ${L.esc(s.music_style.join(', '))}</p>
<p style="color:#555">${chars}</p>${blocks}
<p style="color:#666;font-size:13px">Approve = make the preview (the whole song + the first shots). Revise = say what to change.</p>
<p style="color:#888;font-size:12px">Job ${jobId}</p></div>`;
}

// ---------- produce ----------
async function produce({ cfg, sec, dir, jobId, S, PREVIEW, FF, family }) {
  const pad = n => String(n).padStart(3, '0');
  const f = (n, ext) => path.join(dir, `scene_${pad(n)}${ext}`);
  const has = p => { try { return fs.statSync(p).size > 0; } catch { return false; } };
  const r3 = x => Math.round(x * 1000) / 1000;
  const SG = cfg.song || {};
  const warnings = []; let cost = 0;

  // 1. characters of the song: one locked reference picture each (drawn once per job)
  const cdir = path.join(dir, 'characters'); fs.mkdirSync(cdir, { recursive: true });
  const cast = { narrator: 'singer', characters: S.characters.map(c => ({ ...c, ref: path.join(cdir, `${c.id}.jpg`) })) };
  const anchors = [];
  for (const c of cast.characters) {
    if (!has(c.ref)) {
      try {
        const r = await L.retry(() => L.genImage(cfg, sec, { prompt: `${cfg.style}. Character reference sheet of ONE character: ${c.name}, ${c.look}. Full body, facing the camera, happy, plain soft pastel background.` +
          (anchors.length ? ' Same art style as the reference images, but draw ONLY this character.' : ''), refs: anchors.slice(0, 2), width: 2048, height: 2048, file: c.ref }), 2, `draw ${c.id}`);
        cost += r.cost;
      } catch (e) { warnings.push(`Could not draw ${c.name}: ${e.message.slice(0, 80)}`); }
    }
    if (has(c.ref) && anchors.length < 2) anchors.push(L.fileToDataURI(c.ref));
  }
  const refs = Object.fromEntries(cast.characters.filter(c => has(c.ref)).map(c => [c.id, L.fileToDataURI(c.ref)]));

  // 2. the whole song, section by section with exact lyrics (so we know when each line is sung)
  const songFile = path.join(dir, 'song_full.mp3');
  const lineS = SG.line_s || 3.2;
  const secMs = S.sections.map(s => Math.max(3000, Math.round(s.lines.length * lineS * (s.name === 'intro' ? 1.2 : 1) * 1000)));
  if (!has(songFile)) {
    L.setStatus(dir, { stage: 'song' });
    const styles = S.music_style.length ? S.music_style : ['cheerful preschool nursery rhyme', 'bouncy', 'ukulele and glockenspiel', 'clear happy vocals'];
    const plan = { positive_global_styles: styles, negative_global_styles: ['scary', 'sad', 'explicit', 'heavy drums'],
      sections: S.sections.map((s, i) => ({ section_name: s.name, positive_local_styles: [], negative_local_styles: [], duration_ms: secMs[i], lines: s.lines.map(l => l.text) })) };
    try {
      await L.retry(() => L.elPost(sec, '/v1/music?output_format=mp3_44100_128', { composition_plan: plan, model_id: 'music_v1' }, songFile, 600000), 2, 'song');
    } catch (e) {
      L.log('composition plan failed, trying prompt:', e.message.slice(0, 160));
      await L.elPost(sec, '/v1/music?output_format=mp3_44100_128', { model_id: 'music_v1', music_length_ms: secMs.reduce((a, b) => a + b, 0),
        prompt: `${styles.join(', ')}. A preschool kids' song. Lyrics: ${S.sections.map(s => `[${s.name}] ${s.lines.map(l => l.text).join(' / ')}`).join(' ')}` }, songFile);
      warnings.push('The song was made from a prompt (not section by section), so picture timing is approximate.');
    }
  }
  // 3. timeline: planned section lengths, stretched to the real song length
  const total = await L.duration(FF, songFile);
  const planned = secMs.reduce((a, b) => a + b, 0) / 1000;
  const k = total / planned;
  let t = 0; const T = {};
  S.scenes.forEach(sc => { const sDur = secMs[sc.section] / 1000; const n = S.sections[sc.section].lines.length; T[sc.n] = { t0: r3(t), d: r3(sDur / n * k) }; t += sDur / n * k; });

  // 4. director (world sheet + one shot per line)
  let DIR = null;
  try { DIR = await director.plan({ cfg, sec, cast, S, dir, series: null }); cost += DIR.cost || 0; DIR.cost = 0; }
  catch (e) { warnings.push(`Prompt Director failed (${e.message.slice(0, 80)}).`); }
  const shotOf = n => DIR && DIR.shots.find(x => x.n === n);
  const work = PREVIEW ? S.scenes.slice(0, cfg.preview_scenes || 6) : S.scenes;

  // 5. pictures
  L.setStatus(dir, { stage: 'images' });
  await L.pool(work, cfg.image.concurrency || 3, async sc => {
    if (has(f(sc.n, '.jpg'))) return;
    const shot = shotOf(sc.n);
    const ids = (shot ? shot.characters : sc.characters).filter(id => refs[id]).slice(0, 3);
    const list = ids.map(id => ({ uri: refs[id], label: cast.characters.find(c => c.id === id).name }));
    if (shot) { const loc = DIR.world.locations.find(l => l.id === shot.location); if (loc && loc.ref && has(loc.ref)) list.push({ uri: L.fileToDataURI(loc.ref), label: `the place (${loc.name})` }); }
    const prompt = shot ? director.imagePrompt(cfg, shot, cast, DIR.world, list.map(x => x.label)) : `${cfg.style}. ${sc.image_prompt}`;
    const r = await L.retry(() => L.genImage(cfg, sec, { prompt, refs: list.map(x => x.uri), file: f(sc.n, '.jpg') }), 3, `image ${sc.n}`);
    cost += r.cost;
  });

  // 6. clips (one per line; lines are short so one clip always covers them)
  L.setStatus(dir, { stage: 'clips' });
  const V = cfg.video; const pending = [];
  for (const sc of work) {
    if (has(f(sc.n, '.mp4'))) continue;
    const shot = shotOf(sc.n);
    const prompt = `${shot ? director.motionPrompt(cfg, shot, sc, cast) : sc.motion_prompt}. Cheerful, bouncy movement in time with a happy song.`;
    try { pending.push({ sc, task: await L.submitVideo(cfg, sec, { imageFile: f(sc.n, '.jpg'), prompt, duration: T[sc.n].d > 5.2 ? 10 : 5 }) }); }
    catch (e) { L.log(`clip ${sc.n} submit failed: ${e.message}`); }
  }
  const deadline = Date.now() + V.max_wait_min * 60000;
  while (pending.length && Date.now() < deadline) {
    await L.sleep(V.poll_ms);
    let r; try { r = await L.runware(sec, pending.map(p => ({ taskType: 'getResponse', taskUUID: p.task })), 60000); } catch { continue; }
    for (const p of [...pending]) {
      const d = r.data.find(x => x.taskUUID === p.task && x.videoURL);
      const err = r.errors.find(x => x.taskUUID === p.task) || r.data.find(x => x.taskUUID === p.task && x.status === 'error');
      if (d) { pending.splice(pending.indexOf(p), 1); try { await L.download(d.videoURL, f(p.sc.n, '.mp4')); cost += d.cost || 0; } catch (e) { L.log(e.message); } }
      else if (err) { pending.splice(pending.indexOf(p), 1); L.log(`clip ${p.sc.n} failed`); }
    }
  }

  // 7. render: silent segments cut exactly to each line, then the song on top
  L.setStatus(dir, { stage: 'render' });
  const fps = cfg.render.fps;
  const segs = [];
  for (const sc of work) {
    const d = T[sc.n].d; const seg = f(sc.n, '_songseg.mp4');
    if (!has(seg)) {
      const v = has(f(sc.n, '.mp4'))
        ? ['-i', f(sc.n, '.mp4'), '-vf', `scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,setsar=1,fps=${fps},tpad=stop_mode=clone:stop_duration=${d},trim=duration=${d},format=yuv420p`]
        : ['-loop', '1', '-i', f(sc.n, '.jpg'), '-vf', `scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,setsar=1,fps=${fps},format=yuv420p`];
      await L.ff(FF, [...v, '-t', String(d), '-an', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', String(cfg.render.crf), '-video_track_timescale', '15360', seg], `segment ${sc.n}`);
    }
    segs.push(seg);
  }
  fs.writeFileSync(path.join(dir, 'songconcat.txt'), segs.map(x => `file '${x}'`).join('\n'));
  const vid = path.join(dir, 'songvideo.mp4');
  await L.ff(FF, ['-f', 'concat', '-safe', '0', '-i', path.join(dir, 'songconcat.txt'), '-c', 'copy', vid], 'concat');
  const vlen = await L.duration(FF, vid);
  const final = path.join(dir, PREVIEW ? 'preview.mp4' : 'final.mp4');
  await L.ff(FF, ['-i', vid, '-i', songFile, '-filter_complex', `[1:a]atrim=duration=${vlen},afade=t=out:st=${Math.max(0, vlen - 1.5).toFixed(2)}:d=1.5,loudnorm=I=-14:TP=-1.5:LRA=11[a]`,
    '-map', '0:v', '-map', '[a]', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-t', String(vlen), '-movflags', '+faststart', final], 'final');

  const slug = S.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
  const costTotal = r3((L.readJSON(path.join(dir, 'status.json'), {}).cost_total || 0) + cost);
  const mins = `${Math.floor(vlen / 60)}:${String(Math.round(vlen % 60)).padStart(2, '0')}`;
  const base = { ok: true, jobId, next_job: '', notify_email: cfg.notify_email, drive_parent: cfg.drive_parent_folder_id || 'root',
    length: mins, clips: work.filter(sc => has(f(sc.n, '.mp4'))).length, scenes: work.length, cost: costTotal, warnings,
    description: S.description, lesson: S.learning, tags: S.tags.join(', ') };
  if (PREVIEW) {
    L.setStatus(dir, { stage: 'preview_ready', cost_total: costTotal });
    return { ...base, preview: true, title: `PREVIEW · ${S.title}`, part: `First ${work.length} of ${S.scenes.length} shots (the song is complete)`,
      folder_name: `DD TV English – PREVIEW – ${S.title} (${jobId})`, files: [{ path: final, name: `0_${slug}_PREVIEW.mp4` }], shorts: [] };
  }

  // 8. a Short (first ~40 s, vertical) and a thumbnail
  const short = path.join(dir, 'short_1.mp4');
  const sl = Math.min(40, vlen);
  await L.ff(FF, ['-i', final, '-t', String(sl), '-filter_complex', `[0:v]split[a][b];[a]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=24:3[bg];[b]scale=1728:-2,crop=1080:ih[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1,format=yuv420p[v];[0:a]afade=t=out:st=${(sl - 1).toFixed(2)}:d=1[a]`,
    '-map', '[v]', '-map', '[a]', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-c:a', 'aac', '-movflags', '+faststart', short], 'short');
  const thumb = path.join(dir, 'thumbnail.jpg');
  if (!has(thumb)) {
    try {
      const raw = path.join(dir, 'thumbnail_raw.jpg');
      const r = await L.genImage(cfg, sec, { prompt: `${cfg.style}. YouTube thumbnail, bold, bright, close-up, big happy faces. ${S.thumbnail_prompt}`, refs: Object.values(refs).slice(0, 3), file: raw });
      cost += r.cost;
      await L.ff(FF, ['-i', raw, '-vf', 'scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720', '-q:v', '3', thumb], 'thumb');
    } catch (e) { warnings.push('Thumbnail failed; pick a frame instead.'); }
  }
  const meta = path.join(dir, 'metadata.txt');
  fs.writeFileSync(meta, [`TITLE: ${S.title}`, '', 'DESCRIPTION:', S.description, '', `TAGS: ${S.tags.join(', ')}`, '', 'LYRICS:', ...S.sections.flatMap(s => ['', ...s.lines.map(l => l.text)])].join('\n'));
  L.setStatus(dir, { stage: 'ready', cost_total: r3(costTotal + cost) });
  return { ...base, cost: r3(costTotal + cost), title: S.title, part: 'Song episode', folder_name: `DD TV English – ${S.title} (${jobId})`,
    files: [{ path: final, name: `1_${slug}_LONG.mp4` }, { path: short, name: `2_${slug}_SHORT_1.mp4` },
      ...(has(thumb) ? [{ path: thumb, name: `3_${slug}_thumbnail.jpg` }] : []), { path: meta, name: `4_${slug}_metadata.txt` }],
    shorts: [`${S.title.split('|')[0].trim()} #shorts`] };
}

module.exports = { write, produce, emailHtml, TRADITIONAL, FORMULA };
