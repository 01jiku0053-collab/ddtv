'use strict';
// TREND RESEARCH: which kids' songs and rhymes got the most views on YouTube in the last N months.
// Uses the official YouTube Data API (secrets.json -> youtube_key). Results are cached for 3 days.
// Only titles, channels, view counts and the start of descriptions are used: to spot TRENDS, never to copy.
const fs = require('fs');
const path = require('path');
const L = require('./lib');

const QUERIES = ['nursery rhymes', 'kids songs', 'counting song for kids', 'colors song for kids', 'animal song for kids',
  'bedtime song for kids', 'finger family song', 'baby songs toddlers', 'phonics song kids', 'good habits song for kids'];

async function yt(pathQ, key) {
  const r = await L.fetchT(`${process.env.YT_BASE || 'https://www.googleapis.com/youtube/v3'}/${pathQ}&key=${key}`, {}, 30000);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`YouTube API ${r.status}: ${JSON.stringify(j.error || j).slice(0, 200)}`);
  return j;
}

async function trending(cfg, sec, { months = 6, force = false } = {}) {
  const file = path.join(L.ROOT, 'research', 'trending.json');
  const cached = L.readJSON(file, null);
  if (!force && cached && Date.now() - Date.parse(cached.created) < 3 * 86400e3) return cached;
  if (!sec.youtube_key) return { created: new Date().toISOString(), live: false, items: [], note: 'no youtube_key in secrets.json' };
  const after = new Date(Date.now() - months * 30 * 86400e3).toISOString();
  const ids = new Set();
  for (const q of (cfg.research && cfg.research.queries) || QUERIES) {
    try {
      const j = await yt(`search?part=id&type=video&order=viewCount&maxResults=25&safeSearch=strict&relevanceLanguage=en&publishedAfter=${after}&q=${encodeURIComponent(q)}`, sec.youtube_key);
      (j.items || []).forEach(i => i.id && i.id.videoId && ids.add(i.id.videoId));
    } catch (e) { L.log(`research "${q}" skipped: ${e.message}`); }
  }
  const list = [...ids];
  const items = [];
  for (let i = 0; i < list.length; i += 50) {
    try {
      const j = await yt(`videos?part=snippet,statistics,contentDetails&id=${list.slice(i, i + 50).join(',')}`, sec.youtube_key);
      for (const v of j.items || []) {
        const views = +(v.statistics && v.statistics.viewCount) || 0;
        const days = Math.max(1, (Date.now() - Date.parse(v.snippet.publishedAt)) / 86400e3);
        items.push({ id: v.id, title: v.snippet.title, channel: v.snippet.channelTitle, published: v.snippet.publishedAt.slice(0, 10),
          views, views_per_day: Math.round(views / days), duration: v.contentDetails && v.contentDetails.duration,
          description: String(v.snippet.description || '').slice(0, 700) });
      }
    } catch (e) { L.log('video details skipped:', e.message); }
  }
  items.sort((a, b) => b.views_per_day - a.views_per_day);
  const out = { created: new Date().toISOString(), live: true, months, items: items.slice(0, 80) };
  L.writeJSON(file, out);
  return out;
}

// a compact text block for the idea writer
function summary(data, n = 40) {
  if (!data.live || !data.items.length) return '';
  return data.items.slice(0, n).map((v, i) =>
    `${i + 1}. "${v.title}" | ${v.channel} | ${v.views.toLocaleString('en')} views | ${v.views_per_day.toLocaleString('en')}/day | ${v.published}`).join('\n');
}

module.exports = { trending, summary };

if (require.main === module) L.main(async () => {
  const { cfg, sec } = L.loadAll();
  const d = await trending(cfg, sec, { force: true });
  return { ok: d.live, count: d.items.length, note: d.note || '', top: d.items.slice(0, 10).map(v => `${v.title} | ${v.channel} | ${v.views} views`) };
});
