'use strict';
// The Prompt Director. Runs once per script version, before any picture is made:
//   1) WORLD SHEET: fixed Location Cards (+ one reference picture each), the time-of-day flow and the colour palette
//   2) SHOT PLAN: for every scene, derived from its lines: action, who is visible, expressions, shot type,
//      lighting, and movement (camera / characters / environment)
//   3) CHECKS in code: speakers are visible, no repeated shot types, close-ups max 2 characters, viewer lines face camera
// Final prompts are ASSEMBLED IN CODE so Look Cards are always pasted in full, word for word.
const fs = require('fs');
const path = require('path');
const L = require('./lib');

const SHOTS = {
  'extreme wide': 'Extreme wide establishing shot, the characters small in a big, detailed environment',
  'wide': 'Wide shot showing the whole scene and everyone in it, full bodies visible',
  'medium': 'Medium shot, characters framed from the knees up, clear body language',
  'close-up': 'Close-up shot of the face and shoulders, big clear expression',
  'extreme close-up': 'Extreme close-up on one important detail',
  'low angle': 'Low-angle shot looking up, making the moment feel big and exciting',
  'high angle': 'High-angle shot looking down on the scene',
  'over-shoulder': 'Over-the-shoulder shot from behind one character, looking at the other',
  'foreground-framed': 'Shot framed through a foreground object like a doorway, leaves or a window',
};
const SHOT_KEYS = Object.keys(SHOTS);

const toCard = c => `${c.name} is ${c.look}`;
const cleanId = s => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');

async function jsonCall(cfg, sec, system, user, label, temperature = 0.5) {
  let lastErr;
  for (let a = 1; a <= 2; a++) {
    try { return L.parseJSONLoose(await L.llm(cfg, sec, system, user + (a > 1 ? `\n\nYour previous reply was invalid (${lastErr}). Reply with the complete JSON only.` : ''), { temperature })); }
    catch (e) { lastErr = e.message; L.log(`${label} attempt ${a} failed: ${e.message}`); }
  }
  throw new Error(`${label} failed: ${lastErr}`);
}

function scriptText(S, name) {
  return S.scenes.map(sc => `Scene ${sc.n}: ` + sc.lines.map(l => `${name[l.speaker] || l.speaker}: "${l.text}"`).join(' ')).join('\n');
}

// ---------- 1. world sheet ----------
async function worldSheet(cfg, sec, S, cast, name, story) {
  const sys = `You are the production designer of a preschool animated series. Build the WORLD SHEET for this episode.
Art style of the show: ${cfg.style}

Rules:
- 2 to 5 LOCATIONS, only places the story really uses. Each gets a Location Card: 40-70 words describing ONLY the place (no characters):
  layout, size compared to the characters, materials, 3-4 main colours, 3-5 key props, what is in the background. Concrete and drawable, so it looks the same every time.
- TIME FLOW: how time of day and weather change through the story (e.g. "sunny afternoon -> windy golden evening -> cosy lamp-lit night -> first snow").
- PALETTE: 3-4 main colours for the whole episode plus one warm accent.
Reply with ONLY this JSON:
{ "locations": [ { "id": "short_id", "name": "...", "card": "..." } ], "time_flow": "...", "palette": "..." }`;
  const user = `${story ? `Story: ${story}\n` : ''}Characters: ${cast.characters.map(c => c.name).join(', ')}\n\nSCRIPT:\n${scriptText(S, name)}`;
  const w = await jsonCall(cfg, sec, sys, user, 'world sheet', 0.6);
  const seen = new Set();
  w.locations = (w.locations || []).map(l => {
    let id = cleanId(l.id || l.name).slice(0, 20) || 'place';
    while (seen.has(id)) id += 'x';
    seen.add(id);
    return { id, name: String(l.name || id), card: String(l.card || '').trim() };
  }).filter(l => l.card).slice(0, 6);
  if (!w.locations.length) throw new Error('world sheet has no locations');
  return { locations: w.locations, time_flow: String(w.time_flow || ''), palette: String(w.palette || '') };
}

// ---------- 2. shot plan (in batches, so every scene gets full attention) ----------
async function shotBatch(cfg, sec, batch, world, cast, name, prevShot, allText) {
  const sys = `You are the storyboard director of a preschool animated series. For each scene you receive, plan ONE animated shot.
The picture must show EXACTLY what is happening while those lines are spoken: the action the lines describe, the character who is speaking, and their feeling.

CAST (ids): ${cast.characters.map(c => `${c.id} = ${c.name}`).join(', ')}
LOCATIONS (ids): ${world.locations.map(l => `${l.id} = ${l.name}`).join(', ')}
TIME FLOW: ${world.time_flow}
PALETTE: ${world.palette}

RULES
- "characters": ids of everyone VISIBLE (max 3). Whoever speaks must be visible. The storyteller (${cast.narrator}) is visible only when she is part of the scene.
- "shot": one of ${SHOT_KEYS.map(k => `"${k}"`).join(', ')}. Vary it: never the same shot twice in a row. Wide/extreme wide for new places, close-up for feelings and jokes landing, low angle for big exciting moments.
- "action": 1-2 sentences, what is visibly happening, concrete (poses, what hands/paws do, objects).
- "expressions": a short expression for each visible character.
- "lighting": the light for this moment, following the time flow (direction, warmth, soft shadows).
- "camera": ONE camera move for the 5-10 second clip (slow push in, gentle pan left/right, tilt up, dolly forward, small shake for a bump, or static for a joke).
- "movement": what the characters DO during the clip, in order (big clear cartoon acting).
- "environment": what moves in the world (leaves, steam, snow, water, light).
- "to_camera": true if a character talks to the viewer in this scene.
- "sfx": ONE short sound effect that makes this moment funnier or clearer (e.g. "springy boing", "big splash", "soft whoosh of wind", "tiny pop", "wooden door creak"), or "" when the scene needs none. Use one in about half the scenes, always for jokes, bumps, surprises and magic.
- CONTINUITY: characters appear only when the story brings them in; within the same place, keep each character where they were in the previous shot (same side of the frame, same props) unless the lines say they move.
- TALKING: while a character speaks, use a medium or wide shot (never a close-up of a talking mouth); close-ups are for silent reactions.
- Never show the viewer or any child/person who is not in the cast. No text or letters in the picture.

Reply with ONLY this JSON:
{ "shots": [ { "n": 1, "location": "id", "characters": ["id"], "shot": "medium", "action": "...", "expressions": { "id": "..." },
  "lighting": "...", "camera": "...", "movement": "...", "environment": "...", "to_camera": false, "sfx": "" } ] }`;
  const user = `WHOLE STORY (for context):\n${allText}\n\nPrevious shot type: ${prevShot || 'none'}\n\nPLAN THESE SCENES:\n${scriptText({ scenes: batch }, name)}`;
  const r = await jsonCall(cfg, sec, sys, user, `shot plan ${batch[0].n}-${batch[batch.length - 1].n}`);
  return Array.isArray(r.shots) ? r.shots : [];
}

// ---------- 3. checks ----------
function check(shots, S, cast, world) {
  const ids = new Set(cast.characters.map(c => c.id));
  const locs = new Set(world.locations.map(l => l.id));
  const fixes = [];
  let prev = '';
  S.scenes.forEach((sc, i) => {
    const s = shots[i] = shots[i] || {};
    s.n = sc.n;
    s.characters = [...new Set((s.characters || []).map(cleanId).filter(x => ids.has(x)))];
    // whoever speaks must be visible (the storyteller may speak off-screen)
    for (const sp of [...new Set(sc.lines.map(l => l.speaker))]) {
      if (sp !== cast.narrator && ids.has(sp) && !s.characters.includes(sp)) { s.characters.unshift(sp); fixes.push(`scene ${sc.n}: added speaker ${sp}`); }
    }
    if (!s.characters.length && sc.characters && sc.characters.length) s.characters = sc.characters.slice(0, 3);
    if (s.characters.length > 3) s.characters = s.characters.slice(0, 3);
    s.shot = SHOTS[s.shot] ? s.shot : 'medium';
    if (/close-up/.test(s.shot) && s.characters.length > 2) { s.shot = 'medium'; fixes.push(`scene ${sc.n}: close-up with 3 characters -> medium`); }
    const visibleTalkers = sc.lines.some(l => l.speaker !== cast.narrator && s.characters.includes(l.speaker) && !l.sing);
    if (/close-up/.test(s.shot) && visibleTalkers) { s.shot = 'medium'; fixes.push(`scene ${sc.n}: talking close-up -> medium`); }
    const talksToViewer = s.to_camera || sc.lines.some(l => /\b(can you|do you|will you|shout|say it with|help me|with me)\b/i.test(l.text));
    s.to_camera = !!talksToViewer;
    if (s.shot === prev) {
      const alt = ['medium', 'close-up', 'wide', 'low angle', 'over-shoulder'].find(k => k !== prev && !(/close-up/.test(k) && (s.characters.length > 2 || visibleTalkers)));
      fixes.push(`scene ${sc.n}: repeated "${prev}" -> "${alt}"`); s.shot = alt;
    }
    prev = s.shot;
    if (!locs.has(cleanId(s.location))) s.location = (shots[i - 1] && shots[i - 1].location) || world.locations[0].id;
    else s.location = cleanId(s.location);
    s.action = String(s.action || sc.image_prompt || '').trim();
    s.expressions = s.expressions || {};
    for (const k of ['lighting', 'camera', 'movement', 'environment', 'sfx']) s[k] = String(s[k] || '').trim();
    s.sfx = s.sfx.slice(0, 80);
  });
  return fixes;
}

// ---------- prompt assembly (code, not AI) ----------
function imagePrompt(cfg, shot, cast, world, refOrder) {
  const byId = Object.fromEntries(cast.characters.map(c => [c.id, c]));
  const loc = world.locations.find(l => l.id === shot.location) || world.locations[0];
  const chars = shot.characters.map(id => byId[id]).filter(Boolean);
  const who = chars.map(c => `${toCard(c)}; expression: ${shot.expressions[c.id] || 'happy and lively'}.`).join(' ');
  const refs = refOrder.length ? ` Reference images in order: ${refOrder.map((r, i) => `image ${i + 1} = ${r}`).join(', ')}. Draw each character exactly like their reference image (same face, colours, outfit, proportions) and the place like its reference.` : '';
  const parts = [
    `${SHOTS[shot.shot]}.`,
    shot.action && (/[.!?]$/.test(shot.action) ? shot.action : shot.action + '.'),
    shot.to_camera ? 'The speaking character looks straight into the camera, talking to the viewer.' : '',
    chars.length ? `Characters in this picture (only these): ${who}` : 'No characters in this picture.',
    `Setting: ${loc.name}: ${loc.card}`,
    shot.lighting ? `Lighting: ${shot.lighting}.` : '',
    world.palette ? `Colours: ${world.palette}.` : '',
    refs,
    cfg.style,
  ];
  let p = parts.filter(Boolean).join(' ');
  const max = (cfg.image && cfg.image.max_prompt_chars) || 2900;
  if (p.length > max) p = parts.filter(Boolean).filter(x => !x.startsWith('Colours:')).join(' ');   // drop the least important part first
  return p.slice(0, max);
}

function motionPrompt(cfg, shot, sc, cast) {
  const byId = Object.fromEntries(cast.characters.map(c => [c.id, c.name]));
  const talkers = [...new Set(sc.lines.map(l => l.speaker))].filter(id => shot.characters.includes(id)).map(id => byId[id]);
  return [
    shot.camera && `Camera: ${shot.camera}.`,
    shot.movement && (/[.!?]$/.test(shot.movement) ? shot.movement : shot.movement + '.'),
    talkers.length ? `${talkers.join(' and ')} ${talkers.length > 1 ? 'talk' : 'talks'} with small, gentle mouth movements and lively gestures.` : '',
    shot.to_camera ? 'Looks into the camera while talking.' : '',
    shot.environment && (/[.!?]$/.test(shot.environment) ? shot.environment : shot.environment + '.'),
    (cfg.video && cfg.video.motion_tail) || 'Smooth, lively cartoon animation; characters stay exactly on-model; no morphing.',
    'Only the characters already in the picture; nobody new appears; the background and places stay exactly the same.',
  ].filter(Boolean).join(' ').slice(0, 1900);
}

// ---------- main entry ----------
async function plan({ cfg, sec, cast, S, dir, series, FF }) {
  const file = path.join(dir, 'shots.json');
  const cached = L.readJSON(file, null);
  if (cached && cached.script_version === S.version && cached.scenes === S.scenes.length) return cached;
  const name = Object.fromEntries(cast.characters.map(c => [c.id, c.name]));

  // world sheet: shared by all parts of a series, so places stay the same across episodes
  const worldDir = series ? path.join(series.dir, 'world') : path.join(dir, 'world');
  fs.mkdirSync(worldDir, { recursive: true });
  let world = L.readJSON(path.join(worldDir, 'world.json'), null);
  if (!world) {
    world = await worldSheet(cfg, sec, S, cast, name, series ? `${series.bible.series_title}: ${series.bible.logline}` : '');
    L.writeJSON(path.join(worldDir, 'world.json'), world);
  }
  // one reference picture per location (no characters), drawn once
  let cost = 0;
  for (const l of world.locations) {
    const img = path.join(worldDir, `${l.id}.jpg`);
    if (!fs.existsSync(img)) {
      try {
        const r = await L.retry(() => L.genImage(cfg, sec, { prompt: `${cfg.style}. Empty background plate of a location, no characters, no animals, no people: ${l.name}: ${l.card}. Wide shot, ${world.time_flow.split(/->|→/)[0] || 'soft daylight'}. Colours: ${world.palette}.`, file: img }), 2, `location ${l.id}`);
        cost += r.cost;
      } catch (e) { L.log(`location picture ${l.id} skipped: ${e.message}`); }
    }
    l.ref = fs.existsSync(img) ? img : null;
  }

  // shot plan in batches of 8
  const allText = scriptText(S, name);
  const shots = [];
  for (let i = 0; i < S.scenes.length; i += 8) {
    const batch = S.scenes.slice(i, i + 8);
    let got = [];
    try { got = await shotBatch(cfg, sec, batch, world, cast, name, shots.length ? shots[shots.length - 1].shot : '', allText); }
    catch (e) { L.log(e.message); }
    for (const sc of batch) shots.push(got.find(g => +g.n === sc.n) || {});
  }
  const fixes = check(shots, S, cast, world);
  if (fixes.length) L.log(`director fixes: ${fixes.join('; ')}`);
  const out = { script_version: S.version, scenes: S.scenes.length, world, shots, fixes, cost };
  L.writeJSON(file, out);
  return out;
}

module.exports = { plan, imagePrompt, motionPrompt, SHOTS };
