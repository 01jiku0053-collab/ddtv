'use strict';
// usage (inside the n8n container): node patch_workflow.js <credentials-export.json> <workflow.json> <out.json>
// Reads n8n's own credential list (names/types/ids only; secrets stay encrypted and are not used)
// and attaches the right Gmail / Google Drive credential to every node that needs one.
const fs = require('fs');
const [credFile, wfFile, outFile] = process.argv.slice(2);
const creds = JSON.parse(fs.readFileSync(credFile, 'utf8'));
const wf = JSON.parse(fs.readFileSync(wfFile, 'utf8'));

function choose(type, preferName) {
  const list = creds.filter(c => c.type === type);
  return list.find(c => preferName.test(c.name)) || list[0] || null;
}
const gmail = choose('gmailOAuth2', /gmail/i);
const drive = choose('googleDriveOAuth2Api', /^google drive account$/i);
let g = 0, d = 0;
for (const n of wf.nodes) {
  if (n.type === 'n8n-nodes-base.gmail' && gmail) { n.credentials = { gmailOAuth2: { id: gmail.id, name: gmail.name } }; g++; }
  if (n.type === 'n8n-nodes-base.googleDrive' && drive) { n.credentials = { googleDriveOAuth2Api: { id: drive.id, name: drive.name } }; d++; }
}
// n8n's database needs an id; a fixed one means future updates replace this same workflow.
wf.id = wf.id || 'ddtvEnglishPipe1';
fs.writeFileSync(outFile, JSON.stringify(wf));
console.log(`Gmail credential: ${gmail ? `"${gmail.name}" -> ${g} nodes` : 'NOT FOUND (select it by hand in n8n)'}`);
console.log(`Drive credential: ${drive ? `"${drive.name}" -> ${d} nodes` : 'NOT FOUND (select it by hand in n8n)'}`);
