'use strict';
// usage: node produce.js <jobId>
// Resumable: every step skips files that already exist, so a re-run after a failure
// only pays for what is missing. Delete a file (e.g. scene_007.jpg) to regenerate just that.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const L = require('./lib');
const director = require('./director');

const pad = n => String(n).padStart(3, '0');
const r3 = x => Math.round(x * 1000) / 1000;
const exists = f => { try { return fs.statSync(f).size > 0; } catch { return false; } };

L.main(async () => {
  const jobId = process.argv[2];
  const dir = L.jobDir(jobId);
  const { cfg, cast: family, sec } = L.loadAll();
  const series = L.seriesOf(jobId);
  const cast = L.castFor(cfg, family, series);
  const S = L.readJSON(path.join(dir, 'script.json'));
  const brief = L.readJSON(path.join(dir, 'brief.json'), { format: 'story' });
  const FF = L.ffmpegBin(cfg);
  const R = cfg.render;
  const warnings = [];
  let cost = 0;
  const byId = Object.fromEntries(cast.characters.map(c => [c.id, c]));
  const f = (n, ext) => path.join(dir, `scene_${pad(n)}${ext}`);
  L.setStatus(dir, { stage: 'producing', started: new Date().toISOString() });

  // ---------- character reference images ----------
  const refs = {};
  for (const c of cast.characters) if (exists(c.ref)) refs[c.id] = L.fileToDataURI(c.ref);
  const onScreen = new Set(S.scenes.flatMap(sc => sc.characters));  // (director may add speakers; refs checked per scene)
  const noRef = cast.characters.filter(c => onScreen.has(c.id) && !refs[c.id]).map(c => c.name);
  if (noRef.length) warnings.push(`No reference image for ${noRef.join(', ')}: they may look different from scene to scene (DD family: use the Character Setup form).`);

  const charText = ids => ids.map(id => byId[id]).filter(Boolean).map(c => `${c.name} is ${c.look}`).join('. ');
  const scenePrompt = sc => {
    const hasRefs = sc.characters.some(id => refs[id]);
    return `${cfg.style}. ${sc.image_prompt}. ${charText(sc.characters)}.` +
      (hasRefs ? ' Draw each character exactly like their reference image: same face, hair, outfit, colours and art style.' : '');
  };

  // ---------- 0. Prompt Director (world sheet + shot plan) ----------
  let DIR = null;
  if (cfg.director !== false) {
    L.setStatus(dir, { stage: 'directing' });
    try { DIR = await director.plan({ cfg, sec, cast, S, dir, series }); cost += DIR.cost || 0; DIR.cost = 0; }
    catch (e) { L.log('director failed:', e.message); warnings.push(`Prompt Director failed (${e.message.slice(0, 100)}); simple prompts were used.`); }
  }
  const byIdx = n => DIR && DIR.shots.find(x => x.n === n);
  // refs for one scene: its characters (max 3) + its location, with names in the same order for the prompt
  function sceneRefs(sc) {
    const shot = byIdx(sc.n);
    const ids = shot ? shot.characters : sc.characters;
    const list = ids.filter(id => refs[id]).slice(0, 3).map(id => ({ uri: refs[id], label: byId[id].name }));
    if (shot) {
      const loc = DIR.world.locations.find(l => l.id === shot.location);
      if (loc && loc.ref && exists(loc.ref)) list.push({ uri: L.fileToDataURI(loc.ref), label: `the place (${loc.name})` });
    }
    return list;
  }

  // ---------- 1. images ----------
  L.setStatus(dir, { stage: 'images' });
  let refMiss = 0;
  await L.pool(S.scenes, cfg.image.concurrency || 3, async sc => {
    if (exists(f(sc.n, '.jpg'))) return;
    const r = await L.retry(() => L.genImage(cfg, sec, {
      prompt: byIdx(sc.n) ? director.imagePrompt(cfg, byIdx(sc.n), cast, DIR.world, sceneRefs(sc).map(r => r.label)) : scenePrompt(sc),
      refs: sceneRefs(sc).map(r => r.uri), file: f(sc.n, '.jpg'),
    }), 3, `image ${sc.n}`);
    cost += r.cost;
    if (sc.characters.some(id => refs[id]) && !r.usedRefs) refMiss++;
    L.log(`image ${sc.n}/${S.scenes.length} done`);
  });
  if (refMiss) warnings.push(`${refMiss} image(s) were made without character references because Runware rejected the reference format. Check produce.log.`);

  // ---------- 3. voices ----------
  L.setStatus(dir, { stage: 'voices' });
  const narratorVoice = (byId[cast.narrator] || {}).voice_id || cfg.voice.narrator_voice_id;
  const fallback = new Set();
  const lineJobs = [];
  for (const sc of S.scenes) sc.lines.forEach((ln, i) => {
    let v = (byId[ln.speaker] || {}).voice_id;
    if (!v) { v = narratorVoice; if (ln.speaker !== cast.narrator) fallback.add((byId[ln.speaker] || {}).name || ln.speaker); }
    lineJobs.push({ file: path.join(dir, `line_${pad(sc.n)}_${String(i + 1).padStart(2, '0')}.mp3`), text: ln.text, voiceId: v });
  });
  await L.pool(lineJobs, cfg.voice.concurrency || 3, async j => {
    if (exists(j.file)) return;
    await L.retry(() => L.tts(cfg, sec, j), 3, `voice ${path.basename(j.file)}`);
  });
  if (fallback.size) warnings.push(`No voice_id set for ${[...fallback].join(', ')}: their lines used the narrator voice. Add voice IDs (DD family: characters.json · story characters: voice.pool in config.json).`);

  // ---------- 4. scene audio + timing ----------
  L.setStatus(dir, { stage: 'timing' });
  const D = {};
  for (const sc of S.scenes) {
    const wav = f(sc.n, '.wav');
    if (!exists(wav)) {
      const files = sc.lines.map((_, i) => path.join(dir, `line_${pad(sc.n)}_${String(i + 1).padStart(2, '0')}.mp3`));
      const parts = files.map((_, i) => `[${i}:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo${i < files.length - 1 ? `,apad=pad_dur=${R.line_gap_s}` : ''}[a${i}]`);
      const fc = parts.join(';') + ';' + files.map((_, i) => `[a${i}]`).join('') + `concat=n=${files.length}:v=0:a=1[out]`;
      await L.ff(FF, [...files.flatMap(x => ['-i', x]), '-filter_complex', fc, '-map', '[out]', '-c:a', 'pcm_s16le', wav], `scene ${sc.n} audio`);
    }
    D[sc.n] = r3(Math.max(R.min_scene_s, R.scene_lead_s + await L.duration(FF, wav) + R.scene_tail_s));
  }

  // ---------- 2. animated clips (non-fatal: a failed clip becomes a slow-zoom still) ----------
  L.setStatus(dir, { stage: 'clips' });
  const V = cfg.video;
  const haveClips = S.scenes.filter(sc => exists(f(sc.n, '.mp4'))).length;
  const todo = S.scenes.filter(sc => sc.animate && !exists(f(sc.n, '.mp4')) && !exists(f(sc.n, '.noclip')))
    .slice(0, Math.max(0, (V.max_clips || 0) - haveClips));
  const pending = [];
  let clipFails = 0;
  const lengths = (V.durations || [V.duration]).slice().sort((x, y) => x - y);
  for (const sc of todo) {
    try {
      const prompt = byIdx(sc.n) ? director.motionPrompt(cfg, byIdx(sc.n), sc, cast) : `${sc.motion_prompt || 'gentle happy movement'}. ${V.motion_style}. ${charText(sc.characters)}`;
      const want = lengths.find(x => x >= D[sc.n] - 0.2) || lengths[lengths.length - 1];
      let task;
      try { task = await L.submitVideo(cfg, sec, { imageFile: f(sc.n, '.jpg'), prompt, duration: want }); }
      catch (e) { if (want === V.duration) throw e; L.log(`clip ${sc.n}: ${want}s rejected, using ${V.duration}s`); task = await L.submitVideo(cfg, sec, { imageFile: f(sc.n, '.jpg'), prompt, duration: V.duration }); }
      pending.push({ sc, task });
    } catch (e) {
      clipFails++; L.log(`clip ${sc.n} submit failed: ${e.message}`);
      if (/401|402|insufficient|credit/i.test(e.message)) { warnings.push('Runware refused video clips (credit/auth?). Remaining scenes use stills.'); break; }
    }
  }
  const deadline = Date.now() + V.max_wait_min * 60000;
  while (pending.length && Date.now() < deadline) {
    await L.sleep(V.poll_ms);
    let r;
    try { r = await L.runware(sec, pending.map(p => ({ taskType: 'getResponse', taskUUID: p.task })), 60000); }
    catch (e) { L.log('poll error', e.message); continue; }
    for (const p of [...pending]) {
      const d = r.data.find(x => x.taskUUID === p.task && x.videoURL);
      const err = r.errors.find(x => x.taskUUID === p.task) || r.data.find(x => x.taskUUID === p.task && x.status === 'error');
      if (d) {
        try { await L.download(d.videoURL, f(p.sc.n, '.mp4')); cost += d.cost || 0; L.log(`clip ${p.sc.n} done`); }
        catch (e) { clipFails++; L.log(`clip ${p.sc.n} download failed`, e.message); }
        pending.splice(pending.indexOf(p), 1);
      } else if (err) {
        clipFails++; L.log(`clip ${p.sc.n} failed: ${JSON.stringify(err).slice(0, 200)}`);
        fs.writeFileSync(f(p.sc.n, '.noclip'), JSON.stringify(err));
        pending.splice(pending.indexOf(p), 1);
      }
    }
  }
  if (pending.length) { clipFails += pending.length; L.log(`${pending.length} clip(s) timed out`); }
  if (clipFails) warnings.push(`${clipFails} animated clip(s) failed or timed out; those scenes use a slow zoom instead. Re-run "Resume Production" to retry them (delete scene_NNN.noclip first).`);

  L.setStatus(dir, { cost_total: r3((L.readJSON(path.join(dir, 'status.json'), {}).cost_total || 0) + cost), stage: 'render' }); cost = 0;
  // ---------- 5. scene video segments ----------
  const fps = R.fps;
  const venc = ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', String(R.crf), '-pix_fmt', 'yuv420p', '-r', String(fps),
    '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-ac', '2', '-video_track_timescale', '15360'];
  const lead = Math.round(R.scene_lead_s * 1000);
  await L.pool(S.scenes, 2, async sc => {
    const seg = f(sc.n, '_seg.mp4');
    if (exists(seg)) return;
    const d = D[sc.n];
    const aFilt = `[1:a]adelay=${lead}|${lead},apad=whole_dur=${d},atrim=duration=${d}[a]`;
    let args;
    if (exists(f(sc.n, '.mp4'))) {
      const cd = await L.duration(FF, f(sc.n, '.mp4')).catch(() => V.duration);
      const slow = r3(Math.min(Math.max(d / cd, 1), R.max_clip_slowdown));
      const v = `[0:v]scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,setsar=1,setpts=${slow}*PTS,fps=${fps},tpad=stop_mode=clone:stop_duration=${d},trim=duration=${d},setpts=PTS-STARTPTS,format=yuv420p[v]`;
      args = ['-i', f(sc.n, '.mp4'), '-i', f(sc.n, '.wav'), '-filter_complex', `${v};${aFilt}`];
    } else {
      const frames = Math.ceil(d * fps), zmax = 1.12;
      const z = sc.n % 2 ? `1+${zmax - 1}*on/${frames}` : `${zmax}-${r3(zmax - 1)}*on/${frames}`;
      const v = `[0:v]scale=3840:2160:force_original_aspect_ratio=increase,crop=3840:2160,zoompan=z='${z}':d=${frames}:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s=1920x1080:fps=${fps},setsar=1,trim=duration=${d},format=yuv420p[v]`;
      args = ['-i', f(sc.n, '.jpg'), '-i', f(sc.n, '.wav'), '-filter_complex', `${v};${aFilt}`];
    }
    await L.ff(FF, [...args, '-map', '[v]', '-map', '[a]', ...venc, '-t', String(d), seg + '.tmp.mp4'], `scene ${sc.n} video`);
    fs.renameSync(seg + '.tmp.mp4', seg);
    L.log(`segment ${sc.n} rendered (${d}s)`);
  });

  // ---------- 6. intro / outro (optional) ----------
  async function normalizeBumper(src, out) {
    if (!exists(src)) return null;
    if (!exists(out)) {
      const dur = await L.duration(FF, src);
      const aud = await L.hasAudio(FF, src);
      const args = ['-i', src, ...(aud ? [] : ['-f', 'lavfi', '-t', String(dur), '-i', 'anullsrc=r=48000:cl=stereo']),
        '-filter_complex', `[0:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=${fps},format=yuv420p[v];[${aud ? 0 : 1}:a]aresample=48000,aformat=channel_layouts=stereo[a]`,
        '-map', '[v]', '-map', '[a]', ...venc, '-t', String(dur), out];
      await L.ff(FF, args, 'bumper');
    }
    return out;
  }
  const intro = await normalizeBumper(cfg.paths.intro, path.join(dir, 'bumper_intro.mp4'));
  const outro = await normalizeBumper(cfg.paths.outro, path.join(dir, 'bumper_outro.mp4'));
  const introDur = intro ? await L.duration(FF, intro) : 0;

  // ---------- 7. concat + music + loudness ----------
  const list = [intro, ...S.scenes.map(sc => f(sc.n, '_seg.mp4')), outro].filter(Boolean);
  fs.writeFileSync(path.join(dir, 'concat.txt'), list.map(x => `file '${x}'`).join('\n'));
  const body = path.join(dir, 'body.mp4');
  await L.ff(FF, ['-f', 'concat', '-safe', '0', '-i', path.join(dir, 'concat.txt'), '-c', 'copy', body], 'concat');
  const total = await L.duration(FF, body);

  let music = null;
  try {
    const all = fs.readdirSync(cfg.paths.music_dir).filter(x => /\.(mp3|m4a|wav)$/i.test(x)).sort();
    const rhymeish = all.filter(x => /rhyme|song/i.test(x));
    const poolM = brief.format === 'rhyme' && rhymeish.length ? rhymeish : (all.filter(x => !/rhyme|song/i.test(x)).length ? all.filter(x => !/rhyme|song/i.test(x)) : all);
    if (poolM.length) music = path.join(cfg.paths.music_dir, poolM[parseInt(crypto.createHash('md5').update(jobId).digest('hex').slice(0, 6), 16) % poolM.length]);
  } catch { /* no music folder */ }
  if (!music) warnings.push(`No music found in ${cfg.paths.music_dir}: the video has voice only. Add a few cheerful royalty-free tracks.`);

  const final = path.join(dir, 'final.mp4');
  const mv = brief.format === 'rhyme' ? R.music_volume_rhyme : R.music_volume;
  const fadeSt = Math.max(0, total - 2.5).toFixed(2);
  const fc = music
    ? `[0:a]asplit=2[v1][v2];[1:a]volume=${mv},afade=t=in:d=1.5[m];[m][v2]sidechaincompress=threshold=0.04:ratio=5:attack=20:release=500[md];[v1][md]amix=inputs=2:duration=first:normalize=0,afade=t=out:st=${fadeSt}:d=2.5,loudnorm=I=-14:TP=-1.5:LRA=11[a]`
    : `[0:a]loudnorm=I=-14:TP=-1.5:LRA=11[a]`;
  await L.ff(FF, ['-i', body, ...(music ? ['-stream_loop', '-1', '-i', music] : []), '-filter_complex', fc,
    '-map', '0:v', '-map', '[a]', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-t', String(total), '-movflags', '+faststart', final], 'final mix');

  // ---------- 8. Shorts (9:16, cut from the final mix so they keep the music) ----------
  const start = {}; let t = introDur;
  for (const sc of S.scenes) { start[sc.n] = t; t += D[sc.n]; }
  const shortFiles = [];
  const fgW = Math.round(1080 * R.shorts_fg_zoom / 2) * 2;
  const font = exists(cfg.paths.font) ? cfg.paths.font : null;
  for (const [i, sh] of S.shorts.entries()) {
    const out = path.join(dir, `short_${i + 1}.mp4`);
    if (!exists(out)) {
      const ss = start[sh.from];
      let len = 0; for (let n = sh.from; n <= sh.to; n++) len += D[n] || 0;
      len = r3(Math.min(len, R.shorts_max_s));
      let title = '';
      if (font && sh.title) {
        const words = sh.title.split(/\s+/), lines = [''];
        for (const w of words) { if ((lines[lines.length - 1] + ' ' + w).trim().length > 16) lines.push(w); else lines[lines.length - 1] = (lines[lines.length - 1] + ' ' + w).trim(); }
        const tf = path.join(dir, `short_${i + 1}_title.txt`);
        fs.writeFileSync(tf, lines.join('\n'));
        title = `,drawtext=fontfile=${font}:textfile=${tf}:fontsize=84:fontcolor=white:borderw=7:bordercolor=black@0.85:line_spacing=12:x=(w-text_w)/2:y=h*0.1`;
      }
      const v = `[0:v]split[a][b];[a]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=24:3,eq=brightness=-0.06[bg];[b]scale=${fgW}:-2,crop=1080:ih[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2${title},setsar=1,format=yuv420p[v]`;
      const a = `[0:a]afade=t=in:d=0.3,afade=t=out:st=${Math.max(0, len - 0.8).toFixed(2)}:d=0.8[a]`;
      const cut = vf => L.ff(FF, ['-ss', String(r3(ss)), '-i', final, '-t', String(len), '-filter_complex', `${vf};${a}`, '-map', '[v]', '-map', '[a]',
        '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p', '-r', String(fps), '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', out], `short ${i + 1}`);
      try { await cut(v); }
      catch (e) {
        if (!title || !/drawtext/.test(e.message)) throw e;
        // This ffmpeg build has no text support: make the Short without the title overlay.
        await cut(v.replace(title, ''));
        if (!warnings.some(w => w.startsWith('Shorts have no title'))) warnings.push('Shorts have no title text on top (your ffmpeg has no text support). Add the title in YouTube instead.');
      }
    }
    shortFiles.push(out);
  }

  // ---------- 9. thumbnail ----------
  const thumb = path.join(dir, 'thumbnail.jpg');
  if (!exists(thumb)) {
    try {
      const raw = path.join(dir, 'thumbnail_raw.jpg');
      if (!exists(raw)) {
        const tp = S.thumbnail_prompt || S.scenes[0].image_prompt;
        const ids = cast.characters.filter(c => new RegExp(`\\b${c.name}\\b`, 'i').test(tp)).map(c => c.id).slice(0, 3);
        const use = ids.length ? ids : S.scenes[0].characters;
        const r = await L.retry(() => L.genImage(cfg, sec, {
          prompt: `${cfg.style}. YouTube thumbnail, bold simple composition, close-up, big expressive faces. ${tp}. ${charText(use)}.`,
          refs: use.map(id => refs[id]).filter(Boolean), file: raw }), 2, 'thumbnail');
        cost += r.cost;
      }
      await L.ff(FF, ['-i', raw, '-vf', 'scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720', '-q:v', '3', thumb], 'thumbnail');
    } catch (e) { warnings.push(`Thumbnail failed (${e.message.slice(0, 120)}); pick a frame from the video instead.`); }
  }

  // ---------- 10. metadata ----------
  const mins = `${Math.floor(total / 60)}:${String(Math.round(total % 60)).padStart(2, '0')}`;
  const part = brief.series && brief.series.total > 1 ? brief.series : null;
  const ytTitle = part ? `${S.title} | ${part.title} Part ${part.part}`.slice(0, 100) : S.title;
  const meta = [
    `TITLE: ${ytTitle}`, '', 'DESCRIPTION:', S.description, '', `Today's lesson: ${S.lesson}`, '',
    `TAGS: ${S.tags.join(', ')}`, '',
    ...S.shorts.map((sh, i) => `SHORT ${i + 1} TITLE: ${sh.title} #shorts`), '',
    `Length: ${mins} · Scenes: ${S.scenes.length} · Script v${S.version} · Job ${jobId}`,
  ].join('\n');
  const metaFile = path.join(dir, 'metadata.txt');
  fs.writeFileSync(metaFile, meta);

  const slug = S.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
  const files = [{ path: final, name: `1_${slug}_LONG.mp4` },
    ...shortFiles.map((p, i) => ({ path: p, name: `2_${slug}_SHORT_${i + 1}.mp4` })),
    ...(exists(thumb) ? [{ path: thumb, name: `3_${slug}_thumbnail.jpg` }] : []),
    { path: metaFile, name: `4_${slug}_metadata.txt` }];

  const costTotal = r3((L.readJSON(path.join(dir, 'status.json'), {}).cost_total || 0) + cost);
  L.setStatus(dir, { stage: 'ready', length_s: Math.round(total), cost: r3(cost), cost_total: costTotal });
  // Series bookkeeping: tell the workflow which episode to write next (only if not written yet).
  let next_job = '';
  if (series) {
    L.setStatus(series.dir, { [`part_${series.ep}`]: 'ready' });
    const nextId = `${series.id}_e${series.ep + 1}`;
    if (series.ep < series.bible.episodes.length && !exists(path.join(L.ROOT, 'jobs', nextId, 'script.json'))) next_job = nextId;
  }
  const clipsUsed = S.scenes.filter(sc => exists(f(sc.n, '.mp4'))).length;
  return {
    ok: true, jobId, title: ytTitle, next_job, part: part ? `${part.title} · Part ${part.part} of ${part.total}` : '', notify_email: cfg.notify_email, drive_parent: cfg.drive_parent_folder_id || 'root',
    folder_name: `DD TV English – ${part ? `${part.title} P${part.part} – ` : ''}${S.title} (${jobId})`, files, length: mins, clips: clipsUsed, scenes: S.scenes.length,
    cost: costTotal, warnings,
    description: S.description, lesson: S.lesson, tags: S.tags.join(', '), shorts: S.shorts.map(s => `${s.title} #shorts`),
  };
});
