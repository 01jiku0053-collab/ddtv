'use strict';
// usage: node series.js <seriesId> <briefB64|-> [feedbackB64]
//   First call: brief from the New Story form. "-" + feedback = revision round.
//   Feedback may contain "redraw: name, name" to force new pictures for those characters.
// Writes series/<id>/brief.json, bible.json, bible_vN.json, characters/<id>.jpg, _latest/ previews.
const fs = require('fs');
const path = require('path');
const L = require('./lib');

const VOICE_TYPES = ['girl', 'boy', 'woman', 'man', 'grandma', 'grandpa', 'creature'];

function bibleSystem(cfg, family, brief) {
  const fam = family.characters.map(c => `- "${c.id}": ${c.name}, ${c.role}. Looks: ${c.look}.`).join('\n');
  const narr = family.characters.find(c => c.id === family.narrator);
  const castRule = {
    new: `Invent 2 to 4 NEW original main characters for this story. ${narr.name} ("${narr.id}") is only the storyteller who narrates; she may appear at the start and end.`,
    family: `Use the DD family below as the main characters. You may add at most 2 new guest characters the story needs.`,
    mix: `Use some of the DD family below AND invent 1 to 3 NEW original characters who meet them.`,
  }[brief.cast] || '';
  return `You are the head writer of "DD TV English", a YouTube channel of original animated stories in English for ${cfg.script.audience}.
You are planning a SERIES BIBLE for a story told in ${brief.episodes} episode(s) of about 3-5 minutes each.

THE DD FAMILY (existing characters):
${fam}

CAST RULE: ${castRule}

NEW CHARACTERS must be completely original (never resemble existing cartoon, film, game or book characters). For each:
- "id": lowercase single word, unique, not one of: ${family.characters.map(c => c.id).join(', ')}
- "look": ONE concrete visual description that an illustrator can draw the same way every time: species/age, body shape, skin/fur colours, hair, eyes, clothing with colours, one distinctive accessory. No vague words.
- "voice_type": one of ${VOICE_TYPES.join(', ')}.
- "pronoun": "she" or "he" (every character is a she or a he, including animals and clouds).
Animals and magical creatures are welcome. Keep everything warm, safe and gentle.

EPISODES: exactly ${brief.episodes}. Each has its own small lesson and a complete mini-story a toddler can follow alone,
while the bigger story moves forward across episodes.${brief.episodes > 1 ? ' Each episode except the last ends with a gentle, happy "what happens next?" teaser (never scary or sad). The last episode brings everything together warmly.' : ''}

Reply with ONLY this JSON:
{
  "series_title": "short, warm, max 40 characters",
  "logline": "one sentence for parents",
  "characters": [ { "id": "...", "name": "...", "role": "...", "personality": "...", "look": "...", "catchphrase": "...", "voice_type": "...", "pronoun": "she" } ],
  "episodes": [ { "n": 1, "title": "...", "lesson": "...", "summary": "3-5 sentences: what happens, who is in it, how it ends", "teaser": "one line setting up the next part, or empty for the last episode" } ]
}`;
}

function normalizeBible(raw, family, brief) {
  const famIds = new Set(family.characters.map(c => c.id));
  const seen = new Set();
  const characters = (Array.isArray(raw.characters) ? raw.characters : []).map(c => {
    let id = String(c.id || c.name || '').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 16);
    if (!id || famIds.has(id)) return null;
    while (seen.has(id)) id += 'x';
    seen.add(id);
    return { id, name: String(c.name || id).trim(), role: String(c.role || ''), personality: String(c.personality || 'kind'),
      look: String(c.look || '').trim(), catchphrase: String(c.catchphrase || ''),
      voice_type: VOICE_TYPES.includes(c.voice_type) ? c.voice_type : 'creature',
      pronoun: /^he/i.test(String(c.pronoun || '')) ? 'he/him' : /^she/i.test(String(c.pronoun || '')) ? 'she/her' : '' };
  }).filter(c => c && c.look).slice(0, 5);
  if (brief.cast !== 'family' && !characters.length) throw new Error('the writer created no new characters');
  const eps = (Array.isArray(raw.episodes) ? raw.episodes : []).slice(0, brief.episodes).map((e, i) => ({
    n: i + 1, title: String(e.title || `Part ${i + 1}`), lesson: String(e.lesson || brief.lesson || ''),
    summary: String(e.summary || '').trim(), teaser: i + 1 < brief.episodes ? String(e.teaser || '') : '' }));
  if (eps.length !== brief.episodes || eps.some(e => !e.summary)) throw new Error(`the writer planned ${eps.length} usable episodes, expected ${brief.episodes}`);
  return { series_title: String(raw.series_title || 'Untitled story').slice(0, 60), logline: String(raw.logline || ''), characters, episodes: eps };
}

L.main(async () => {
  const [seriesId, briefB64, feedbackB64] = process.argv.slice(2);
  if (!/^[a-z0-9_-]+$/i.test(seriesId || '')) throw new Error(`bad series id "${seriesId}"`);
  const dir = path.join(L.ROOT, 'series', seriesId);
  const { cfg, cast: family, sec } = L.loadAll();
  const FF = L.ffmpegBin(cfg);
  fs.mkdirSync(path.join(dir, 'characters'), { recursive: true });

  let brief;
  if (briefB64 && briefB64 !== '-') {
    const b = JSON.parse(L.b64d(briefB64));
    brief = { idea: String(b.idea || '').trim(), lesson: String(b.lesson || '').trim(),
      format: ['story', 'rhyme', 'learn'].includes(b.format) ? b.format : 'story',
      episodes: Math.min(5, Math.max(1, parseInt(b.episodes, 10) || 1)),
      cast: ['new', 'family', 'mix'].includes(b.cast) ? b.cast : 'new',
      notes: String(b.notes || '').trim(), source: String(b.source || ''), auto: !!b.auto, created: new Date().toISOString() };
    if (brief.idea.length < 10) throw new Error('story idea is too short');
    L.writeJSON(path.join(dir, 'brief.json'), brief);
  } else brief = L.readJSON(path.join(dir, 'brief.json'));

  const feedback = L.b64d(feedbackB64 || '');
  const prev = feedback ? L.readJSON(path.join(dir, 'bible.json'), null) : null;
  const st = L.readJSON(path.join(dir, 'status.json'), {});
  const version = (st.version || 0) + 1;
  L.setStatus(dir, { stage: 'planning', version });

  // ---- 1. bible ----
  let user = `STORY BRIEF FROM THE SHOWRUNNER (this is the creative direction; follow it closely):
Idea: ${brief.idea}
Main lesson: ${brief.lesson}
Format of the episodes: ${brief.format}
Showrunner notes: ${brief.notes || '(none)'}${brief.source && brief.source !== 'original' ? `\nBased on the public-domain tale: ${brief.source}. Retell it freshly with the new characters; do not keep the original's names.` : ''}`;
  if (prev) user += `\n\nThis is a REVISION. Previous bible:\n${JSON.stringify(prev)}\n\nShowrunner feedback (priority):\n${feedback}\nKeep character ids unchanged unless a character is removed or replaced. Keep what was not criticised.`;
  let bible, lastErr;
  for (let a = 1; a <= 2 && !bible; a++) {
    try {
      const txt = await L.llm(cfg, sec, bibleSystem(cfg, family, brief), user + (a > 1 ? `\n\nYour previous reply was invalid (${lastErr}). Reply with the complete JSON only.` : ''));
      bible = normalizeBible(L.parseJSONLoose(txt), family, brief);
    } catch (e) { lastErr = e.message; L.log(`bible attempt ${a} failed: ${e.message}`); }
  }
  if (!bible) throw new Error(`could not plan the series: ${lastErr}`);
  bible.version = version;

  // ---- 2. character pictures (only new characters, changed looks, or "redraw: ...") ----
  const redraw = new Set(((feedback.match(/redraw\s*:?\s*([^\n.]+)/i) || [])[1] || '')
    .toLowerCase().split(/[\s,]+/).filter(Boolean));
  const famRefs = family.characters.filter(c => brief.cast !== 'new' || c.id === family.narrator)
    .map(c => path.join(L.ROOT, 'assets', 'characters', `${c.id}.jpg`)).filter(p => fs.existsSync(p));
  const anchors = famRefs.slice(0, 2).map(L.fileToDataURI);
  let cost = 0; const drawn = [];
  for (const c of bible.characters) {
    const img = path.join(dir, 'characters', `${c.id}.jpg`);
    const lookFile = path.join(dir, 'characters', `${c.id}.look.txt`);
    const same = fs.existsSync(img) && fs.existsSync(lookFile) && fs.readFileSync(lookFile, 'utf8') === c.look;
    if (same && !redraw.has(c.id) && !redraw.has(c.name.toLowerCase())) { if (anchors.length < 3) anchors.push(L.fileToDataURI(img)); continue; }
    const prompt = `${cfg.style}. Character reference sheet of ONE character: ${c.name}, ${c.look}. Full body, standing, facing the camera, friendly ${c.personality.split(',')[0]} expression, plain soft pastel background, whole character visible, centred.` +
      (anchors.length ? ' Same art style, rendering and proportions as the reference images, but draw ONLY this new character.' : '');
    const r = await L.retry(() => L.genImage(cfg, sec, { prompt, refs: anchors.slice(0, 3), width: 2048, height: 2048, file: img }), 2, `draw ${c.id}`);
    cost += r.cost; fs.writeFileSync(lookFile, c.look); drawn.push(c.name);
    if (anchors.length < 3) anchors.push(L.fileToDataURI(img));   // later characters copy the first one's style
  }

  // ---- 3. previews for the approval email ----
  const latest = path.join(dir, '_latest');
  fs.rmSync(latest, { recursive: true, force: true }); fs.mkdirSync(latest, { recursive: true });
  for (const c of bible.characters) await L.ff(FF, ['-i', path.join(dir, 'characters', `${c.id}.jpg`), '-vf', 'scale=640:-2', '-q:v', '4', path.join(latest, `${c.id}.jpg`)], 'preview');

  L.writeJSON(path.join(dir, `bible_v${version}.json`), bible);
  L.writeJSON(path.join(dir, 'bible.json'), bible);
  L.setStatus(dir, { stage: 'awaiting_approval', version, title: bible.series_title, episodes_total: brief.episodes });

  const voiced = L.assignVoices(cfg, bible.characters);
  const chars = voiced.map(c => `<tr><td style="padding:6px;vertical-align:top"><b>${L.esc(c.name)}</b><br><span style="color:#888">${c.id}.jpg attached</span></td>
    <td style="padding:6px">${L.esc(c.role)}. ${L.esc(c.personality)}.<br><i>"${L.esc(c.catchphrase)}"</i><br><span style="color:#888;font-size:12px">Look: ${L.esc(c.look)}<br>Voice: ${c.voice_type}${c.voice_id ? '' : ' (no voice in pool yet: narrator voice will be used)'}</span></td></tr>`).join('');
  const eps = bible.episodes.map(e => `<li><b>Part ${e.n}: ${L.esc(e.title)}</b> (lesson: ${L.esc(e.lesson)})<br>${L.esc(e.summary)}${e.teaser ? `<br><i>Teaser: ${L.esc(e.teaser)}</i>` : ''}</li>`).join('');
  const html = `<div style="font-family:Arial,sans-serif;max-width:760px">
<h2 style="margin:0">📖 ${L.esc(bible.series_title)}</h2><p>${L.esc(bible.logline)}</p>
${brief.auto ? `<p style="background:#f5f3ff;padding:8px;border-radius:6px">🤖 Invented automatically · ${brief.source && brief.source !== 'original' ? `retold from the public-domain tale <b>${L.esc(brief.source)}</b>` : '<b>original story</b>'}<br>Lesson: ${L.esc(brief.lesson)}</p>` : ''}
<p><b>${brief.episodes} episode(s)</b> · format: ${brief.format} · cast: ${brief.cast} · plan v${version}${drawn.length ? ` · newly drawn: ${L.esc(drawn.join(', '))}` : ''}</p>
${bible.characters.length ? `<h3>New characters (pictures attached)</h3><table style="border-collapse:collapse">${chars}</table>` : ''}
<h3>Episodes</h3><ol style="padding-left:18px">${eps}</ol>
<p style="color:#666;font-size:13px">${cfg.auto && cfg.auto.approve_scripts === false ? '<b>Approve = everything else runs automatically:</b> all episodes are written, produced and sent to Drive. ' : ''}Approving locks these characters for every episode of this story. To change a picture, choose Revise and write e.g.
<b>redraw: ${L.esc((bible.characters[0] || { name: 'Name' }).name)}</b> plus what to change ("rounder, more orange").</p>
<p style="color:#888;font-size:12px">Series ${seriesId}</p></div>`;

  return { ok: true, seriesId, version, title: bible.series_title, episodes: brief.episodes, notify_email: cfg.notify_email, cost,
    subject: `DD TV English story plan v${version}: ${bible.series_title} (${brief.episodes} part${brief.episodes > 1 ? 's' : ''})`, email_html: html };
});
