'use strict';
// SYNC LAB: renders the same scenes several ways so you can compare with your own eyes.
//   Talking scenes:  A = current clip + voice   B = + KlingAI Lip-Sync   C = OmniHuman-1.5 (picture + voice)
//   Action scene:    A = current clip           D = Kling VIDEO 3.0 Turbo
// Uses the pictures, clips and voices already made by the preview. Called by produce.js <jobId> lab
const fs = require('fs');
const path = require('path');
const L = require('./lib');

const MODELS = {
  lipsync: 'klingai:7@1',
  omnihuman: 'bytedance:5@2',
  kling3: 'klingai:kling-video@3.0-turbo',
};

async function upload(sec, file, mime) {
  const r = await L.runware(sec, [{ taskType: 'mediaStorage', taskUUID: L.uuid(), operation: 'upload',
    media: `data:${mime};base64,${fs.readFileSync(file).toString('base64')}` }], 300000);
  const d = r.data.find(x => x.mediaURL || x.mediaUUID);
  if (!d) throw new Error(`upload failed: ${JSON.stringify(r.errors).slice(0, 200)}`);
  return d.mediaURL || d.mediaUUID;
}

// submit one videoInference task and wait for it
async function runVideo(sec, task, file, label, maxMin = 20) {
  const taskUUID = L.uuid();
  const r = await L.runware(sec, [{ taskType: 'videoInference', taskUUID, deliveryMethod: 'async', includeCost: true, outputType: 'URL', outputFormat: 'MP4', ...task }]);
  if (r.errors.length) throw new Error(`${label}: ${JSON.stringify(r.errors).slice(0, 300)}`);
  const end = Date.now() + maxMin * 60000;
  while (Date.now() < end) {
    await L.sleep(process.env.LAB_POLL_MS ? +process.env.LAB_POLL_MS : 8000);
    let p; try { p = await L.runware(sec, [{ taskType: 'getResponse', taskUUID }], 60000); } catch { continue; }
    const d = p.data.find(x => x.taskUUID === taskUUID && x.videoURL);
    const err = p.errors.find(x => x.taskUUID === taskUUID) || p.data.find(x => x.taskUUID === taskUUID && x.status === 'error');
    if (d) { await L.download(d.videoURL, file); return d.cost || 0; }
    if (err) throw new Error(`${label}: ${JSON.stringify(err).slice(0, 300)}`);
  }
  throw new Error(`${label}: timed out`);
}

async function run({ cfg, sec, cast, S, dir, jobId, DIR, FF, scenesArg }) {
  const lab = path.join(dir, 'lab');
  fs.mkdirSync(lab, { recursive: true });
  const pad = n => String(n).padStart(3, '0');
  const f = (n, ext) => path.join(dir, `scene_${pad(n)}${ext}`);
  const has = p => { try { return fs.statSync(p).size > 0; } catch { return false; } };
  const name = Object.fromEntries(cast.characters.map(c => [c.id, c.name]));
  const ready = S.scenes.filter(sc => has(f(sc.n, '.jpg')) && has(f(sc.n, '.mp4')));
  if (!ready.length) throw new Error('no scenes with pictures and clips yet: make the preview first');

  // choose: talking scenes = one visible character speaks (not the narrator); action = has a sound effect or the most movement
  const talkerOf = sc => { const sp = [...new Set(sc.lines.filter(l => l.speaker !== cast.narrator && !l.sing).map(l => l.speaker))]; return sp.length ? sp[0] : null; };
  let talk = scenesArg.length ? ready.filter(sc => scenesArg.includes(sc.n) && talkerOf(sc)) : ready.filter(sc => talkerOf(sc)).slice(0, 3);
  let action = ready.find(sc => !talk.includes(sc) && DIR && (DIR.shots.find(x => x.n === sc.n) || {}).sfx) || ready.find(sc => !talk.includes(sc)) || ready[0];
  if (!talk.length) throw new Error('no talking scenes in the preview to test');

  const results = []; let cost = 0; const notes = [];
  const mux = async (video, audio, out, dur) => L.ff(FF, ['-i', video, '-i', audio, '-filter_complex',
    `[0:v]scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720,setsar=1,fps=30,tpad=stop_mode=clone:stop_duration=${dur},trim=duration=${dur},format=yuv420p[v];[1:a]aresample=48000,apad=whole_dur=${dur},atrim=duration=${dur}[a]`,
    '-map', '[v]', '-map', '[a]', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-c:a', 'aac', '-b:a', '160k', '-t', String(dur), out], 'mux');

  for (const sc of talk) {
    const who = talkerOf(sc);
    // the audio is ONLY the talking character's lines (so mouths are driven by the right voice)
    const lineFiles = sc.lines.map((l, i) => ({ l, file: path.join(dir, `line_${pad(sc.n)}_${String(i + 1).padStart(2, '0')}.mp3`) }))
      .filter(x => x.l.speaker === who && has(x.file)).map(x => x.file);
    if (!lineFiles.length) { notes.push(`scene ${sc.n}: no voice files found, skipped`); continue; }
    const talkWav = path.join(lab, `s${sc.n}_voice.wav`);
    await L.ff(FF, [...lineFiles.flatMap(x => ['-i', x]), '-filter_complex', lineFiles.map((_, i) => `[${i}:a]aresample=48000,aformat=channel_layouts=mono[a${i}]`).join(';') + ';' + lineFiles.map((_, i) => `[a${i}]`).join('') + `concat=n=${lineFiles.length}:v=0:a=1[o]`, '-map', '[o]', talkWav], 'voice');
    const talkMp3 = path.join(lab, `s${sc.n}_voice.mp3`);
    await L.ff(FF, ['-i', talkWav, '-c:a', 'libmp3lame', '-q:a', '2', talkMp3], 'mp3');
    const dur = Math.round((await L.duration(FF, talkWav) + 0.4) * 100) / 100;
    const label = `scene ${sc.n} (${name[who] || who}: "${L.stripTags(sc.lines.find(l => l.speaker === who).text).slice(0, 60)}")`;

    // A: current
    const A = path.join(lab, `s${String(sc.n).padStart(2, '0')}_A_current.mp4`);
    await mux(f(sc.n, '.mp4'), talkWav, A, dur);
    results.push({ scene: sc.n, v: 'A', what: `${label}: current clip, voice laid on top`, file: A });

    let audioURL = null;
    try { audioURL = await upload(sec, talkMp3, 'audio/mpeg'); } catch (e) { notes.push(`scene ${sc.n}: audio upload failed (${e.message.slice(0, 100)})`); }

    // B: current clip (stretched to the voice length) + KlingAI Lip-Sync
    if (audioURL) {
      try {
        const base = path.join(lab, `s${sc.n}_base.mp4`);
        await L.ff(FF, ['-i', f(sc.n, '.mp4'), '-vf', `scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720,fps=30,tpad=stop_mode=clone:stop_duration=${dur},trim=duration=${dur}`, '-an', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', base], 'base');
        const videoURL = await upload(sec, base, 'video/mp4');
        const raw = path.join(lab, `s${sc.n}_lipsync_raw.mp4`);
        cost += await runVideo(sec, { model: MODELS.lipsync, providerSettings: { klingai: { originalAudioVolume: 0, soundVolume: 1 } }, inputs: { video: videoURL, audio: audioURL } }, raw, `lip-sync scene ${sc.n}`);
        const B = path.join(lab, `s${String(sc.n).padStart(2, '0')}_B_lipsync.mp4`);
        await mux(raw, talkWav, B, dur);
        results.push({ scene: sc.n, v: 'B', what: `${label}: + KlingAI Lip-Sync`, file: B });
      } catch (e) { notes.push(`scene ${sc.n} B (Lip-Sync) failed: ${e.message.slice(0, 180)}`); }

      // C: OmniHuman-1.5 animates the scene picture from the voice
      try {
        const raw = path.join(lab, `s${sc.n}_omni_raw.mp4`);
        cost += await runVideo(sec, { model: MODELS.omnihuman, inputs: { image: L.fileToDataURI(f(sc.n, '.jpg')), audio: audioURL } }, raw, `OmniHuman scene ${sc.n}`, 25);
        const C = path.join(lab, `s${String(sc.n).padStart(2, '0')}_C_omnihuman.mp4`);
        await mux(raw, talkWav, C, dur);
        results.push({ scene: sc.n, v: 'C', what: `${label}: OmniHuman-1.5 (animated from the voice)`, file: C });
      } catch (e) { notes.push(`scene ${sc.n} C (OmniHuman) failed: ${e.message.slice(0, 180)}`); }
    }
  }

  // action scene: current vs Kling VIDEO 3.0 Turbo
  if (action) {
    const wav = f(action.n, '.wav');
    const dur = has(wav) ? Math.min(12, Math.round((await L.duration(FF, wav) + 0.3) * 100) / 100) : 6;
    const A = path.join(lab, `s${String(action.n).padStart(2, '0')}_A_current_action.mp4`);
    if (has(wav)) { await mux(f(action.n, '.mp4'), wav, A, dur); results.push({ scene: action.n, v: 'A', what: `scene ${action.n} (action): current clip`, file: A }); }
    try {
      const shot = DIR && DIR.shots.find(x => x.n === action.n);
      const prompt = shot ? require('./director').motionPrompt(cfg, shot, action, cast) : (action.motion_prompt || 'lively cartoon movement');
      const raw = path.join(lab, `s${action.n}_kling3_raw.mp4`);
      cost += await runVideo(sec, { model: MODELS.kling3, positivePrompt: prompt.slice(0, 2400), resolution: '720p', duration: Math.max(3, Math.min(15, Math.ceil(dur))),
        inputs: { frameImages: [{ image: L.fileToDataURI(f(action.n, '.jpg')), frame: 'first' }] } }, raw, `Kling 3.0 Turbo scene ${action.n}`);
      const D2 = path.join(lab, `s${String(action.n).padStart(2, '0')}_D_kling3.mp4`);
      if (has(wav)) await mux(raw, wav, D2, dur); else fs.copyFileSync(raw, D2);
      results.push({ scene: action.n, v: 'D', what: `scene ${action.n} (action): Kling VIDEO 3.0 Turbo`, file: D2 });
    } catch (e) { notes.push(`scene ${action.n} D (Kling 3.0 Turbo) failed: ${e.message.slice(0, 180)}`); }
  }

  // one video with all versions in order (scene by scene), 1 s of black between them
  const all = path.join(lab, 'ALL_versions_in_order.mp4');
  const ordered = results.slice().sort((a, b) => a.scene - b.scene || a.v.localeCompare(b.v));
  if (ordered.length) {
    const inputs = ordered.flatMap(r => ['-i', r.file]);
    const fc = ordered.map((_, i) => `[${i}:v]scale=1280:720,setsar=1,fps=30,tpad=stop_mode=add:stop_duration=1:color=black[v${i}];[${i}:a]aresample=48000,apad=pad_dur=1[a${i}]`).join(';') + ';' +
      ordered.map((_, i) => `[v${i}][a${i}]`).join('') + `concat=n=${ordered.length}:v=1:a=1[v][a]`;
    await L.ff(FF, [...inputs, '-filter_complex', fc, '-map', '[v]', '-map', '[a]', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '21', '-c:a', 'aac', all], 'compare video');
  }
  const costTotal = Math.round(((L.readJSON(path.join(dir, 'status.json'), {}).cost_total || 0) + cost) * 1000) / 1000;
  L.setStatus(dir, { lab_done: new Date().toISOString(), lab_cost: Math.round(cost * 1000) / 1000, cost_total: costTotal });
  const order = ordered.map((r, i) => `${i + 1}. ${r.what}`);
  return { ok: true, lab: true, jobId, title: `SYNC LAB · ${S.title}`, next_job: '', part: 'Same scenes, different methods',
    notify_email: cfg.notify_email, drive_parent: cfg.drive_parent_folder_id || 'root',
    folder_name: `DD TV English – SYNC LAB – ${S.title} (${jobId})`,
    files: [...(ordered.length ? [{ path: all, name: '0_ALL_versions_in_order.mp4' }] : []), ...ordered.map(r => ({ path: r.file, name: path.basename(r.file) }))],
    length: '', clips: ordered.length, scenes: talk.length + (action ? 1 : 0), cost: Math.round(cost * 1000) / 1000,
    warnings: notes, description: order.join('\n'), lesson: '', tags: '', shorts: [] };
}

module.exports = { run };
