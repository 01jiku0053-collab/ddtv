#!/bin/sh
# OPTIONAL: runs Laya (the decision model) as its own container next to n8n.
# The DD TV pipeline works without it; with it, the Script Doctor and the song ideas get a second opinion.
set -e
N8N=n8n-wx3b-n8n-1
AVAIL=$(free -m | awk '/Mem:/ {print $7}')
echo "Free memory: ${AVAIL} MB"
if [ "$AVAIL" -lt 2500 ]; then
  echo "Not enough free memory for Laya (it needs about 2.5 GB). Skipping: the pipeline works fine without it."
  exit 0
fi
NET=$(docker inspect -f '{{range $k,$v := .NetworkSettings.Networks}}{{$k}} {{end}}' $N8N | awk '{print $1}')
echo "n8n network: $NET"
cd "$(dirname "$0")/laya"
docker build -q -t ddtv-laya . >/dev/null && echo "image built"
docker rm -f ddtv-laya >/dev/null 2>&1 || true
docker run -d --name ddtv-laya --restart unless-stopped --network "$NET" --memory 3g -v ddtv-laya-cache:/cache ddtv-laya >/dev/null
echo "Laya is starting. The first start downloads the model (about 1.7 GB), which takes a few minutes."
echo "Check it with:"
echo "  docker exec $N8N node -e \"fetch('http://ddtv-laya:8080/health').then(r=>r.text()).then(console.log)\""
