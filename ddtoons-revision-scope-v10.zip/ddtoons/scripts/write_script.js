'use strict';
// usage: node write_script.js <jobId> <briefB64|-> [feedbackB64]
//   briefB64 "-" = reuse the saved brief (revision round). feedbackB64 = your revision notes.
// Writes jobs/<jobId>/brief.json, script_vN.json and script.json (the current version).
const fs = require('fs');
const path = require('path');
const L = require('./lib');
const { writersRoom } = require('./writers_room');

const FORMAT_RULES = {
  story: 'A gentle story with a clear arc: Nani opens -> the kids want something -> a small problem -> a first try that fails in a funny or sweet way -> they try the kind/right way -> happy ending -> Nani closes by asking the viewer one simple question about the lesson.',
  rhyme: 'A rhyming sing-along. Short rhyming couplets with a strong bouncy rhythm. A 2-4 line chorus that repeats word-for-word at least 3 times (mark those lines with "chorus": true). Very simple words. Nani introduces it in one line and invites the viewer to sing along.',
  learn: 'A playful learning episode (counting, colours, shapes, animals, habits). The kids discover things one at a time, repeat each new word clearly, and pause to invite the viewer: "Can you say it with me?" Ends with a quick recap of everything learned.',
};

function pronoun(c) {
  if (c.pronoun) return c.pronoun;
  const t = `${c.voice_type || ''} ${c.role || ''} ${c.look || ''}`.toLowerCase();
  if (/\b(girl|woman|grandma|grandmother|mother|mom|sister|she|her|queen|princess|lady)\b/.test(t)) return 'she/her';
  if (/\b(boy|man|grandpa|grandfather|father|dad|brother|he|his|king|prince|puppy|pup)\b/.test(t)) return 'he/him';
  return 'he/him';
}
function castSheet(cast) {
  return cast.characters.map(c =>
    `- id "${c.id}": ${c.name} (${pronoun(c)}), ${c.role}. Personality: ${c.personality}. Catchphrase: "${c.catchphrase}". Looks: ${c.look}.`).join('\n');
}

function systemPrompt(cfg, cast, brief) {
  const f = cfg.script.formats[brief.format] || cfg.script.formats.story;
  const ids = cast.characters.map(c => c.id);
  return `You are the head writer of "DD TV English", a YouTube channel of original animated stories in English for ${cfg.script.audience}.

THE CAST (original characters, always the same):
${castSheet(cast)}
"${cast.narrator}" is the storyteller and narrates everything that is not dialogue.

FORMAT "${brief.format}": ${FORMAT_RULES[brief.format] || FORMAT_RULES.story}
Length: ${f.scenes} scenes, ${f.words} spoken words in total.

${L.houseStyle()}

SAFETY (never break these)
- Simple, concrete words a 3-year-old knows; short lines that are fun to say out loud.
- Warm and safe: no danger, no scary moments, no villains, no injuries, no prolonged crying, no animals in distress, no mocking, no brands, no real people, no existing cartoon characters or songs.
- Kids solve the problem themselves; adults are loving, never harsh. Each featured character uses their catchphrase at least once.

VOICE ACTING (the lines are performed by an expressive voice model)
- You may start a line with ONE voice tag from this list only: [giggles], [laughs], [gasps], [whispers], [excited], [sighs], [shouts], [sleepy], [gulps], [cheerfully], [sadly], [curious], [surprised], [warmly], [softly]. No other tags: never stage directions like [to camera], [freezes], [tiptoeing] (those belong in the picture, not the voice).
- Every line is a complete sentence. Never end or start a line with a dash; no cut-off words.
- Characters react to each other: they interrupt, tease, cheer, and laugh together, like real children and friends do. Each character has their own way of talking.
- The storyteller's lines are warm and playful, with [warmly], [whispers] or [excited] where it helps.

SONG
- For a rhyme episode, sung lines use "sing": true and exact lyrics. For musical story episodes use one short, original chorus sentence marked "chorus": true each time it appears, with identical wording at least three times. Do not generate vague filler lyrics. A plain story may have no chorus.

SCENES
- Each scene is one readable visual beat with 1-2 spoken lines and at most 22 words. Keep a coherent location and screen direction. Something visually changes because of a character choice; avoid filler shots.
- "speaker" is one of: ${ids.map(i => `"${i}"`).join(', ')}. Narration lines use "${cast.narrator}".
- "visual_anchor": for every scene record each visible character’s exact approved outfit and left/centre/right position, the one tracked prop and its colour/owner, and a stable location cue. Carry details forward; change them only when shown on screen.
- "image_prompt": describe ONLY what is visible, in one or two sentences: the setting, which characters (by name) are there, what each is doing, their expressions, the camera framing (wide / medium / close-up). Keep the main action in the centre. Never ask for text or letters in the picture.
- "characters": list of character ids visible in the picture (max 3).
- "animate": true for at most 10 important action or reaction scenes in a story; false for calm narration, establishing images and repeated dialogue. Reserve motion for the hook, visual gags, turning point and payoff.
- "motion_prompt": one physically simple, visible movement with a start and end pose. One character acts at a time. Avoid simultaneous speaking mouths, running, camera moves and object transformations.

SHORTS
- Pick exactly 2 moments for YouTube Shorts: each a run of consecutive scenes (by scene number) that is funny or sweet on its own and lasts about 25-50 seconds (roughly 3-6 scenes). Give each a short catchy title (max 40 characters).

Reply with ONLY this JSON object:
{
  "title": "YouTube title, max 60 characters, warm and specific, no ALL CAPS, no clickbait",
  "lesson": "the lesson in one short sentence",
  "description": "YouTube description, 2-3 short sentences for parents, mentions the lesson",
  "tags": ["8 to 12 tags"],
  "thumbnail_prompt": "a bright close-up picture idea for the thumbnail: which characters, big happy or surprised expressions, simple colourful background, no text",
  "scenes": [
    { "n": 1, "characters": ["nani"], "visual_anchor": "approved outfit, screen position, tracked prop and location", "image_prompt": "...", "animate": true, "motion_prompt": "...",
      "lines": [ { "speaker": "nani", "text": "[warmly] ..." }, { "speaker": "...", "text": "zoom zoom song lyric", "sing": true } ] }
  ],
  "shorts": [ { "title": "...", "from": 3, "to": 7 } ]
}`;
}

function userPrompt(brief, prev, feedback) {
  let u = `EPISODE BRIEF FROM THE SHOWRUNNER (follow it closely; it is the creative direction):
Story idea: ${brief.idea}
Lesson: ${brief.lesson}
Format: ${brief.format}
Featured characters: ${brief.characters.length ? brief.characters.join(', ') : 'writer\'s choice from the cast'}
Showrunner notes: ${brief.notes || '(none)'}`;
  if (brief.series_context) u += `\n\nSERIES CONTEXT:\n${brief.series_context}`;
  if (prev && feedback) {
    u += `\n\nThis is a REVISION. Here is the previous draft:\n${JSON.stringify(prev)}\n\nShowrunner feedback to apply (this has priority):\n${feedback}\n\nRewrite the full script applying the feedback. Keep what was not criticised.`;
  }
  return u;
}

const EDITOR_PROMPT = `You are the story editor of a preschool animation channel. You receive a script as JSON.
Improve it WITHOUT changing the JSON structure or the story's premise:
- cut any sentence longer than 12 words into two; replace hard words with easy ones
- make sure the arc is clear and the ending feels earned; tighten any flat or repetitive scene
- make sure every rule is respected: kind, safe, no scary or distressing moments, no brands, no existing characters
- make sure every image_prompt is concrete and visual and mentions which characters are present by name
- keep the same scene count (+/-2) and valid shorts ranges
Reply with ONLY the full corrected JSON object.`;

const VOICE_TAGS = new Set(['giggles', 'laughs', 'gasps', 'whispers', 'excited', 'sighs', 'shouts', 'sleepy', 'gulps', 'cheerfully', 'sadly', 'curious', 'surprised', 'warmly', 'softly', 'playfully', 'happily', 'nervously', 'proudly', 'gently']);
// keep at most one real voice tag (at the start), drop stage directions, turn cut-off dashes into pauses
function cleanLine(t, sung) {
  let text = String(t || '').trim();
  const tags = [...text.matchAll(/\[([^\]]{1,30})\]/g)].map(m => m[1].toLowerCase().trim());
  text = text.replace(/\[[^\]]{1,30}\]/g, ' ');
  text = text.replace(/^\s*[-–—]+\s*/, '').replace(/\s*[-–—]+\s*$/, '...').replace(/\s+[-–—]\s+/g, ', ').replace(/(\w)[-–—]+\s+/g, '$1, ').replace(/\s+/g, ' ').trim();
  const keep = sung ? null : tags.find(x => VOICE_TAGS.has(x));
  return keep ? `[${keep}] ${text}` : text;
}
function normalize(raw, cast, cfg) {
  const ids = new Set(cast.characters.map(c => c.id));
  const byName = Object.fromEntries(cast.characters.map(c => [c.name.toLowerCase(), c.id]));
  const toId = s => { const k = String(s || '').toLowerCase().trim(); return ids.has(k) ? k : (byName[k] || null); };
  const scenesIn = Array.isArray(raw.scenes) ? raw.scenes : [];
  const scenes = scenesIn.slice(0, cfg.script.max_scenes).map((s, i) => {
    const lines = (Array.isArray(s.lines) ? s.lines : [])
      .map(l => ({ speaker: toId(l.speaker) || cast.narrator, text: cleanLine(l.text, !!l.sing), ...(l.chorus ? { chorus: true } : {}), ...(l.sing ? { sing: true } : {}) }))
      .filter(l => l.text);
    const chars = [...new Set((s.characters || []).map(toId).filter(Boolean))].slice(0, 3);
    return { n: i + 1, characters: chars, visual_anchor: String(s.visual_anchor || '').trim(), image_prompt: String(s.image_prompt || '').trim(),
      animate: !!s.animate, motion_prompt: String(s.motion_prompt || '').trim(), lines };
  }).filter(s => s.lines.length && s.image_prompt);
  scenes.forEach((s, i) => { s.n = i + 1; });
  if (scenes.length < 6) throw new Error(`script has only ${scenes.length} usable scenes`);
  const N = scenes.length;
  const shorts = (Array.isArray(raw.shorts) ? raw.shorts : []).slice(0, 3).map(sh => {
    let a = Math.max(1, Math.min(N, parseInt(sh.from, 10) || 1));
    let b = Math.max(a, Math.min(N, parseInt(sh.to, 10) || a + 4));
    return { title: String(sh.title || raw.title || '').slice(0, 60), from: a, to: b };
  });
  const words = scenes.reduce((t, s) => t + s.lines.reduce((u, l) => u + L.stripTags(l.text).split(/\s+/).filter(Boolean).length, 0), 0);
  return {
    title: String(raw.title || 'Untitled').slice(0, 90), lesson: String(raw.lesson || ''),
    description: String(raw.description || ''), tags: (raw.tags || []).map(String).slice(0, 15),
    thumbnail_prompt: String(raw.thumbnail_prompt || ''), scenes, shorts, words,
  };
}

async function draft(cfg, cast, sec, brief, prev, feedback) {
  if (cfg.llm.writers_room !== false) {
    try {
      return await writersRoom({ cfg, cast, sec, brief, prev, feedback, sheet: castSheet(cast),
        scriptSystem: systemPrompt(cfg, cast, brief), userPrompt, normalize });
    } catch (e) { L.log('writers room failed, falling back to the single writer:', e.message); }
  }
  let lastErr;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const extra = attempt > 1 ? `\n\nIMPORTANT: your previous reply was invalid (${lastErr}). Reply with the complete JSON object only.` : '';
      const txt = await L.llm(cfg, sec, systemPrompt(cfg, cast, brief), userPrompt(brief, prev, feedback) + extra);
      let script = normalize(L.parseJSONLoose(txt), cast, cfg);
      if (cfg.llm.editor_pass) {
        try {
          const ed = await L.llm(cfg, sec, EDITOR_PROMPT + '\n\nThe cast and rules:\n' + systemPrompt(cfg, cast, brief),
            JSON.stringify(script), { temperature: 0.4 });
          script = normalize(L.parseJSONLoose(ed), cast, cfg);
        } catch (e) { L.log('editor pass skipped:', e.message); }
      }
      return script;
    } catch (e) { lastErr = e.message; L.log(`draft attempt ${attempt} failed: ${e.message}`); }
  }
  throw new Error(`could not get a valid script: ${lastErr}`);
}

function emailHtml(jobId, version, s, cast, brief, cfg) {
  const name = Object.fromEntries(cast.characters.map(c => [c.id, c.name]));
  const secs = Math.round(s.words / 2.1 + s.scenes.length * 1.2);
  const rows = s.scenes.map(sc => `
    <tr><td style="vertical-align:top;padding:6px;color:#888">${sc.n}${sc.animate ? ' 🎬' : ''}</td>
    <td style="padding:6px">${sc.lines.map(l => `<b>${L.esc(name[l.speaker] || l.speaker)}:</b> ${L.esc(l.text)}${l.chorus ? ' <i>(chorus)</i>' : ''}${l.sing ? ' 🎵 <i>(sung)</i>' : ''}`).join('<br>')}
    <div style="color:#999;font-size:12px;margin-top:3px">🖼 ${L.esc(sc.image_prompt)}</div></td></tr>`).join('');
  const shorts = s.shorts.map((x, i) => `<li>Short ${i + 1}: "${L.esc(x.title)}" = scenes ${x.from}-${x.to}</li>`).join('');
  return `<div style="font-family:Arial,sans-serif;max-width:760px">
${brief.series ? `<p style="margin:0;color:#7c3aed"><b>${L.esc(brief.series.title)} · Part ${brief.series.part} of ${brief.series.total}</b></p>` : ''}
<h2 style="margin:0">${L.esc(s.title)}</h2>
<p><b>Lesson:</b> ${L.esc(s.lesson)}<br><b>Format:</b> ${L.esc(brief.format)} · <b>Scenes:</b> ${s.scenes.length} · <b>Words:</b> ${s.words} · <b>≈ ${Math.floor(secs / 60)}m ${secs % 60}s</b> · <b>Draft v${version}</b></p>
<p style="color:#666">Your brief: ${L.esc(brief.idea)}</p>
${s.doctor ? require('./doctor').cardHtml(s.doctor) : ''}
${s.fun ? `<div style="background:#f5f3ff;padding:10px;border-radius:6px;font-size:14px">✍️ Writer: <b>${L.esc(s.fun.model)}</b> · Fun score: <b>${s.fun.final_score ?? '–'}/10</b>${s.fun.improved_after ? ' (then rewritten to fix the notes)' : ''} · Narration: ${s.fun.narration_pct}% of lines
<br>🎣 Hook: ${L.esc(s.fun.beats.hook)}<br>🎵 Runner: <i>${L.esc(s.fun.beats.runner)}</i><br>🔄 Twist: ${L.esc(s.fun.beats.twist)}
${s.fun.rounds.map(r => `<br><span style="color:#888">Editor round ${r.round}: ${r.score}/10 · ${L.esc(r.notes)}</span>`).join('')}</div>` : ''}
<table style="border-collapse:collapse;font-size:15px">${rows}</table>
<p><b>Shorts plan</b></p><ul>${shorts}</ul>
<p style="color:#666;font-size:13px">🎬 = animated clip (max ${cfg.video.max_clips}). Read it aloud once: if a line sounds wrong spoken, choose <b>Revise</b> and say which. For small word changes you can also edit
<code>/opt/storyvault/ddtoons/jobs/${jobId}/script.json</code> directly and then choose Approve.</p>
<p style="color:#666;font-size:13px">Job: ${jobId}</p></div>`;
}

if (require.main === module) L.main(async () => {
  const [jobId, briefB64, feedbackB64] = process.argv.slice(2);
  const dir = L.jobDir(jobId);
  fs.mkdirSync(dir, { recursive: true });
  const { cfg, cast: family, sec } = L.loadAll();
  const series = L.seriesOf(jobId);
  const cast = L.castFor(cfg, family, series);

  let brief;
  const briefFile = path.join(dir, 'brief.json');
  if (briefB64 && briefB64 !== '-' && JSON.parse(L.b64d(briefB64)).kind === 'song') {
    const b = JSON.parse(L.b64d(briefB64));
    brief = { kind: 'song', song_kind: b.song_kind === 'traditional' ? 'traditional' : 'original', song: String(b.song || '').trim(),
      learning: String(b.learning || '').trim(), notes: String(b.notes || '').trim(), created: new Date().toISOString() };
    if (brief.song.length < 3) throw new Error('say which song, or what the song should be about');
    L.writeJSON(briefFile, brief);
  } else if (briefB64 && briefB64 !== '-') {
    const b = JSON.parse(L.b64d(briefB64));
    const ids = new Set(cast.characters.map(c => c.id));
    brief = {
      idea: String(b.idea || '').trim(), lesson: String(b.lesson || '').trim(),
      format: ['story', 'rhyme', 'learn'].includes(b.format) ? b.format : 'story',
      characters: String(b.characters || '').toLowerCase().split(/[\s,]+/).filter(x => ids.has(x)),
      notes: String(b.notes || '').trim(), created: new Date().toISOString(),
    };
    if (brief.idea.length < 10) throw new Error('story idea is too short; give the writer something to work with');
    L.writeJSON(briefFile, brief);
  } else if (fs.existsSync(briefFile)) {
    brief = L.readJSON(briefFile);
  } else if (series) {
    // Episode of a series: the brief comes from the approved series bible.
    const B = series.bible, n = series.ep, N = B.episodes.length, ep = B.episodes[n - 1];
    if (!ep) throw new Error(`series ${series.id} has no part ${n}`);
    let ctx = `This is Part ${n} of ${N} of the story "${B.series_title}": ${B.logline}\n`;
    if (n > 1) ctx += `Earlier parts:\n${B.episodes.slice(0, n - 1).map(e => `Part ${e.n} "${e.title}": ${e.summary}`).join('\n')}\n` +
      `Start with ${family.characters.find(c => c.id === family.narrator).name} giving a 2-3 line recap of the story so far, then go straight into this part.\n`;
    if (ep.teaser) ctx += `End with a gentle, happy one-line teaser for the next part: ${ep.teaser}\n`;
    else if (N > 1) ctx += 'This is the final part: bring the whole story to a warm, satisfying ending.\n';
    brief = { idea: `${ep.title}: ${ep.summary}`, lesson: ep.lesson, format: series.brief.format, characters: [],
      notes: series.brief.notes, series_context: ctx, series: { id: series.id, part: n, total: N, title: B.series_title },
      created: new Date().toISOString() };
    L.writeJSON(briefFile, brief);
  } else {
    throw new Error(`job ${jobId} has no brief and is not part of a series`);
  }
  const feedback = L.b64d(feedbackB64 || '');
  const prev = feedback ? L.readJSON(path.join(dir, 'script.json'), null) : null;

  const st = L.readJSON(path.join(dir, 'status.json'), {});
  const version = (st.version || 0) + 1;
  // A new script means new scenes: move any earlier production out of the way (nothing is deleted).
  const made = fs.readdirSync(dir).filter(x => /^(scene_|line_|short_|thumbnail|final|body|concat|bumper_|metadata|shots\.json)/.test(x));
  if (made.length) {
    const arch = path.join(dir, `archive_v${st.version || 0}`);
    fs.mkdirSync(arch, { recursive: true });
    for (const x of made) fs.renameSync(path.join(dir, x), path.join(arch, x));
    L.log(`moved ${made.length} files of the previous version to ${path.basename(arch)}`);
  }
  L.setStatus(dir, { stage: 'writing', version });
  const isSong = brief.kind === 'song';
  let script = isSong ? await require('./song').write({ cfg, sec, brief, feedback, prev }) : await draft(cfg, cast, sec, brief, prev, feedback);
  if (!isSong) {
    try { script = await require('./doctor').story({ cfg, sec, script, cast, normalize, minWords: require('./writers_room').minWords(cfg, brief) }); }
    catch (e) { L.log('script doctor skipped:', e.message); }
  }
  if (!isSong && cfg.quality_gate?.enabled) {
    const quality = require('./quality_gate');
    let gate = quality.inspect(script, cast, cfg);
    if (!gate.ok) {
      const repairPrompt = `Repair ONLY these structural problems in the full script JSON. Keep the story and all good lines. Include a visual_anchor for every scene with exact costume, prop color/owner and left/centre/right position; preserve any marked chorus lines word for word and repeat the same 1-4 lines exactly three times; use at most ${cfg.video.max_clips} animated scenes. Errors: ${gate.errors.join('; ')}. Return JSON only.`;
      try {
        const repaired = L.parseJSONLoose(await L.llm(cfg, sec, repairPrompt, JSON.stringify(script), { temperature: 0.2 }));
        script = normalize(repaired.script || repaired, cast, cfg);
        gate = quality.inspect(script, cast, cfg);
      } catch (e) { L.log('quality repair failed:', e.message); }
    }
    if (!gate.ok) {
      L.writeJSON(path.join(dir, `rejected_script_v${version}.json`), { script, gate });
      throw new Error(`Script quality gate failed before approval: ${gate.errors.slice(0, 12).join('; ')}. Rejected draft saved for revision.`);
    }
    script.quality_gate = gate;
  }
  script.version = version;
  if (feedback) script.feedback_applied = feedback;
  L.writeJSON(path.join(dir, `script_v${version}.json`), script);
  L.writeJSON(path.join(dir, 'script.json'), script);
  L.setStatus(dir, { stage: 'awaiting_approval', version, title: script.title });

  return { ok: true, jobId, version, title: script.title, notify_email: cfg.notify_email,
    approve_scripts: !(cfg.auto && cfg.auto.approve_scripts === false),
    subject: `DD TV English script v${version}: ${script.title}`,
    email_html: isSong ? require('./song').emailHtml(jobId, version, script) : emailHtml(jobId, version, script, cast, brief, cfg) };
});

module.exports = { draft, castSheet, normalize, systemPrompt, userPrompt };
