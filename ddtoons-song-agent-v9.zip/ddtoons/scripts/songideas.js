'use strict';
// usage: node songideas.js ideas <hintB64|-> <mix>          -> 8 researched song ideas, emailed as a numbered list
//        node songideas.js choose <batch> <n> <ownB64|->    -> starts the song job for idea n (or your own idea)
// mix: "mix" | "traditional" | "original"
const fs = require('fs');
const path = require('path');
const L = require('./lib');
const { TRADITIONAL, FORMULA } = require('./song');

// Real numbers from YouTube (secrets.json "youtube_key"): recent kids' songs (see research.js).
async function youtubeEvidence(cfg, sec) {
  try {
    const d = await require('./research').trending(cfg, sec, { months: (cfg.research && cfg.research.months) || 3 });
    const cutoff = Date.now() - ((cfg.research && cfg.research.months) || 3) * 30 * 86400e3;
    return d.live ? d.items.filter(v => Date.parse(v.published) >= cutoff && !/\b(hindi|ghar|jaldi|mere)\b/i.test(v.title)).slice(0, 40) : [];
  } catch (e) { L.log('YouTube research skipped:', e.message); return []; }
}

function formatReferences(cfg) {
  const file = path.join(L.ROOT, cfg.research?.reference_file || 'config/reference_examples.json');
  const data = L.readJSON(file, { examples: [] });
  return (data.examples || []).map(x => `- ${x.type}: ${x.observed_mechanics.join('; ')}. Video ${x.video_id}.`).join('\n');
}

function matchesHint(idea, hint) {
  if (!hint) return true;
  const h = hint.toLowerCase(), concept = `${idea.title} ${idea.song}`.toLowerCase();
  if (/bath|splash/.test(h) && /bed|pajama|goodnight|sleep/.test(h))
    return /bath|splash/.test(concept) && /bed|pajama|goodnight|sleep/.test(concept);
  return true;
}

async function reviewIdeas(cfg, sec, ideas, videos, hint) {
  const candidates = ideas.map((x, index) => ({ index, kind: x.kind, title: x.title, song: x.song, learning: x.learning,
    why: x.why, evidence: x.evidence.map(e => ({ rank: e.n, match: e.match, video_title: videos[e.n - 1]?.title })) }));
  const system = `You are the independent preschool song idea editor. The showrunner's theme is a hard requirement: ${hint || '(open theme)'}. Every original idea must stay within it. Check each idea for a coherent title, setting, action and learning goal. Remove stray plot elements from other ideas. Avoid named characters at idea stage; the songwriter invents the cast later. Check that a video TITLE supports each evidence claim; public metadata cannot prove lyrics or performance. Preserve a familiar traditional rhyme's name. Never insert a source channel's lyrics, characters, melody or distinctive plot. Rewrite an off-theme or confused one-sentence concept to meet the showrunner's theme; reject it if that cannot be done. The "why" field is a positive, cautious reason for a parent to consider the idea, never a critique of a previous draft or a description of your edits.
Reply ONLY with JSON: {"reviews":[{"index":0,"status":"pass|rewrite|reject","title":"revised title if rewrite","song":"revised one-sentence concept if rewrite","why":"accurate cautious reason if rewrite","keep_ranks":[1,2],"reason":"brief reason"}]}. Return exactly one review per input index. For pass, keep_ranks may list all supplied ranks. For rewrite, keep only evidence ranks whose title directly supports the revised claim. For reject, give a concrete reason.`;
  const j = L.parseJSONLoose(await L.llm(cfg, sec, system, JSON.stringify(candidates), { temperature: 0.2, web: false }));
  if (!Array.isArray(j.reviews) || j.reviews.length !== ideas.length) throw new Error('idea review returned an incomplete list');
  for (let i = 0; i < ideas.length; i++) {
    const r = j.reviews.find(v => v.index === i);
    if (!r || !['pass', 'rewrite', 'reject'].includes(r.status)) throw new Error(`idea review missing decision for ${i + 1}`);
    if (r.status === 'reject') throw new Error(`idea ${i + 1} rejected: ${String(r.reason || '').slice(0, 150)}`);
    if (r.status === 'rewrite') {
      if (typeof r.title !== 'string' || typeof r.song !== 'string' || typeof r.why !== 'string' || r.song.trim().length < 20) throw new Error(`idea ${i + 1} review had no usable rewrite`);
      Object.assign(ideas[i], { title: r.title.trim(), song: r.song.trim(), why: r.why.trim() });
    }
    if (Array.isArray(r.keep_ranks)) ideas[i].evidence = ideas[i].evidence.filter(e => r.keep_ranks.includes(e.n));
    if (!matchesHint(ideas[i], hint)) throw new Error(`idea ${i + 1} ignored the showrunner theme`);
    if (hint && !/\bpip\b/i.test(hint) && /\bpip\b/i.test(`${ideas[i].title} ${ideas[i].song}`)) throw new Error(`idea ${i + 1} reused an unrelated named character`);
    if (/unrelated|does not fit|cannot verify|oak.tree|distract|no evidence titles|supplied titles|previous draft/i.test(ideas[i].why))
      ideas[i].why = ideas[i].evidence.length ? 'Recent video titles cover a related theme; views do not predict results for this original song.' : 'A familiar preschool theme or seasonal idea, without direct recent video evidence.';
    ideas[i].review = r.status === 'rewrite' ? 'Edited for coherence' : 'Reviewed';
  }
  return ideas;
}

async function ideas(hint, mix) {
  const { cfg, sec } = L.loadAll();
  const histFile = path.join(L.ROOT, 'ideas_history.json');
  const history = L.readJSON(histFile, []);
  const used = history.map(h => String(h.source || h.title));
  const yt = await youtubeEvidence(cfg, sec);
  const today = new Date().toISOString().slice(0, 10);
  const months = (cfg.research && cfg.research.months) || 3;
  const want = mix === 'traditional' ? '8 traditional rhymes' : mix === 'original' ? '8 original songs' : '4 traditional rhymes and 4 original songs';
  const system = `You are the music researcher and songwriter of "DD TV English", a kids' song channel for ${cfg.script.audience}. Today is ${today}.
${FORMULA}

TASK: research and propose ${want} that are most likely to get views right now.
${hint ? `SHOWRUNNER THEME (mandatory for EVERY idea): ${hint}. Give eight variations within this theme, not eight unrelated topics. If evidence is weak for a variation, leave its evidence list empty.` : ''}
- Traditional rhymes ONLY from this list (public domain): ${TRADITIONAL.join('; ')}.
- Original songs: new lyrics and ideas, never copied; themes toddlers love or live (routines, animals, vehicles, colours, food, feelings, seasons, festivals coming up soon).
- Prefer themes and rhymes that are popular right now (use the data you are given and any web results), and seasonal moments in the next 4-6 weeks.
- One original idea may be a cohesive three-part mini-medley: energetic opening, warm family section, cheerful ending. Keep all three parts on one theme.
- Each "song" is a complete, coherent one-sentence concept. Keep its action and setting aligned with the title and learning goal. Avoid named protagonists in the idea; the songwriter invents the cast later. Do not recycle a plot beat across unrelated ideas.
- Study these format observations as inspiration only. Never copy any source video's lyrics, melody, title, characters, visuals, or scene sequence:
${formatReferences(cfg)}
- Do NOT propose anything already made: ${used.slice(-60).join('; ') || '(none yet)'}.
- "why": one short sentence. Only quote numbers that appear in the data you were given or in web results; otherwise say why it is evergreen or seasonal. Never invent view counts.
- An evidence video only supports the words/topics visible in its title or description. Family alone is weak support for bedtime. Do not claim that view count proves the idea will perform well.

Reply with ONLY this JSON:
{ "ideas": [ { "kind": "traditional|original", "song": "rhyme name, or the original song idea in one sentence",
  "title": "catchy YouTube title", "learning": "counting / colours / animals / body parts / routine / ...", "why": "...", "evidence": [ { "rank": 1, "match": "same_song|same_theme|loose" } ] } ] }
"match": same_song = the video is the same song/rhyme; same_theme = a different song on the same topic or learning theme; loose = only loosely related.
${L.houseStyle()}`;
  const row = (v, i) => `#${i + 1} [${v.short ? 'SHORT' : 'FULL SONG'}] "${v.title}" | ${v.channel} | ${L.fmtM(v.views)} views | ${L.fmtM(v.views_per_day)}/day | ${v.published}`;
  const user = `${yt.length ? `English kids' song videos published in the last ${months} months on YouTube (real metadata, ranked by total views; the #number is the rank):\n${yt.map(row).join('\n')}\nViews/day is only a rough momentum proxy. Compare several channels and avoid treating one large channel as proof. For every idea, list the 1-3 videos that directly support its theme (empty list if none).` : 'No live recent YouTube data available; use evergreen themes and label your reasoning as editorial judgment.'}${hint ? `\nFINAL PRIORITY: All ${want} must follow the showrunner theme: ${hint}. Ignore unrelated trends above. No unrelated named character. The "why" explains appeal and fitting evidence, never editorial criticism.` : ''}`;
  let list, lastErr;
  for (let a = 1; a <= 2 && !list; a++) {
    try {
      const j = L.parseJSONLoose(await L.llm(cfg, sec, system, user + (a > 1 ? `\nPrevious reply invalid (${lastErr}). JSON only.` : ''), { temperature: 0.75, web: false }));
      const xs = (j.ideas || []).map(x => ({ kind: /trad/i.test(x.kind) ? 'traditional' : 'original', song: String(x.song || '').trim(), title: String(x.title || x.song || '').trim(),
        learning: String(x.learning || ''), why: String(x.why || ''),
        evidence: (Array.isArray(x.evidence) ? x.evidence : []).map(e => {
          const n = parseInt(String(typeof e === 'object' ? e.rank : e).replace('#', ''), 10);
          const m = String(typeof e === 'object' ? e.match : '').toLowerCase();
          return { n, match: /same.?song/.test(m) ? 'same_song' : /theme/.test(m) ? 'same_theme' : 'loose' };
        }).filter(e => e.n >= 1 && e.n <= yt.length).slice(0, 3) }))
        .filter(x => x.song && (x.kind === 'original' || TRADITIONAL.some(t => t.toLowerCase() === x.song.toLowerCase() || x.song.toLowerCase().includes(t.toLowerCase().split(' (')[0]))));
      if (xs.length < 8) throw new Error(`only ${xs.length} usable ideas`);
      list = await reviewIdeas(cfg, sec, xs.slice(0, 8), yt, hint);
    } catch (e) { lastErr = e.message; L.log(`ideas attempt ${a}: ${e.message}`); }
  }
  if (!list) throw new Error(`could not research song ideas: ${lastErr}`);
  let layaUsed = false;
  for (const x of list) {
    if (!x.evidence.length) continue;
    const q = {};
    x.evidence.forEach((e, i) => { q[`v${i}`] = { type: 'choice', instructions: `How does this YouTube video relate to the song idea? Video: "${yt[e.n - 1].title.slice(0, 120)}"`,
      criteria: { same_song: 'it is the same song or rhyme', same_theme: 'a different song with the same topic or learning theme', loose: 'only loosely related or unrelated' } }; });
    const ans = await L.laya(cfg, { song_idea: `${x.title}. ${x.kind === 'traditional' ? 'Traditional rhyme: ' : ''}${x.song}. Learning: ${x.learning}` }, q);
    if (ans) { layaUsed = true; x.evidence.forEach((e, i) => { const a = ans[`v${i}`]; if (a && a.choice) { e.match = a.choice; e.p = Math.round(Math.max(...Object.values(a.probabilities || { x: 0 })) * 100); } }); }
  }
  // Score for ordering only; a video's views are not a prediction for our song.
  const W = { same_song: 1, same_theme: 0.5, loose: 0.1 };
  for (const x of list) {
    x.score = Math.max(0, ...x.evidence.map(e => yt[e.n - 1].views * W[e.match] * (yt[e.n - 1].short ? 0.25 : 1)));
    const strong = x.evidence.filter(e => e.match !== 'loose').map(e => yt[e.n - 1]);
    const channels = new Set(strong.map(v => v.channel));
    x.heat = !x.evidence.length ? 'Evergreen / seasonal idea'
      : !strong.length ? 'Loose video links only'
      : `${strong.length} related video${strong.length === 1 ? '' : 's'} across ${channels.size} channel${channels.size === 1 ? '' : 's'} (metadata only)`;
  }
  list.sort((a, b) => b.score - a.score);
  const batch = `s${new Date().toISOString().slice(2, 16).replace(/[-:T]/g, '')}`;
  const dir = path.join(L.ROOT, 'pitches'); fs.mkdirSync(dir, { recursive: true });
  L.writeJSON(path.join(dir, `${batch}.json`), { batch, created: today, ideas: list });
  const rows = list.map((x, i) => `<tr><td style="padding:8px;vertical-align:top;font-size:20px;color:#7c3aed"><b>${i + 1}</b></td>
<td style="padding:8px"><b>${L.esc(x.title)}</b><br>${x.kind === 'traditional' ? '🎵 Traditional rhyme' : '🎶 Original song'} · ${L.esc(x.learning)}<br>
<span style="color:#555">${L.esc(x.kind === 'original' ? x.song : '')}</span>
<div style="margin:4px 0"><b>${x.heat}</b></div>
${x.evidence.map(e => { const v = yt[e.n - 1]; const tag = { same_song: '✅ same song', same_theme: '🟡 same theme', loose: '⚪ loose link' }[e.match]; return `<div style="font-size:13px;color:#0f766e">📊 #${e.n} · <b>${L.fmtM(v.views)} views</b> · ${v.short ? '📱 Short' : '🎬 full song'} · <b>${tag}</b>${e.p ? ` <span style="color:#888">(Laya ${e.p}%)</span>` : ''} · "${L.esc(v.title.slice(0, 70))}" (${L.esc(v.channel)})</div>`; }).join('')}
<div style="color:#888;font-size:13px">💡 ${L.esc(x.why)}</div></td></tr>`).join('');
  const chart = yt.length ? `<p style="margin:16px 0 4px"><b>📈 Most viewed among sampled videos published in the last ${months} months</b></p>
<table style="border-collapse:collapse;font-size:13px">${yt.slice(0, 12).map((v, i) => `<tr><td style="padding:2px 6px;color:#7c3aed">#${i + 1}</td><td style="padding:2px 6px;text-align:right"><b>${L.fmtM(v.views)}</b></td><td style="padding:2px 6px;color:#555">${L.fmtM(v.views_per_day)}/day</td><td style="padding:2px 6px">${v.short ? '📱' : '🎬'} ${L.esc(v.title.slice(0, 60))} <span style="color:#888">(${L.esc(v.channel)})</span></td></tr>`).join('')}</table>` : '';
  return { ok: true, batch, notify_email: cfg.notify_email, subject: 'DD TV English: 8 song ideas to choose from',
    email_html: `<div style="font-family:Arial,sans-serif;max-width:720px"><p>Here are 8 researched song ideas${yt.length ? ' (based on real YouTube view data)' : ''}. Pick one in the next email, ask for 8 new ones, or type your own.</p>
<table style="border-collapse:collapse">${rows}</table>${chart}
<p style="color:#888;font-size:12px">🎬 = full song · 📱 = Short. Ideas are sorted by evidence strength (full songs of the same song count most). Real YouTube data from the last ${months} months.${layaUsed ? ' Evidence links double-checked by Laya.' : ''}</p></div>` };
}

async function choose(batch, n, own) {
  const { cfg } = L.loadAll();
  let brief;
  if (own) {
    const trad = TRADITIONAL.find(t => own.toLowerCase().includes(t.toLowerCase().split(' (')[0]));
    brief = { kind: 'song', song_kind: trad ? 'traditional' : 'original', song: trad || own, learning: '', notes: own };
  } else {
    const data = L.readJSON(path.join(L.ROOT, 'pitches', `${batch}.json`));
    const x = data.ideas[(parseInt(n, 10) || 1) - 1];
    if (!x) throw new Error(`no idea ${n} in ${batch}`);
    brief = { kind: 'song', song_kind: x.kind, song: x.song, learning: x.learning, notes: `Title idea: ${x.title}` };
  }
  const histFile = path.join(L.ROOT, 'ideas_history.json');
  const history = L.readJSON(histFile, []);
  history.push({ date: new Date().toISOString().slice(0, 10), title: brief.song.slice(0, 60), source: brief.song_kind === 'traditional' ? brief.song : 'original song', lesson: brief.learning });
  L.writeJSON(histFile, history.slice(-300));
  const slug = brief.song.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 22).replace(/-+$/, '') || 'song';
  return { ok: true, kind: 'song', jobId: `dd_${new Date().toISOString().slice(2, 16).replace(/[-:T]/g, '')}_song-${slug}`,
    briefB64: Buffer.from(JSON.stringify(brief)).toString('base64'), feedbackB64: '', notify_email: cfg.notify_email };
}

L.main(async () => {
  const [mode, a1, a2, a3] = process.argv.slice(2);
  if (mode === 'ideas') return ideas(L.b64d(a1 || ''), a2 || 'mix');
  if (mode === 'choose') return choose(a1, a2, L.b64d(a3 || ''));
  throw new Error('use: ideas | choose');
});
