'use strict';
const fs=require('fs');const path=require('path');const {spawnSync}=require('child_process');
const dir=__dirname, ledger=path.join(dir,'narration-request.json'), audio=path.join(dir,'konark-hindi.mp3');
const visual=path.join(dir,'konark-visual-v2.mp4'), out=path.join(dir,'konark-example-v2.mp4');
const script='रुकिए! कोणार्क का सूर्य मंदिर एक विशाल पत्थर के रथ जैसा क्यों दिखता है? तेरहवीं शताब्दी में बने इस मंदिर को सूर्य देव के रथ के रूप में कल्पित किया गया था। इसके मंच पर बारह जोड़ी नक्काशीदार पहिए हैं। बारह जोड़ी यानी चौबीस पहिए! हर पहिए में बारीक कारीगरी दिखाई देती है। अब पहियों को फिर से देखिए: क्या आपको मंदिर एक रथ जैसा नजर आता है? और बताइए, बारह जोड़ी पहिए कुल कितने हुए?';
const voice='zgqefOY5FPQ3bB7OZTVR'; // Niraj - Hindi Narrator, from account voices list.
async function main(){
 if(!fs.existsSync(visual))throw Error('Missing visual MP4');
 if(!process.argv.includes('--run')){console.log(JSON.stringify({dryRun:true,text:script,characters:script.length,voice:'Niraj',model:'eleven_multilingual_v2',visual},null,2));return}
 if(fs.existsSync(ledger))throw Error('Narration request already recorded. Do not rerun.');
 const key=JSON.parse(fs.readFileSync('/data/secrets.json','utf8')).elevenlabs_key;
 if(!key)throw Error('ElevenLabs key missing');
 fs.writeFileSync(ledger,JSON.stringify({status:'submitting',characters:script.length,voice,at:new Date().toISOString()},null,2));
 const r=await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voice}?output_format=mp3_44100_128`,{method:'POST',headers:{'xi-api-key':key,'Content-Type':'application/json'},body:JSON.stringify({text:script,model_id:'eleven_multilingual_v2'}),signal:AbortSignal.timeout(180000)});
 if(!r.ok)throw Error(`ElevenLabs HTTP ${r.status}: ${(await r.text()).slice(0,500)}`);
 const data=Buffer.from(await r.arrayBuffer());if(data.length<1000)throw Error('Audio unexpectedly small');
 fs.writeFileSync(audio,data);
 fs.writeFileSync(ledger,JSON.stringify({status:'complete',characters:script.length,voice,bytes:data.length,at:new Date().toISOString()},null,2));
 const f='/data/bin/ffmpeg', probe='/data/bin/ffprobe';
 const q=spawnSync(probe,['-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',audio],{encoding:'utf8'});
 const seconds=Number(q.stdout.trim());if(!Number.isFinite(seconds))throw Error('Cannot measure narration duration');
 const tempo=Math.max(1,Math.min(1.5,seconds/28.5));
 if(seconds/tempo>29.5)throw Error(`Narration is ${seconds.toFixed(1)}s and cannot fit naturally. Audio saved; edit visual duration before mixing.`);
 const filter=`[1:a]atempo=${tempo.toFixed(3)},adelay=300:all=1,apad,atrim=0:30[a]`;
 const p=spawnSync(f,['-hide_banner','-loglevel','error','-y','-i',visual,'-i',audio,'-filter_complex',filter,'-map','0:v:0','-map','[a]','-t','30','-c:v','copy','-c:a','aac','-b:a','128k','-movflags','+faststart',out],{stdio:'inherit',timeout:180000});
 if(p.error)throw p.error;if(p.status!==0)throw Error('FFmpeg failed');
 console.log(JSON.stringify({ok:true,file:out,voiceSeconds:seconds,tempo,bytes:fs.statSync(out).size},null,2));
}
main().catch(e=>{console.error(e.message);process.exitCode=1});
