Konark Hindi Short v2 — review copy

Changes: 374-character Hindi voice script; no slow-down filter; 3-second visual beats; 30-second vertical video.
The pictures are artistic illustrations, not archaeological documentation. Check facts and visual accuracy before publishing.

On Hostinger, extract this ZIP inside /opt/storyvault, set owner 1000:1000, then run:
  docker exec n8n-wx3b-n8n-1 node /data/konark-v2/konark_narrate.js
  docker exec n8n-wx3b-n8n-1 node /data/konark-v2/konark_narrate.js --run
The second command submits ONE 374-character ElevenLabs request and outputs /data/konark-v2/konark-example-v2.mp4.
Do not rerun after it records narration-request.json; report any error for recovery without another paid request.
