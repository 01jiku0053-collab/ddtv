# Plassey: the army that did not fight — 60-second sample

This is a 16:9 Hindi documentary sample. It reuses your already generated `scene-1.mp4` and `scene-2.mp4` from `/data/plassey-cinematic-sample/`. Eight additional scenes use the supplied original illustrations and map with subtle camera motion. The music bed is original synthesized audio. No new Kling or Runware requests are made.

## On the Hostinger server

After extracting this folder to `/opt/storyvault/plassey-60s` and setting its owner to `1000:1000`:

```sh
docker exec n8n-wx3b-n8n-1 node /data/plassey-60s/assemble.js
docker exec n8n-wx3b-n8n-1 node /data/plassey-60s/assemble.js --visual
docker exec n8n-wx3b-n8n-1 node /data/plassey-60s/assemble.js --run
docker cp /opt/storyvault/plassey-60s/plassey-60s.mp4 visual-studio-code-server-hlvi-code-server-1:/config/plassey-60s.mp4
```

Run one command at a time. The first prints the script and source list without making a request. `--visual` creates a silent 60-second edit and costs nothing. `--run` uses the saved visual, makes **one ElevenLabs text-to-speech request** if `narration.mp3` is absent, then mixes the voice and music. If a voice request fails after submission, the script records `voice-request.json` and refuses to retry automatically; inspect before any retry to avoid accidental duplicate spending.

The script expects the existing two videos in `/data/plassey-cinematic-sample/`, `/data/bin/ffmpeg`, `/data/bin/ffprobe`, and an `elevenlabs_key` in `/data/secrets.json`. It does not publish anything. Output: `/opt/storyvault/plassey-60s/plassey-60s.mp4`.

## Editorial notes

The pictures and reenactments illustrate the story; they are not archival footage. The map is schematic and is not intended for precise geography. The hook concerns Mir Jafar's contingent, which held back from the fighting. The rain and artillery sequence is summarized from the National Army Museum account. Plassey took place on 23 June 1757; the Company received Bengal revenue collection rights in 1765. Sources: [National Army Museum](https://www.nam.ac.uk/explore/battle-plassey) and [NCERT, From Trade to Territory](https://ncert.nic.in/textbook/pdf/hess202.pdf). Review the final narration and pictures before publishing.

## Timing and cost

Ten six-second shots give a 60-second video. Audio is stretched or compressed only within 15% to fit; otherwise `--run` stops and leaves the generated MP3 for editing without another voice request. The two Kling clips were already paid for (reported $0.504 each). The only new paid step is the single ElevenLabs narration; its actual charge depends on your account plan.
