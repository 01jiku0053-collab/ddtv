'use strict';
const fs=require('fs'),path=require('path'),{spawnSync}=require('child_process');
const root=__dirname, ff='/data/bin/ffmpeg',probe='/data/bin/ffprobe';
const original='/data/plassey-cinematic-sample';
const script='पलाशी के मैदान में एक सेनापति अपनी सेना लेकर आया। लेकिन युद्ध शुरू होते ही उसकी टुकड़ी खड़ी रही। क्यों? 23 जून 1757 को बंगाल के नवाब सिराजुद्दौला का सामना ईस्ट इंडिया कंपनी से था। नवाब की सेना बड़ी थी; कंपनी की फौज बहुत छोटी। मगर लड़ाई से पहले क्लाइव और बंगाल के प्रभावशाली बैंकरों ने मीर जाफ़र को नवाब बनाने का गुप्त वादा किया था। फिर तेज बारिश हुई। कंपनी ने अपनी तोपें और बारूद ढक लिया; नवाब की तोपें भीग गईं। जब नवाब के सैनिक आगे बढ़े, कंपनी की तोपें फिर गरजीं। उसी समय मीर जाफ़र की घुड़सवार टुकड़ी लड़ाई में शामिल नहीं हुई। सिराज हार गए। मीर जाफ़र नवाब बने। लेकिन सबसे बड़ा विजेता था एक व्यापारिक संगठन: ईस्ट इंडिया कंपनी। आठ साल बाद उसी कंपनी को बंगाल से राजस्व वसूलने का अधिकार मिला।';
const shots=[
 {kind:'video',source:'scene-2.mp4',note:'The army that stood still'},
 {kind:'image',source:'map.jpg',note:'Bengal and Palashi'},
 {kind:'image',source:'court.jpg',note:'Siraj in the court, illustrative reconstruction'},
 {kind:'video',source:'scene-1.mp4',note:'Secret promise, illustrative reconstruction'},
 {kind:'image',source:'rain.jpg',note:'Monsoon on artillery'},
 {kind:'image',source:'cover.jpg',note:'Company guns protected'},
 {kind:'image',source:'cavalry.jpg',note:'Cavalry holds position'},
 {kind:'image',source:'retreat.jpg',note:'Nawab’s forces withdraw'},
 {kind:'image',source:'throne.jpg',note:'Change of nawab, symbolic illustration'},
 {kind:'image',source:'ledger.jpg',note:'1765 revenue rights'}
];
const file=n=>path.join(root,n);
const run=(bin,args)=>{const p=spawnSync(bin,args,{encoding:'utf8',timeout:240000,stdio:['ignore','pipe','pipe']});if(p.error)throw p.error;if(p.status!==0)throw Error(`${path.basename(bin)} failed: ${p.stderr.slice(-1400)}`);return p.stdout.trim()};
const duration=p=>Number(run(probe,['-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',p]));
function preflight(){for(const s of shots){const p=s.kind==='video'?path.join(original,s.source):file(s.source);if(!fs.existsSync(p))throw Error(`Missing ${p}`)}if(!fs.existsSync(file('bed.mp3')))throw Error('Missing bed.mp3')}
function makeShot(s,i){const out=file(`part-${String(i+1).padStart(2,'0')}.mp4`);if(fs.existsSync(out)&&Math.abs(duration(out)-6)<.3)return out;
 const input=s.kind==='video'?path.join(original,s.source):file(s.source);let args;
 if(s.kind==='image'){
   const zoom=`zoompan=z='min(1.12,1+0.0008*on)':x='(iw-iw/zoom)*(on/144)':y='(ih-ih/zoom)/2':d=1:s=1280x720:fps=24,format=yuv420p`;
   args=['-hide_banner','-loglevel','error','-y','-loop','1','-framerate','24','-t','6','-i',input,'-vf',zoom];
 }else args=['-hide_banner','-loglevel','error','-y','-i',input,'-vf','fps=24,scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720,setsar=1,format=yuv420p'];
 run(ff,[...args,'-an','-frames:v','144','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-r','24',out]);
 if(Math.abs(duration(out)-6)>.3)throw Error(`Part ${i+1} duration incorrect: ${duration(out)}`);return out;
}
function visual(){preflight();const parts=shots.map(makeShot);const list=file('concat.txt');fs.writeFileSync(list,parts.map(p=>`file '${p.replace(/'/g,"'\\''")}'`).join('\n')+'\n');const out=file('visual-60s.mp4');run(ff,['-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',list,'-an','-c:v','copy','-movflags','+faststart',out]);if(Math.abs(duration(out)-60)>.7)throw Error(`Visual duration incorrect: ${duration(out)}`);return out}
async function voice(){const p=file('narration.mp3'),ledger=file('voice-request.json');if(fs.existsSync(p))return p;if(fs.existsSync(ledger))throw Error('Voice request exists without an audio file; do not request again until inspected.');const key=JSON.parse(fs.readFileSync('/data/secrets.json','utf8')).elevenlabs_key;if(!key)throw Error('ElevenLabs key missing');fs.writeFileSync(ledger,JSON.stringify({status:'submitting',characters:script.length,at:new Date().toISOString()},null,2));const r=await fetch('https://api.elevenlabs.io/v1/text-to-speech/zgqefOY5FPQ3bB7OZTVR?output_format=mp3_44100_128',{method:'POST',headers:{'xi-api-key':key,'Content-Type':'application/json'},body:JSON.stringify({text:script,model_id:'eleven_multilingual_v2'}),signal:AbortSignal.timeout(180000)});if(!r.ok)throw Error(`ElevenLabs ${r.status}: ${(await r.text()).slice(0,300)}`);const b=Buffer.from(await r.arrayBuffer());if(b.length<10000)throw Error('Voice too short to be valid');fs.writeFileSync(p,b);fs.writeFileSync(ledger,JSON.stringify({status:'complete',characters:script.length,bytes:b.length,at:new Date().toISOString()},null,2));return p}
async function main(){const mode=process.argv[2];if(!mode){console.log(JSON.stringify({dryRun:true,format:'60 seconds, 16:9',sources:shots,narration:script,words:script.split(/\s+/).length,newVideoGenerations:0,voiceRequest:1,sourceVideos:shots.filter(s=>s.kind==='video').map(s=>s.source)},null,2));return}if(!['--visual','--run'].includes(mode))throw Error('Use --visual or --run');const v=visual();if(mode==='--visual'){console.log(JSON.stringify({ok:true,visual:v,seconds:duration(v),newVideoGenerations:0}));return}
 const a=await voice(),sec=duration(a);if(!Number.isFinite(sec))throw Error('Cannot measure voice');const tempo=sec/58.6;if(tempo<.85||tempo>1.15)throw Error(`Narration lasts ${sec.toFixed(1)} seconds; audio saved but automatic retiming would distort it`);
 const out=file('plassey-60s.mp4');const filter=`[1:a]atempo=${tempo.toFixed(4)},adelay=240:all=1,apad,atrim=0:60,volume=1.25[v];[2:a]volume=0.17,atrim=0:60[b];[v][b]amix=inputs=2:duration=first:normalize=0[a]`;
 run(ff,['-hide_banner','-loglevel','error','-y','-i',v,'-i',a,'-i',file('bed.mp3'),'-filter_complex',filter,'-map','0:v:0','-map','[a]','-t','60','-c:v','copy','-c:a','aac','-b:a','160k','-movflags','+faststart',out]);console.log(JSON.stringify({ok:true,file:out,seconds:duration(out),voiceSeconds:sec,voiceTempo:tempo,newVideoGenerations:0,bytes:fs.statSync(out).size},null,2))}
main().catch(e=>{console.error(e.message);process.exitCode=1});
