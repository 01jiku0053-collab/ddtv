'use strict';
// One paid Runware request, then poll the same UUID. No retries or batches.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = __dirname;
const imagePath = path.join(root, 'approved-scene.png');
const outPath = path.join(root, 'animated-test.mp4');
const ledgerPath = path.join(root, 'request.json');
const secretPath = '/data/secrets.json';
const estimatedUSD = 0.51;
const maxUSD = 0.60;
const prompt = `Use the supplied image as the exact first frame. A single continuous five-second wide shot, fixed camera, the same cream hamster, white duck, notebook, cup, large leaf, lantern, river, and bridge in their original positions. The hamster visibly writes two short pencil strokes, pauses, gently turns one notebook page with a paw, then resumes writing. The duck floats softly in place, bobs with the river, and blinks once. Fine rain falls continuously, concentric ripples travel across the river, and warm cup steam curls upward. Natural small movements with consistent anatomy and clothing. Preserve the painterly background, warm lantern light, calm adult study mood, and original composition. No zoom, camera cuts, new subjects, extra limbs, morphing, text, speech, or music. Audio: quiet realistic rain and soft river only.`;

async function api(key, tasks) {
  const response = await fetch('https://api.runware.ai/v1', {
    method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(tasks), signal: AbortSignal.timeout(120000)
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok || (body.errors || []).length) {
    throw new Error(`Runware HTTP ${response.status}: ${JSON.stringify(body.errors || body).slice(0, 600)}`);
  }
  return body.data || [];
}

async function main() {
  if (!fs.existsSync(imagePath)) throw new Error('approved-scene.png missing');
  if (estimatedUSD > maxUSD) throw new Error('Cost ceiling exceeded');
  if (fs.existsSync(ledgerPath)) throw new Error('A request was already submitted; this script refuses another');
  const taskUUID = crypto.randomUUID();
  const task = {
    taskType: 'videoInference', taskUUID,
    model: 'bytedance:seedance@2.5',
    inputs: { frameImages: [{ image: 'data:image/png;base64,' + fs.readFileSync(imagePath).toString('base64'), frame: 'first' }] },
    positivePrompt: prompt, resolution: '480p', duration: 5,
    deliveryMethod: 'async', outputType: 'URL', outputFormat: 'MP4',
    numberResults: 1, includeCost: true
  };
  if (!process.argv.includes('--run')) {
    console.log(JSON.stringify({ dryRun: true, model: task.model, duration: task.duration,
      resolution: task.resolution, generations: task.numberResults,
      estimatedUSD, maxUSD, imageBytes: fs.statSync(imagePath).size, prompt }, null, 2));
    return;
  }
  if (!fs.existsSync(secretPath)) throw new Error('/data/secrets.json missing');
  const sec = JSON.parse(fs.readFileSync(secretPath, 'utf8'));
  if (!sec.runware_key) throw new Error('runware_key missing from /data/secrets.json');
  // Record the UUID before submission, so rerunning after any error cannot charge twice.
  fs.writeFileSync(ledgerPath, JSON.stringify({ taskUUID, status: 'submitting', estimatedUSD, maxUSD, submittedAt: new Date().toISOString() }, null, 2));
  const data = await api(sec.runware_key, [task]);
  if (data.some(x => x.videoURL)) return download(data.find(x => x.videoURL));
  const deadline = Date.now() + 15 * 60000;
  while (Date.now() < deadline) {
    await new Promise(resolve => setTimeout(resolve, 10000));
    const result = await api(sec.runware_key, [{ taskType: 'getResponse', taskUUID }]);
    const ready = result.find(x => x.taskUUID === taskUUID && x.videoURL);
    if (ready) return download(ready);
    if (result.some(x => x.taskUUID === taskUUID && x.status === 'error')) throw new Error('Generation failed: ' + JSON.stringify(result));
  }
  throw new Error(`Still pending after 15 minutes. Task UUID: ${taskUUID}. Do not rerun this script.`);
}

async function download(ready) {
  const r = await fetch(ready.videoURL, { signal: AbortSignal.timeout(120000) });
  if (!r.ok) throw new Error('Video download failed; task remains recorded in request.json');
  fs.writeFileSync(outPath, Buffer.from(await r.arrayBuffer()));
  const prior = JSON.parse(fs.readFileSync(ledgerPath, 'utf8'));
  fs.writeFileSync(ledgerPath, JSON.stringify({ ...prior, status: 'complete', actualUSD: ready.cost ?? null, videoFile: outPath }, null, 2));
  console.log(JSON.stringify({ ok: true, file: outPath, actualUSD: ready.cost ?? null, bytes: fs.statSync(outPath).size }, null, 2));
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
