Rainy study animation: ONE 5-second motion test

This package uses the existing Runware key in /data/secrets.json inside your n8n container.
It sends one Seedance 2.5 image-to-video request at 480p and never resubmits automatically.
Published Runware rate when prepared: $0.102/second, estimated $0.51 for 5 seconds.
Prices can change. Confirm the current rate before using --run.

On Hostinger, upload rain-pilot-one-shot.zip into /opt/storyvault/ and run:

  cd /opt/storyvault && unzip -q rain-pilot-one-shot.zip
  docker exec n8n-wx3b-n8n-1 node /data/rain-pilot/one_shot.js

The first command checks the package; the second prints the dry run and does not spend.
When ready for the single paid test, run:

  docker exec n8n-wx3b-n8n-1 node /data/rain-pilot/one_shot.js --run

The result is saved to /opt/storyvault/rain-pilot/animated-test.mp4 on the host.
If a request errors or times out, do NOT remove request.json and do NOT rerun --run.
The task UUID in request.json can be used to recover the result without another charge.
Nothing is uploaded to YouTube, and your existing n8n workflows are untouched.
