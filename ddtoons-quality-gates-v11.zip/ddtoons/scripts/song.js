'use strict';
// SONG EPISODES (the nursery-rhyme format that dominates kids' YouTube).
//   write():   the songwriter + song editor -> script.json with kind "song" (sections, lines, one visual per line)
//   produce(): characters -> director -> pictures -> full song -> selected animated beats and illustrated stills
//              cut to the music -> video, Short, thumbnail
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const L = require('./lib');
const director = require('./director');

// Traditional rhymes with no known modern author, safe to use. (Songs like "Baby Shark" or "Wheels on the Bus"
// have modern authors/owners and are deliberately NOT on this list.)
const TRADITIONAL = ['Five Little Ducks', 'Twinkle Twinkle Little Star', 'Old MacDonald Had a Farm', 'Row Row Row Your Boat',
  'Humpty Dumpty', 'Baa Baa Black Sheep', 'Itsy Bitsy Spider', 'Five Little Monkeys Jumping on the Bed', 'Ten in the Bed',
  'Hickory Dickory Dock', 'London Bridge Is Falling Down', 'Mary Had a Little Lamb', 'The Farmer in the Dell', 'Rain Rain Go Away',
  'Hey Diddle Diddle', 'Jack and Jill', 'Bingo', 'Five Little Speckled Frogs', 'One Two Buckle My Shoe', 'Pat-a-Cake',
  'Little Bo-Peep', 'Hot Cross Buns', 'The Muffin Man', 'Ring Around the Rosie', 'Little Miss Muffet', 'Hush Little Baby',
  'Head Shoulders Knees and Toes', 'If You\'re Happy and You Know It', 'The Ants Go Marching', 'This Old Man', 'Oh Where Has My Little Dog Gone',
  'Five Little Pumpkins', 'Ten Little Fingers', 'Are You Sleeping (Frère Jacques)', 'Down by the Bay', 'Here We Go Round the Mulberry Bush'];

const FORMULA = `KIDS' SONG CRAFT (format observations, not a recipe to copy):
- Start with a clear sound or action in the first five seconds. Use a memorable original refrain.
- Aim for one coherent song near the configured duration. Use a three-part mini-medley only when the approved idea explicitly calls for one; the parts must advance the same action in chronological order.
- In a single song, repeat a simple verse pattern while changing one animal, action, colour or number. In a medley, each segment has its own short chorus and the three parts share a theme.
- Keep most lyric lines to 4-9 familiar words and a similar syllable count within each repeated verse. Rhymes must sound natural, not forced.
- Each picture shows exactly one lyric action, usually with 1-2 characters. The same approved outfit/prop carries through connected shots.
- Write for clear, slow English singing and a child-friendly original melody. Avoid distress, punishment and confusing lyrics.
- A video with many views is a research lead, not proof that copying its exact format will work. Never copy a modern song's words, tune, characters, title, costume or scene sequence.`;

// ---------- write ----------
function songSystem(cfg, brief) {
  return `You are the head songwriter of "DD TV English", a nursery-rhyme and kids' song channel for ${cfg.script.audience}.
${FORMULA}

${brief.kind === 'traditional'
  ? `Write the TRADITIONAL song "${brief.song}". Use the traditional public-domain lyrics (you may simplify, and you may add the counting/colour layer and a happy final verse). Allowed traditional songs ONLY: ${TRADITIONAL.join('; ')}. If the requested song is not on that list, write an ORIGINAL song on the same idea instead and set "kind": "original".`
  : `Write an ORIGINAL song (new lyrics and structure, never copied from any existing song) about: ${brief.song}.`}
Learning layer: ${brief.learning || 'writer\'s choice (counting is always good)'}.
Notes from the showrunner: ${brief.notes || '(none)'}
Length budget: ${(cfg.song && cfg.song.target_s) || 150} seconds at about ${(cfg.song && cfg.song.line_s) || 3.6} seconds per line. Aim for 34-42 lyric lines total; every lyric line needs a separately generated picture. Never inflate the song with duplicate action cycles merely to meet a duration.

CHARACTERS: invent the cute, original characters the song needs (list EVERY character that appears in any visual, max 6) for the song (animals are great), each with a concrete look and a pronoun.
For every line also write "visual": one sentence that shows exactly that line as a picture (who, doing what, where). Keep places consistent. For a three-part medley name sections "song 1 ...", "song 2 ...", "song 3 ..." and use original, distinct refrains connected by a shared theme.
The intro has 1-2 lines; each verse 4 lines; an optional outro of 1-2 lines ("Let's sing it again!").

${L.houseStyle()}

Reply with ONLY this JSON:
{ "title": "YouTube title, max 60 chars, like 'Five Little Ducks | Learn Colors | Kids Songs'",
  "kind": "traditional|original", "source": "song name (traditional) or 'original'",
  "learning": "...", "music_style": ["4-6 short style tags, e.g. cheerful preschool nursery rhyme, ukulele, glockenspiel, bouncy, clear happy vocals"],
  "characters": [ { "id": "lowercase", "name": "...", "look": "concrete visual description", "pronoun": "she|he", "role": "..." } ],
  "sections": [ { "name": "intro|verse 1|...|outro", "lines": [ { "text": "lyric line", "visual": "picture for this line" } ] } ],
  "description": "YouTube description, 2-3 sentences for parents", "tags": ["10 tags"],
  "thumbnail_prompt": "bright, simple close-up idea, no text" }`;
}

const EDITOR = `You are a strict editor of preschool songs. Check the song JSON against the formula and fix it:
- repeated verses have a predictable pattern; if this is a medley, each part advances the same routine and a returning chorus never replays an earlier action after that action is finished
- every line short (max 9 words) and singable, similar rhythm in matching lines
- every visual shows exactly its line; characters, clothing, places and action order stay consistent
- include a direct child participation cue; check real audible rhymes rather than ticking a box
Reply with ONLY the corrected full JSON in the same format.`;

function normalizeSong(raw) {
  const ids = new Set();
  const characters = (raw.characters || []).slice(0, 6).map(c => {
    let id = String(c.id || c.name || 'friend').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 14) || 'friend';
    while (ids.has(id)) id += 'x'; ids.add(id);
    return { id, name: String(c.name || id), look: String(c.look || '').trim(), role: String(c.role || ''),
      pronoun: /^he/i.test(c.pronoun || '') ? 'he/him' : 'she/her', voice_type: 'creature' };
  }).filter(c => c.look);
  const sections = (raw.sections || []).map(s => ({
    name: String(s.name || 'verse'),
    lines: (s.lines || []).map(l => ({ text: L.stripTags(String(l.text || l || '')).trim(), visual: String(l.visual || '').trim() })).filter(l => l.text).slice(0, 12),
  })).filter(s => s.lines.length).slice(0, 16);
  if (sections.length < 3) throw new Error(`song has only ${sections.length} sections`);
  const words = sections.reduce((t, s) => t + s.lines.reduce((u, l) => u + l.text.split(/\s+/).length, 0), 0);
  return { kind: 'song', song_kind: raw.kind === 'traditional' ? 'traditional' : 'original', source: String(raw.source || 'original'),
    title: String(raw.title || 'Kids Song').slice(0, 90), learning: String(raw.learning || ''), lesson: String(raw.learning || ''),
    music_style: (raw.music_style || []).map(String).slice(0, 6), characters, sections,
    description: String(raw.description || ''), tags: (raw.tags || []).map(String).slice(0, 15),
    thumbnail_prompt: String(raw.thumbnail_prompt || ''), words };
}

// turn the song into "scenes" (one per lyric line) with planned timing, so the director and renderer can use them
function toScenes(song, lineSeconds) {
  let n = 0;
  const scenes = [];
  for (const [si, s] of song.sections.entries()) for (const l of s.lines) {
    n++;
    const chars = song.characters.filter(c => new RegExp(`\\b${c.name}\\b`, 'i').test(`${l.visual} ${l.text}`)).map(c => c.id);
    scenes.push({ n, section: si, characters: chars.length ? chars.slice(0, 3) : song.characters.slice(0, 2).map(c => c.id),
      image_prompt: l.visual || l.text, animate: true, motion_prompt: `acting out: ${l.text}`,
      lines: [{ speaker: 'singer', text: l.text, sing: true }], planned_s: lineSeconds * (s.name === 'intro' ? 1.2 : 1) });
  }
  return scenes;
}

async function write({ cfg, sec, brief, feedback, prev }) {
  let user = `Write the song now.`;
  if (prev && feedback) user = `Previous version:\n${JSON.stringify(prev)}\n\nShowrunner feedback (priority):\n${feedback}\nRewrite the full song applying the feedback.`;
  let lastErr, song;
  for (let a = 1; a <= 2 && !song; a++) {
    try { song = normalizeSong(L.parseJSONLoose(await L.llm(cfg, sec, songSystem(cfg, brief), user + (a > 1 ? `\nYour previous reply was invalid (${lastErr}). JSON only.` : ''), { temperature: 0.8 }))); }
    catch (e) { lastErr = e.message; L.log(`song attempt ${a}: ${e.message}`); }
  }
  if (!song) throw new Error(`could not write the song: ${lastErr}`);
  try { song = normalizeSong(L.parseJSONLoose(await L.llm(cfg, sec,
    EDITOR + '\n\n' + FORMULA + `\n\nApproved concept: ${brief.song}\nRevision feedback (priority): ${feedback || '(none)'}`,
    JSON.stringify(song), { temperature: 0.25 }))); }
  catch (e) { L.log('song editor skipped:', e.message); }
  const lineS = (cfg.song && cfg.song.line_s) || 3.6;
  song.scenes = toScenes(song, lineS);
  try { song = await require('./doctor').song({ cfg, sec, song, normalizeSong, toScenes }); }
  catch (e) { L.log('script doctor skipped:', e.message); }
  return song;
}

function emailHtml(jobId, version, s) {
  const secs = Math.round(s.scenes.reduce((t, x) => t + x.planned_s, 0));
  const blocks = s.sections.map(sec => `<p style="margin:10px 0 2px"><b>${L.esc(sec.name)}</b></p>` +
    sec.lines.map(l => `<div style="margin-left:10px">🎵 ${L.esc(l.text)}<div style="color:#999;font-size:12px;margin-left:18px">🖼 ${L.esc(l.visual)}</div></div>`).join('')).join('');
  const chars = s.characters.map(c => `<b>${L.esc(c.name)}</b>: ${L.esc(c.look)}`).join('<br>');
  return `<div style="font-family:Arial,sans-serif;max-width:760px">
<h2 style="margin:0">🎵 ${L.esc(s.title)}</h2>
<p>${s.song_kind === 'traditional' ? `Traditional rhyme: <b>${L.esc(s.source)}</b>` : '<b>Original song</b>'} · learning: ${L.esc(s.learning)} · ${s.words} words · ≈ ${Math.floor(secs / 60)}m ${secs % 60}s · ${s.scenes.length} shots · draft v${version}</p>
<p style="color:#555">Music: ${L.esc(s.music_style.join(', '))}</p>
${s.doctor ? require('./doctor').cardHtml(s.doctor) : ''}
<p style="color:#555">${chars}</p>${blocks}
<p style="color:#666;font-size:13px">Approve = make a preview of the first shots, plus a separate full-song audio file. Revise = say what to change.</p>
<p style="color:#888;font-size:12px">Job ${jobId}</p></div>`;
}

// ---------- produce ----------
function chooseAnimatedScenes(work, budget) {
  const eligible = work.filter(sc => sc.animate !== false);
  const cap = Math.min(Math.max(0, budget), Math.max(1, Math.ceil(work.length / 4)));
  if (!cap || !eligible.length) return [];
  const picks = [];
  const add = sc => { if (sc && !picks.includes(sc) && picks.length < cap) picks.push(sc); };
  add(eligible[0]);
  if (cap > 1) add(eligible[eligible.length - 1]);
  for (let i = 1; i < work.length; i++) if (work[i].section !== work[i - 1].section) add(work[i]);
  for (let i = 0; i < cap * 3 && picks.length < cap; i++) add(eligible[Math.floor((i + 0.5) * eligible.length / (cap * 3))]);
  return picks.sort((a, b) => a.n - b.n);
}

async function produce({ cfg, sec, dir, jobId, S, PREVIEW, FF, family }) {
  const pad = n => String(n).padStart(3, '0');
  const f = (n, ext) => path.join(dir, `scene_${pad(n)}${ext}`);
  const has = p => { try { return fs.statSync(p).size > 0; } catch { return false; } };
  const r3 = x => Math.round(x * 1000) / 1000;
  const SG = cfg.song || {};
  const warnings = []; let cost = 0;

  // 1. characters of the song: one locked reference picture each (drawn once per job)
  const cdir = path.join(dir, 'characters'); fs.mkdirSync(cdir, { recursive: true });
  const cast = { narrator: 'singer', characters: S.characters.map(c => ({ ...c, ref: path.join(cdir, `${c.id}.jpg`) })) };
  const anchors = [];
  for (const c of cast.characters) {
    if (!has(c.ref)) {
      try {
        const r = await L.retry(() => L.genImage(cfg, sec, { prompt: `${cfg.style}. Character reference sheet of ONE character: ${c.name}, ${c.look}. Full body, facing the camera, happy, plain soft pastel background.` +
          (anchors.length ? ' Same art style as the reference images, but draw ONLY this character.' : ''), refs: anchors.slice(0, 2), width: 2048, height: 2048, file: c.ref }), 2, `draw ${c.id}`);
        cost += r.cost;
      } catch (e) { warnings.push(`Could not draw ${c.name}: ${e.message.slice(0, 80)}`); }
    }
    if (has(c.ref) && anchors.length < 2) anchors.push(L.fileToDataURI(c.ref));
  }
  const missingRefs = cast.characters.filter(c => !has(c.ref)).map(c => c.name);
  if (missingRefs.length) throw new Error(`Missing character references: ${missingRefs.join(', ')}. Production stopped before scene generation.`);
  const refs = Object.fromEntries(cast.characters.map(c => [c.id, L.fileToDataURI(c.ref)]));

  // 2. the whole song, section by section with exact lyrics (so we know when each line is sung)
  const songFile = path.join(dir, 'song_full.mp3');
  const lineS = SG.line_s || 3.6;
  const secMs = S.sections.map(s => Math.max(3000, Math.round(s.lines.length * lineS * (s.name === 'intro' ? 1.2 : 1) * 1000)));
  if (!has(songFile)) {
    L.setStatus(dir, { stage: 'song' });
    const styles = S.music_style.length ? S.music_style : ['cheerful preschool nursery rhyme', 'bouncy', 'ukulele and glockenspiel', 'clear happy vocals'];
    // rhythm: steady tempo, every line sung clearly on the beat, never rushed
    const rhythm = ['steady bouncy tempo around 110 BPM', 'clear singable nursery-rhyme melody', 'every lyric line sung clearly on the beat', 'kids can sing along', 'warm clear lead vocal'];
    const avoid = ['crammed lyrics', 'rushed syllables', 'spoken voice', 'rap', 'scary', 'sad', 'heavy drums', 'long instrumental breaks', 'fade in'];
    const models = SG.music_models || ['music_v2_5', 'music_v2', 'music_v1'];
    let made = '';
    for (const model of models) {
      try {
        const body = model === 'music_v1'
          ? { model_id: 'music_v1', composition_plan: { positive_global_styles: [...styles, ...rhythm.slice(0, 3)], negative_global_styles: avoid.slice(0, 6),
              sections: S.sections.map((s, i) => ({ section_name: s.name, positive_local_styles: [], negative_local_styles: [], duration_ms: secMs[i], lines: s.lines.map(l => l.text) })) } }
          : { model_id: model, composition_plan: { chunks: S.sections.map((s, i) => ({
              text: `[${s.name.replace(/\b\w/g, c => c.toUpperCase())}]\n${s.lines.map(l => l.text).join('\n')}`,
              duration_ms: secMs[i],
              positive_styles: [...styles, ...rhythm, /chorus|intro|outro/i.test(s.name) ? 'big catchy sing-along hook' : 'same melody as the other verses'],
              negative_styles: avoid, context_adherence: 'high' })) } };
        await L.retry(() => L.elPost(sec, '/v1/music?output_format=mp3_48000_192', body, songFile, 900000), 2, `song ${model}`);
        made = model; break;
      } catch (e) { L.log(`song with ${model} failed: ${e.message.slice(0, 160)}`); }
    }
    if (!made) {
      await L.elPost(sec, '/v1/music?output_format=mp3_44100_128', { model_id: 'music_v1', music_length_ms: secMs.reduce((a, b) => a + b, 0),
        prompt: `${styles.join(', ')}. A preschool kids' song. Lyrics: ${S.sections.map(s => `[${s.name}] ${s.lines.map(l => l.text).join(' / ')}`).join(' ')}` }, songFile);
      warnings.push('The song was made from a prompt (not section by section), so picture timing is approximate.');
      made = 'music_v1 (prompt)';
    }
    L.setStatus(dir, { song_model: made });
    if (made !== models[0]) warnings.push(`Song made with ${made} (${models[0]} was not available).`);
  }
  // 3. timeline: planned section lengths, stretched to the real song length
  const total = await L.duration(FF, songFile);
  const planned = secMs.reduce((a, b) => a + b, 0) / 1000;
  const k = total / planned;
  let t = 0; const T = {};
  S.scenes.forEach(sc => { const sDur = secMs[sc.section] / 1000; const n = S.sections[sc.section].lines.length; T[sc.n] = { t0: r3(t), d: r3(sDur / n * k) }; t += sDur / n * k; });

  // 4. director (world sheet + one shot per line)
  let DIR = null;
  try { DIR = await director.plan({ cfg, sec, cast, S, dir, series: null }); cost += DIR.cost || 0; DIR.cost = 0; }
  catch (e) { throw new Error(`Prompt Director failed; scene generation stopped: ${e.message}`); }
  const shotOf = n => DIR && DIR.shots.find(x => x.n === n);
  const work = PREVIEW ? S.scenes.slice(0, cfg.preview_scenes || 6) : S.scenes;

  // 5. pictures
  L.setStatus(dir, { stage: 'images' });
  await L.pool(work, cfg.image.concurrency || 3, async sc => {
    if (has(f(sc.n, '.jpg'))) return;
    const shot = shotOf(sc.n);
    const ids = (shot ? shot.characters : sc.characters).filter(id => refs[id]).slice(0, 3);
    const list = ids.map(id => ({ uri: refs[id], label: cast.characters.find(c => c.id === id).name }));
    if (shot) { const loc = DIR.world.locations.find(l => l.id === shot.location); if (loc && loc.ref && has(loc.ref)) list.push({ uri: L.fileToDataURI(loc.ref), label: `the place (${loc.name})` }); }
    const prompt = shot ? director.imagePrompt(cfg, shot, cast, DIR.world, list.map(x => x.label)) : `${cfg.style}. ${sc.image_prompt}`;
    const r = await L.retry(() => L.genImage(cfg, sec, { prompt, refs: list.map(x => x.uri), file: f(sc.n, '.jpg') }), 3, `image ${sc.n}`);
    cost += r.cost;
  });

  // 6. Animate a selected set of beats; the rest use illustrated stills.
  L.setStatus(dir, { stage: 'clips' });
  const V = cfg.video; const pending = [];
  const existing = work.filter(sc => has(f(sc.n, '.mp4'))).length;
  const chosen = chooseAnimatedScenes(work, Math.max(0, (V.max_clips || 0) - existing));
  for (const sc of chosen) {
    if (has(f(sc.n, '.mp4'))) continue;
    const shot = shotOf(sc.n);
    const prompt = `${shot ? director.motionPrompt(cfg, shot, sc, cast) : sc.motion_prompt}. Cheerful, bouncy movement in time with a happy song.`;
    try { pending.push({ sc, task: await L.submitVideo(cfg, sec, { imageFile: f(sc.n, '.jpg'), prompt, duration: 5 }) }); }
    catch (e) { L.log(`clip ${sc.n} submit failed: ${e.message}`); }
  }
  const deadline = Date.now() + V.max_wait_min * 60000;
  while (pending.length && Date.now() < deadline) {
    await L.sleep(V.poll_ms);
    let r; try { r = await L.runware(sec, pending.map(p => ({ taskType: 'getResponse', taskUUID: p.task })), 60000); } catch { continue; }
    for (const p of [...pending]) {
      const d = r.data.find(x => x.taskUUID === p.task && x.videoURL);
      const err = r.errors.find(x => x.taskUUID === p.task) || r.data.find(x => x.taskUUID === p.task && x.status === 'error');
      if (d) { pending.splice(pending.indexOf(p), 1); try { await L.download(d.videoURL, f(p.sc.n, '.mp4')); cost += d.cost || 0; } catch (e) { L.log(e.message); } }
      else if (err) { pending.splice(pending.indexOf(p), 1); L.log(`clip ${p.sc.n} failed`); }
    }
  }

  // 7. render: silent segments cut exactly to each line, then the song on top
  L.setStatus(dir, { stage: 'render' });
  const fps = cfg.render.fps;
  // clarity: sharper upscaling (lanczos) + light sharpening of the 720p clips
  const SHARP = cfg.render.sharpen === false ? '' : `,unsharp=5:5:${cfg.render.sharpen_amount || 0.8}:5:5:0.0`;
  const segs = [];
  for (const sc of work) {
    const d = T[sc.n].d; const seg = f(sc.n, '_songseg.mp4');
    if (!has(seg)) {
      const v = has(f(sc.n, '.mp4'))
        ? ['-i', f(sc.n, '.mp4'), '-vf', `scale=1920:1080:force_original_aspect_ratio=increase:flags=lanczos,crop=1920:1080,setsar=1${SHARP},fps=${fps},tpad=stop_mode=clone:stop_duration=${d},trim=duration=${d},format=yuv420p`]
        : ['-loop', '1', '-i', f(sc.n, '.jpg'), '-vf', `scale=1920:1080:force_original_aspect_ratio=increase:flags=lanczos,crop=1920:1080,setsar=1,fps=${fps},format=yuv420p`];
      await L.ff(FF, [...v, '-t', String(d), '-an', '-c:v', 'libx264', '-preset', 'medium', '-crf', String(cfg.render.crf_song || 17), '-video_track_timescale', '15360', seg], `segment ${sc.n}`);
    }
    segs.push(seg);
  }
  fs.writeFileSync(path.join(dir, 'songconcat.txt'), segs.map(x => `file '${x}'`).join('\n'));
  const vid = path.join(dir, 'songvideo.mp4');
  await L.ff(FF, ['-f', 'concat', '-safe', '0', '-i', path.join(dir, 'songconcat.txt'), '-c', 'copy', vid], 'concat');
  const vlen = await L.duration(FF, vid);
  const final = path.join(dir, PREVIEW ? 'preview.mp4' : 'final.mp4');
  await L.ff(FF, ['-i', vid, '-i', songFile, '-filter_complex', `[1:a]atrim=duration=${vlen},afade=t=out:st=${Math.max(0, vlen - 1.5).toFixed(2)}:d=1.5,loudnorm=I=-14:TP=-1.5:LRA=11[a]`,
    '-map', '0:v', '-map', '[a]', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-t', String(vlen), '-movflags', '+faststart', final], 'final');

  const slug = S.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
  const costTotal = r3((L.readJSON(path.join(dir, 'status.json'), {}).cost_total || 0) + cost);
  const mins = `${Math.floor(vlen / 60)}:${String(Math.round(vlen % 60)).padStart(2, '0')}`;
  const base = { ok: true, jobId, next_job: '', notify_email: cfg.notify_email, drive_parent: cfg.drive_parent_folder_id || 'root',
    length: mins, clips: work.filter(sc => has(f(sc.n, '.mp4'))).length, scenes: work.length, cost: costTotal, warnings,
    description: S.description, lesson: S.learning, tags: S.tags.join(', ') };
  if (PREVIEW) {
    L.setStatus(dir, { stage: 'preview_ready', cost_total: costTotal });
    return { ...base, preview: true, title: `PREVIEW · ${S.title}`, part: `First ${work.length} of ${S.scenes.length} shots; full-song audio is separate`,
      folder_name: `DD TV English – PREVIEW – ${S.title} (${jobId})`, files: [{ path: final, name: `0_${slug}_PREVIEW.mp4` },
        { path: songFile, name: `0_${slug}_FULL_SONG.mp3` }], shorts: [] };
  }

  // 8. a Short (first ~40 s, vertical) and a thumbnail
  const short = path.join(dir, 'short_1.mp4');
  const sl = Math.min(40, vlen);
  await L.ff(FF, ['-i', final, '-t', String(sl), '-filter_complex', `[0:v]split[a][b];[a]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=24:3[bg];[b]scale=1728:-2,crop=1080:ih[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1,format=yuv420p[v];[0:a]afade=t=out:st=${(sl - 1).toFixed(2)}:d=1[a]`,
    '-map', '[v]', '-map', '[a]', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-c:a', 'aac', '-movflags', '+faststart', short], 'short');
  const thumb = path.join(dir, 'thumbnail.jpg');
  if (!has(thumb)) {
    try {
      const raw = path.join(dir, 'thumbnail_raw.jpg');
      const r = await L.genImage(cfg, sec, { prompt: `${cfg.style}. YouTube thumbnail, bold, bright, close-up, big happy faces. ${S.thumbnail_prompt}`, refs: Object.values(refs).slice(0, 3), file: raw });
      cost += r.cost;
      await L.ff(FF, ['-i', raw, '-vf', 'scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720', '-q:v', '3', thumb], 'thumb');
    } catch (e) { warnings.push('Thumbnail failed; pick a frame instead.'); }
  }
  const meta = path.join(dir, 'metadata.txt');
  fs.writeFileSync(meta, [`TITLE: ${S.title}`, '', 'DESCRIPTION:', S.description, '', `TAGS: ${S.tags.join(', ')}`, '', 'LYRICS:', ...S.sections.flatMap(s => ['', ...s.lines.map(l => l.text)])].join('\n'));
  L.setStatus(dir, { stage: 'ready', cost_total: r3(costTotal + cost) });
  return { ...base, cost: r3(costTotal + cost), title: S.title, part: 'Song episode',
    youtube: cfg.youtube && cfg.youtube.enabled !== false ? {
      upload: true, privacy: cfg.youtube.privacy || 'public', category_id: String(cfg.youtube.category_id || '27'), region: cfg.youtube.region || 'US',
      made_for_kids: true, synthetic: !!cfg.youtube.synthetic_label, publish_delay_h: cfg.youtube.publish_delay_h || 0,
      title: S.title.slice(0, 100), description: `${S.description || ''}\n\n${S.lesson ? `Today's lesson: ${S.lesson}` : ''}`.trim().slice(0, 4900),
      tags: (S.tags || []).slice(0, 15).join(','), long_path: final, short_path: short, thumb_path: has(thumb) ? thumb : '', short_title: `${S.title.split('|')[0].trim()} #shorts`.slice(0, 100)
    } : { upload: false },
 folder_name: `DD TV English – ${S.title} (${jobId})`,
    files: [{ path: final, name: `1_${slug}_LONG.mp4` }, { path: short, name: `2_${slug}_SHORT_1.mp4` },
      ...(has(thumb) ? [{ path: thumb, name: `3_${slug}_thumbnail.jpg` }] : []), { path: meta, name: `4_${slug}_metadata.txt` }],
    shorts: [`${S.title.split('|')[0].trim()} #shorts`] };
}

module.exports = { write, produce, emailHtml, TRADITIONAL, FORMULA, normalizeSong, toScenes, chooseAnimatedScenes };
